'use strict';

(function initializeNoteBridge() {
  const processedOperations = new Set();

  function delay(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }

  function isVisible(element) {
    if (!element) return false;
    const style = getComputedStyle(element);
    return style.display !== 'none' && style.visibility !== 'hidden' && !element.hidden;
  }

  function accessibleText(element) {
    return [
      element.getAttribute('aria-label'),
      element.getAttribute('title'),
      element.getAttribute('data-testid'),
      element.textContent
    ].filter(Boolean).join(' ').replace(/\s+/g, ' ').trim();
  }

  function isLiked(button) {
    if (!button) return false;
    if (button.getAttribute('aria-pressed') === 'true') return true;
    if (button.getAttribute('data-active') === 'true' || button.getAttribute('data-liked') === 'true') return true;
    const state = [
      button.getAttribute('data-active'),
      button.getAttribute('data-liked'),
      button.className,
      accessibleText(button)
    ].join(' ');
    return /(^|\s)(true|active|liked|is-active)(\s|$)/i.test(state) || /スキ済み|スキを取り消す/.test(state);
  }

  function findLikeButton() {
    const preferred = Array.from(document.querySelectorAll([
      'button.o-noteLikeV3__iconButton',
      'button[aria-label="スキ"][aria-pressed]',
      'button[aria-label*="スキを取り消す"]'
    ].join(','))).find(isVisible);
    if (preferred) return preferred;

    const candidates = Array.from(document.querySelectorAll('button,[role="button"]'));
    return candidates.find((element) => {
      if (!isVisible(element)) return false;
      const text = accessibleText(element);
      return /スキ/.test(text) && !/お礼|一覧|した人|数|設定/.test(text);
    }) || null;
  }

  function isFollowing(button) {
    if (!button) return false;
    if (button.getAttribute('aria-pressed') === 'true' || button.getAttribute('data-following') === 'true') return true;
    return /フォロー中|フォロー解除|following/i.test(accessibleText(button) + ' ' + String(button.className || ''));
  }

  function findFollowButton() {
    const candidates = Array.from(document.querySelectorAll('button,[role="button"]'));
    return candidates.find((element) => {
      if (!isVisible(element)) return false;
      const text = accessibleText(element);
      return /フォロー/.test(text) && !/フォロワー|一覧|おすすめ|通知/.test(text);
    }) || null;
  }

  function findLoginBarrier() {
    const candidates = Array.from(document.querySelectorAll('[role="dialog"],dialog,form,section,[role="region"]'));
    return candidates.find((element) => {
      const text = accessibleText(element);
      return isVisible(element) && (/コメントするには/.test(text) || (/コメント/.test(text) && /ログイン|会員登録/.test(text)));
    }) || null;
  }

  async function currentUserProfile() {
    const endpoints = ['/api/v2/current_user', '/api/v1/current_user'];
    for (const endpoint of endpoints) {
      try {
        const response = await fetch(endpoint, { credentials: 'include', headers: { accept: 'application/json' } });
        if (response.status === 401 || response.status === 403) return false;
        if (response.status === 404) continue;
        if (response.ok) {
          const payload = await response.json();
          const data = payload && payload.data !== undefined ? payload.data : payload;
          if (!data) return null;
          const user = data.user || data;
          if (user && (user.id || user.urlname || user.nickname)) return user;
          return null;
        }
      } catch (_) {
        // DOM-level login detection remains available when this endpoint changes.
      }
    }
    return null;
  }

  async function currentUserState() {
    const profile = await currentUserProfile();
    return profile === false ? false : (profile ? true : null);
  }

  function noteClientCode() {
    try {
      return String(localStorage.getItem('note-client-code') || '').trim();
    } catch (_) {
      return '';
    }
  }

  function noteCommentAst(value) {
    return {
      type: 'root',
      children: [{
        type: 'element',
        tag_name: 'p',
        children: [{ type: 'text', value: String(value || '').replace(/\r\n?/g, '\n') }]
      }]
    };
  }

  function noteApiErrorMessage(payload, fallback) {
    const error = payload && (payload.error || payload.data && payload.data.error);
    if (error && typeof error === 'object' && error.message) return String(error.message);
    if (typeof error === 'string' && error.trim()) return error.trim();
    return fallback;
  }

  async function performDirectComment(comment, replyTarget) {
    const noteKey = (location.pathname.match(/\/n\/([a-zA-Z0-9_-]+)/) || [])[1] || '';
    if (!noteKey) {
      return { ok: false, code: 'wrong_article', message: '対象の記事を確認できませんでした。' };
    }
    if (replyTarget && !replyTarget.key) {
      return { ok: false, code: 'reply_target_missing', message: '返信先のコメントを確認できませんでした。' };
    }

    const headers = {
      Accept: 'application/json',
      'Content-Type': 'application/json',
      'X-Requested-With': 'XMLHttpRequest'
    };
    const clientCode = noteClientCode();
    if (clientCode) headers['X-Note-Client-Code'] = clientCode;

    const body = {
      comment: noteCommentAst(comment),
      acknowledgement: false,
      caller_name: 'createNoteCommentV3'
    };
    if (replyTarget && replyTarget.key) body.parent_key = replyTarget.key;

    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 10000);
    try {
      const response = await fetch('/api/v3/notes/' + encodeURIComponent(noteKey) + '/note_comments', {
        method: 'POST',
        credentials: 'include',
        cache: 'no-store',
        headers,
        body: JSON.stringify(body),
        signal: controller.signal
      });
      let payload = null;
      try { payload = await response.json(); } catch (_) {}

      if (response.ok && !(payload && payload.error)) {
        const data = payload && payload.data !== undefined ? payload.data : payload;
        const created = data && data.comment ? data.comment : data;
        return {
          ok: true,
          action: 'comment',
          verified: true,
          source: 'note_api_v3_page',
          commentKey: String(created && created.key || '')
        };
      }

      if (response.status === 401 || response.status === 403) {
        return { ok: false, code: 'login_required', message: 'Firefoxでnoteへログインしてください。', status: response.status };
      }
      const error = payload && (payload.error || payload.data && payload.data.error);
      if (error && error.type === 'comment_acknowledgement') {
        return { ok: false, code: 'comment_acknowledgement', message: 'このコメントはnote側で確認操作が必要です。開いたnote画面から内容を確認して送信してください。', status: response.status };
      }
      return {
        ok: false,
        code: 'comment_api_rejected',
        message: noteApiErrorMessage(payload, 'noteがコメントを受け付けませんでした。時間をおいて再度お試しください。'),
        status: response.status
      };
    } catch (error) {
      if (error && error.name === 'AbortError') {
        return { ok: false, code: 'comment_result_unknown', message: '10秒以内に送信結果を確認できませんでした。二重投稿を防ぐため、note側のコメント欄で状態をご確認ください。' };
      }
      return { ok: false, code: 'comment_api_unavailable', message: 'noteとの通信に失敗しました。Reader画面はそのままです。時間をおいて再度お試しください。' };
    } finally {
      clearTimeout(timer);
    }
  }

  async function waitFor(getter, timeout) {
    const deadline = Date.now() + timeout;
    while (Date.now() < deadline) {
      const value = getter();
      if (value) return value;
      await delay(180);
    }
    return null;
  }

  async function performLike() {
    const login = await currentUserState();
    if (login === false) {
      return { ok: false, code: 'login_required', message: 'Firefoxでnoteへログインしてください。' };
    }

    const button = await waitFor(findLikeButton, 10000);
    if (!button) {
      return { ok: false, code: 'like_button_missing', message: 'スキの場所を確認できませんでした。note画面を開きます。' };
    }
    if (isLiked(button)) return { ok: true, action: 'like', already: true, verified: true };

    button.scrollIntoView({ block: 'center', behavior: 'auto' });
    button.click();

    const deadline = Date.now() + 5000;
    while (Date.now() < deadline) {
      if (findLoginBarrier()) {
        return { ok: false, code: 'login_required', message: 'Firefoxでnoteへログインしてください。' };
      }
      if (isLiked(button) || isLiked(findLikeButton())) {
        return { ok: true, action: 'like', already: false, verified: true };
      }
      await delay(180);
    }
    return { ok: true, action: 'like', already: false, verified: false };
  }

  async function performFollow() {
    const login = await currentUserState();
    if (login === false) {
      return { ok: false, code: 'login_required', message: 'Firefoxでnoteへログインしてください。' };
    }
    const button = await waitFor(findFollowButton, 12000);
    if (!button) {
      return { ok: false, code: 'follow_button_missing', message: 'フォローボタンを確認できませんでした。note画面を開きます。' };
    }
    if (isFollowing(button)) return { ok: true, action: 'follow', already: true, verified: true };
    button.scrollIntoView({ block: 'center', behavior: 'auto' });
    button.click();
    const deadline = Date.now() + 5000;
    while (Date.now() < deadline) {
      if (findLoginBarrier()) return { ok: false, code: 'login_required', message: 'Firefoxでnoteへログインしてください。' };
      if (isFollowing(button) || isFollowing(findFollowButton())) {
        return { ok: true, action: 'follow', already: false, verified: true };
      }
      await delay(180);
    }
    return { ok: true, action: 'follow', already: false, verified: false };
  }

  function findArticleSaveButton() {
    const candidates = Array.from(document.querySelectorAll('button,a,[role="button"]'));
    return candidates.find((element) => {
      if (!isVisible(element)) return false;
      const text = accessibleText(element);
      return /記事を保存|マガジンに追加|マガジンへ追加/.test(text) && !/作成|管理|並べ替え/.test(text);
    }) || null;
  }

  function magazineActionControls(scope) {
    const root = scope && typeof scope.querySelectorAll === 'function' ? scope : document;
    return Array.from(root.querySelectorAll('button,[role="button"],input[type="checkbox"]')).filter((element) => {
      if (!isVisible(element)) return false;
      if (element instanceof HTMLInputElement && element.type === 'checkbox') return true;
      const text = accessibleText(element);
      return /^(追加|追加済|保存|保存済)$/.test(compactText(text)) || /マガジン.*追加|追加.*マガジン/.test(text);
    });
  }

  function findMagazinePanel() {
    const dialogs = Array.from(document.querySelectorAll('[role="dialog"],dialog,[role="listbox"],[data-testid*="magazine" i]')).filter(isVisible);
    const explicit = dialogs.find((element) => /マガジン/.test(accessibleText(element)) && magazineActionControls(element).length);
    if (explicit) return explicit;
    const seed = magazineActionControls(document).find((element) => {
      const text = compactText(accessibleText(element));
      return /^(追加|追加済|保存|保存済)$/.test(text);
    });
    let node = seed && seed.parentElement;
    for (let depth = 0; node && node !== document.body && depth < 8; depth += 1, node = node.parentElement) {
      if (/マガジン/.test(accessibleText(node)) && magazineActionControls(node).length) return node;
    }
    return null;
  }

  async function ensureMagazinePanel() {
    let panel = findMagazinePanel();
    if (panel) return panel;
    const button = await waitFor(findArticleSaveButton, 12000);
    if (!button) return null;
    button.scrollIntoView({ block: 'center', behavior: 'auto' });
    button.click();
    return waitFor(findMagazinePanel, 8000);
  }

  function magazineKeyFromHref(value) {
    const match = String(value || '').match(/\/m\/([a-zA-Z0-9_-]+)/);
    return match ? match[1] : '';
  }

  function magazineRowForControl(control, panel) {
    const direct = control.closest('li,[role="listitem"],tr');
    if (direct && (!panel || panel.contains(direct))) return direct;
    let node = control.parentElement;
    for (let depth = 0; node && node !== panel && node !== document.body && depth < 6; depth += 1, node = node.parentElement) {
      const actions = magazineActionControls(node);
      const text = compactText(accessibleText(node));
      if (actions.length === 1 && text.length > compactText(accessibleText(control)).length && text.length < 800) return node;
    }
    return control.parentElement || control;
  }

  function magazineNameFromRow(row, control) {
    const anchor = Array.from(row.querySelectorAll('a[href*="/m/"]')).find((element) => compactText(element.textContent));
    if (anchor) return compactText(anchor.textContent).slice(0, 160);
    const preferred = Array.from(row.querySelectorAll('strong,h2,h3,h4,[data-testid*="title" i]')).find((element) => {
      const value = compactText(element.textContent);
      return value && !/追加|保存|マガジン一覧/.test(value);
    });
    if (preferred) return compactText(preferred.textContent).slice(0, 160);
    const actionText = compactText(accessibleText(control));
    const lines = String(row.innerText || row.textContent || '').split(/\n+/).map(compactText).filter(Boolean).filter((value) => {
      return value !== actionText && !/^(追加|追加済|保存|保存済|無料|有料|定期購読|共同運営)$/.test(value);
    });
    return String(lines[0] || '').slice(0, 160);
  }

  function magazineIsAdded(control) {
    if (!control) return false;
    if (control instanceof HTMLInputElement && control.type === 'checkbox' && control.checked) return true;
    if (control.getAttribute('aria-checked') === 'true' || control.getAttribute('aria-pressed') === 'true') return true;
    return /追加済|保存済/.test(accessibleText(control));
  }

  function magazineKindFromRow(row) {
    const match = compactText(accessibleText(row)).match(/定期購読|共同運営|有料|無料/);
    return match ? match[0] : '';
  }

  function collectMagazineRows(panel) {
    const seen = new Set();
    const rows = [];
    magazineActionControls(panel).forEach((control, index) => {
      const row = magazineRowForControl(control, panel);
      const anchor = Array.from(row.querySelectorAll('a[href*="/m/"]'))[0];
      const key = magazineKeyFromHref(anchor && anchor.getAttribute('href'));
      const name = magazineNameFromRow(row, control);
      if (!key && !name) return;
      const identity = key || name + ':' + index;
      if (seen.has(identity)) return;
      seen.add(identity);
      const already = magazineIsAdded(control);
      const unavailable = Boolean(control.disabled && !already);
      const rowText = compactText(accessibleText(row));
      rows.push({
        key,
        name,
        index,
        kind: magazineKindFromRow(row),
        already,
        available: !unavailable,
        reason: unavailable ? (/他の人の記事/.test(rowText) ? '他人の記事は対象外' : '追加できません') : '',
        control,
        row
      });
    });
    return rows;
  }

  function publicMagazineRows(rows) {
    return (rows || []).map((row) => ({
      key: row.key,
      name: row.name,
      index: row.index,
      kind: row.kind,
      already: row.already,
      available: row.available,
      reason: row.reason
    }));
  }

  function findMagazineTarget(rows, target) {
    if (!target) return null;
    if (target.key) {
      const byKey = rows.find((row) => row.key === target.key);
      if (byKey) return byKey;
    }
    if (target.name) {
      const byName = rows.find((row) => row.name === target.name);
      if (byName) return byName;
    }
    if (!target.key && !target.name) return rows.find((row) => row.index === Number(target.index)) || null;
    return null;
  }

  function findMagazineConfirmation(panel, name) {
    const dialogs = Array.from(document.querySelectorAll('[role="dialog"],dialog')).filter((element) => isVisible(element) && element !== panel);
    for (const dialog of dialogs) {
      const text = compactText(accessibleText(dialog));
      if (!/追加/.test(text) || (name && !text.includes(name) && !/マガジン.*追加/.test(text))) continue;
      const confirm = Array.from(dialog.querySelectorAll('button,[role="button"]')).find((button) => {
        return isVisible(button) && /^(はい|追加|追加する|OK)$/.test(compactText(accessibleText(button)));
      });
      if (confirm) return confirm;
    }
    return null;
  }

  async function performMagazines() {
    const login = await currentUserState();
    if (login === false) return { ok: false, code: 'login_required', message: 'Firefoxでnoteへログインしてください。' };
    const panel = await ensureMagazinePanel();
    if (!panel) return { ok: false, code: 'magazine_panel_missing', message: 'noteの「記事を保存」を確認できませんでした。' };
    const rows = collectMagazineRows(panel);
    return { ok: true, action: 'magazines', magazines: publicMagazineRows(rows), verified: true };
  }

  async function performMagazineAdd(target) {
    const login = await currentUserState();
    if (login === false) return { ok: false, code: 'login_required', message: 'Firefoxでnoteへログインしてください。' };
    let panel = await ensureMagazinePanel();
    if (!panel) return { ok: false, code: 'magazine_panel_missing', message: 'noteの「記事を保存」を確認できませんでした。' };
    let row = findMagazineTarget(collectMagazineRows(panel), target);
    if (!row) return { ok: false, code: 'magazine_missing', message: '選択したマガジンを確認できませんでした。' };
    if (row.already) return { ok: true, action: 'magazine_add', already: true, verified: true };
    if (!row.available || row.control.disabled) return { ok: false, code: 'magazine_unavailable', message: 'このマガジンには記事を追加できません。' };
    row.control.scrollIntoView({ block: 'center', behavior: 'auto' });
    row.control.click();
    await delay(300);
    const confirm = findMagazineConfirmation(panel, row.name);
    if (confirm) confirm.click();
    const verified = await waitFor(() => {
      const currentPanel = findMagazinePanel();
      if (!currentPanel) return null;
      const current = findMagazineTarget(collectMagazineRows(currentPanel), target);
      return current && current.already ? current : null;
    }, 6000);
    if (verified) return { ok: true, action: 'magazine_add', already: false, verified: true };
    panel = await ensureMagazinePanel();
    row = panel && findMagazineTarget(collectMagazineRows(panel), target);
    if (row && row.already) return { ok: true, action: 'magazine_add', already: false, verified: true };
    return { ok: false, code: 'magazine_result_unknown', message: '追加済みになったことを確認できませんでした。二重操作を避けるため、note側で状態をご確認ください。' };
  }

  async function performStatus() {
    const login = await currentUserState();
    if (login === false) {
      return { ok: false, code: 'login_required', message: 'Firefoxでnoteへログインしてください。' };
    }
    const button = await waitFor(findLikeButton, 10000);
    if (!button) {
      return { ok: false, code: 'like_button_missing', message: 'スキ状態を確認できませんでした。' };
    }
    return { ok: true, action: 'status', liked: isLiked(button), verified: true };
  }

  function findCommentEditor(root) {
    const scope = root && typeof root.querySelectorAll === 'function' ? root : document;
    const selectors = [
      'textarea[placeholder*="コメント"]',
      'textarea[name*="comment" i]',
      'textarea[aria-label*="コメント"]',
      '[contenteditable="true"][aria-label*="コメント"]',
      '[contenteditable="true"][data-placeholder*="コメント"]',
      '[contenteditable="true"][role="textbox"]',
      'textarea',
      '[contenteditable="true"]'
    ];
    for (const selector of selectors) {
      const element = Array.from(scope.querySelectorAll(selector)).find(isVisible);
      if (element) return element;
    }
    return null;
  }

  function findCommentTrigger() {
    const currentNoteTrigger = Array.from(document.querySelectorAll('button.o-viewComment')).find(isVisible);
    if (currentNoteTrigger) return currentNoteTrigger;
    const candidates = Array.from(document.querySelectorAll('button,a,[role="button"]'));
    return candidates.find((element) => {
      const text = accessibleText(element);
      return isVisible(element) && /コメントする|コメントを書く|コメントを追加|コメント/.test(text) && !/送信|投稿済み|削除/.test(text);
    }) || null;
  }

  function findCommentComposerTrigger() {
    const candidates = Array.from(document.querySelectorAll('button,a,[role="button"]'));
    return candidates.find((element) => {
      const text = accessibleText(element);
      return isVisible(element) && /コメントする|コメントを書く|コメントを追加/.test(text) && !/コメントをみる/.test(text);
    }) || null;
  }

  function compactText(value) {
    return String(value || '').replace(/\s+/g, ' ').trim();
  }

  function urlnameFromHref(value) {
    const match = String(value || '').match(/^\/?([a-zA-Z0-9_-]+)(?:[/?#]|$)/);
    return match ? match[1] : '';
  }

  function commentCardForReplyButton(button) {
    let node = button && button.parentElement;
    while (node && node !== document.body) {
      if (node.matches && node.matches('div.relative.flex.gap-2') && node.querySelector('.m-foldableText p,p.whitespace-pre-line')) {
        return node;
      }
      node = node.parentElement;
    }
    return null;
  }

  function findCommentLikeButton(card) {
    if (!card) return null;
    const preferred = Array.from(card.querySelectorAll([
      'button[aria-label*="スキ"]',
      'button[data-testid*="like" i]',
      'button[data-liked]',
      'button[data-active]'
    ].join(','))).find((element) => isVisible(element) && !/記事/.test(accessibleText(element)));
    if (preferred) return preferred;
    return Array.from(card.querySelectorAll('button,[role="button"]')).find((element) => {
      const text = accessibleText(element);
      return isVisible(element) && /スキ/.test(text) && !/一覧|した人|記事/.test(text);
    }) || null;
  }

  function isCommentLiked(card, button) {
    // Never use the number beside the heart or another user's avatar as the
    // creator-like signal. Only the active/red heart owned by this session is
    // authoritative.
    if (isLiked(button)) return true;
    if (!card || !button) return false;
    const visualNodes = [button, button.querySelector('svg'), button.querySelector('path')].filter(Boolean);
    const hasRedHeart = visualNodes.some((node) => {
      const style = getComputedStyle(node);
      const colors = [style.color, style.fill, style.stroke].join(' ');
      const values = Array.from(colors.matchAll(/rgba?\((\d+)[, ]+(\d+)[, ]+(\d+)/g));
      return values.some((match) => Number(match[1]) > Number(match[2]) + 35 && Number(match[1]) > Number(match[3]) + 15);
    });
    if (hasRedHeart) return true;
    const explicit = [
      button.getAttribute('aria-pressed'),
      button.getAttribute('data-liked'),
      button.getAttribute('data-active'),
      button.getAttribute('aria-label'),
      button.getAttribute('title')
    ].filter(Boolean).join(' ');
    return /(^|\s)(true|liked|active)(\s|$)/i.test(explicit) || /スキ済み|スキを取り消す/.test(explicit);
  }

  function findCommentRows() {
    const rows = [];
    const seen = new Set();
    let threadIndex = -1;
    Array.from(document.querySelectorAll('button[aria-label="返信"]')).forEach((replyButton) => {
      if (!isVisible(replyButton)) return;
      const card = commentCardForReplyButton(replyButton);
      if (!card || seen.has(card)) return;
      const bodyElement = card.querySelector('.m-foldableText p,p.whitespace-pre-line');
      const authorLink = card.querySelector('a[href^="/"]');
      const time = card.querySelector('time');
      const body = compactText(bodyElement && bodyElement.textContent);
      const authorUrlname = urlnameFromHref(authorLink && authorLink.getAttribute('href'));
      if (!body || !authorUrlname) return;
      seen.add(card);
      const authorText = compactText(authorLink && authorLink.textContent) || authorUrlname;
      const avatar = card.querySelector('img');
      const nested = Boolean(card.parentElement && card.parentElement.closest && card.parentElement.closest('.mt-2.ml-2'));
      if (!nested) threadIndex += 1;
      const likeButton = findCommentLikeButton(card);
      rows.push({
        card,
        replyButton,
        authorUrlname,
        authorName: authorText,
        body,
        publishedAt: time ? (time.getAttribute('datetime') || compactText(time.textContent)) : '',
        avatar: avatar ? (avatar.currentSrc || avatar.src || '') : '',
        depth: nested ? 1 : 0,
        threadIndex: Math.max(threadIndex, 0),
        liked: isCommentLiked(card, likeButton),
        likeButton
      });
    });
    return rows;
  }

  async function ensureCommentsOpen(options) {
    const expandAll = !options || options.expandAll !== false;
    let rows = findCommentRows();
    if (!rows.length) {
      const trigger = await waitFor(findCommentTrigger, 15000);
      if (trigger) {
        trigger.scrollIntoView({ block: 'center', behavior: 'auto' });
        trigger.click();
      }
    }
    rows = await waitFor(() => {
      const found = findCommentRows();
      return found.length ? found : null;
    }, 15000);
    if (!rows || !rows.length) return [];
    if (expandAll) await expandAllComments();
    return findCommentRows();
  }

  function threadExpandKey(button) {
    const card = commentCardForReplyButton(button.closest('div.relative.flex.gap-2')?.querySelector('button[aria-label="返信"]'))
      || button.closest('div.relative.flex.gap-2');
    const author = card && card.querySelector('a[href^="/"]');
    const body = card && card.querySelector('.m-foldableText p,p.whitespace-pre-line');
    return [urlnameFromHref(author && author.getAttribute('href')), compactText(body && body.textContent), compactText(button.textContent)].join('|');
  }

  function findThreadExpandButtons() {
    return Array.from(document.querySelectorAll('.o-commentSection button')).filter((button) => {
      return isVisible(button) && /^返信\d+件$/.test(compactText(accessibleText(button)));
    });
  }

  function findCommentListMore() {
    return Array.from(document.querySelectorAll('.o-commentSection .comment-list button')).find((button) => {
      return isVisible(button) && !button.closest('.m-foldableText') && compactText(accessibleText(button)) === 'もっとみる';
    }) || null;
  }

  async function expandAllComments() {
    const expandedThreads = new Set();
    for (let round = 0; round < 30; round += 1) {
      let acted = false;
      const threadButtons = findThreadExpandButtons();
      for (const button of threadButtons) {
        const key = threadExpandKey(button);
        if (!key || expandedThreads.has(key)) continue;
        expandedThreads.add(key);
        button.scrollIntoView({ block: 'center', behavior: 'auto' });
        button.click();
        acted = true;
        await delay(120);
      }
      const more = findCommentListMore();
      if (more) {
        more.scrollIntoView({ block: 'center', behavior: 'auto' });
        more.click();
        acted = true;
        await delay(350);
      }
      if (!acted) break;
    }
  }

  async function performComments() {
    const profile = await currentUserProfile();
    if (profile === false) {
      return { ok: false, code: 'login_required', message: 'Firefoxでnoteへログインしてください。' };
    }
    const rows = await ensureCommentsOpen();
    if (!rows.length) {
      return { ok: true, action: 'comments', comments: [], viewerUrlname: profile && profile.urlname ? profile.urlname : '', verified: true };
    }
    return {
      ok: true,
      action: 'comments',
      comments: rows.slice(0, 100).map((row) => ({
        authorUrlname: row.authorUrlname,
        authorName: row.authorName,
        body: row.body,
        publishedAt: row.publishedAt,
        avatar: row.avatar,
        depth: row.depth,
        threadIndex: row.threadIndex,
        liked: row.liked
      })),
      viewerUrlname: profile && profile.urlname ? profile.urlname : '',
      verified: true
    };
  }

  async function performAccount() {
    const profile = await currentUserProfile();
    if (profile === false) {
      return { ok: false, code: 'login_required', message: 'Firefoxでnoteへログインしてください。' };
    }
    if (!profile || !profile.urlname) {
      return { ok: false, code: 'account_unavailable', message: 'ログイン中のnoteアカウントを確認できませんでした。ユーザー名を入力してください。' };
    }
    return { ok: true, action: 'account', urlname: profile.urlname, nickname: profile.nickname || profile.name || profile.urlname };
  }

  function findTargetRow(rows, targetValue) {
    if (!targetValue) return null;
    const targetBody = compactText(targetValue.body);
    return rows.find((row) => {
      if (row.authorUrlname !== targetValue.authorUrlname || row.body !== targetBody) return false;
      return !targetValue.publishedAt || row.publishedAt === targetValue.publishedAt;
    }) || rows.find((row) => row.authorUrlname === targetValue.authorUrlname && row.body === targetBody) || null;
  }

  function findThreadExpandButtonForRow(row) {
    if (!row || !row.card) return null;
    return Array.from(row.card.querySelectorAll('button')).find((button) => {
      return isVisible(button) && /^返信\d+件$/.test(compactText(accessibleText(button)));
    }) || null;
  }

  function findRootRow(rows, targetValue) {
    if (!targetValue || !targetValue.rootAuthorUrlname || !targetValue.rootBody) return null;
    return findTargetRow(rows, {
      authorUrlname: targetValue.rootAuthorUrlname,
      body: targetValue.rootBody,
      publishedAt: ''
    });
  }

  async function findTargetRowQuickly(targetValue) {
    let rows = await ensureCommentsOpen({ expandAll: false });
    let target = findTargetRow(rows, targetValue);
    if (target) return target;

    // Replies are hidden behind their own root's "返信N件" button. Open only
    // that thread instead of every thread on the article.
    const root = findRootRow(rows, targetValue);
    const threadButton = findThreadExpandButtonForRow(root);
    if (threadButton) {
      threadButton.scrollIntoView({ block: 'center', behavior: 'auto' });
      threadButton.click();
      target = await waitFor(() => findTargetRow(findCommentRows(), targetValue), 4500);
      if (target) return target;
    }

    // If the root comment is not in the initial page, load one page at a time
    // and stop as soon as the requested comment (or its parent) appears.
    for (let round = 0; round < 8; round += 1) {
      const more = findCommentListMore();
      if (!more) break;
      more.scrollIntoView({ block: 'center', behavior: 'auto' });
      more.click();
      await delay(260);
      rows = findCommentRows();
      target = findTargetRow(rows, targetValue);
      if (target) return target;
      const loadedRoot = findRootRow(rows, targetValue);
      const loadedThreadButton = findThreadExpandButtonForRow(loadedRoot);
      if (loadedThreadButton) {
        loadedThreadButton.scrollIntoView({ block: 'center', behavior: 'auto' });
        loadedThreadButton.click();
        target = await waitFor(() => findTargetRow(findCommentRows(), targetValue), 4500);
        if (target) return target;
      }
    }
    return null;
  }

  async function performDirectCommentLike(targetValue) {
    const noteKey = (location.pathname.match(/\/n\/([a-zA-Z0-9_-]+)/) || [])[1] || '';
    const commentKey = String(targetValue && targetValue.commentKey || '').trim();
    if (!noteKey) return { ok: false, code: 'wrong_article', message: '対象の記事を確認できませんでした。' };
    if (!commentKey) return { ok: false, code: 'comment_target_missing', message: '対象コメントの識別情報を確認できませんでした。' };
    if (targetValue && targetValue.liked === true) {
      return { ok: true, action: 'comment_like', already: true, verified: true, source: 'note_api_v3_page' };
    }

    const headers = { Accept: 'application/json', 'X-Requested-With': 'XMLHttpRequest' };
    const clientCode = noteClientCode();
    if (clientCode) headers['X-Note-Client-Code'] = clientCode;
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 10000);
    try {
      const response = await fetch(
        '/api/v3/notes/' + encodeURIComponent(noteKey) + '/note_comments/' + encodeURIComponent(commentKey) + '/likes',
        {
          method: 'POST',
          credentials: 'include',
          cache: 'no-store',
          headers,
          signal: controller.signal
        }
      );
      let payload = null;
      try { payload = await response.json(); } catch (_) {}
      if (response.ok && !(payload && payload.error)) {
        return { ok: true, action: 'comment_like', already: false, verified: true, source: 'note_api_v3_page' };
      }
      if (response.status === 401 || response.status === 403) {
        return { ok: false, code: 'login_required', message: 'Firefoxでnoteへログインしてください。', status: response.status };
      }
      if (response.status === 404) {
        return { ok: false, code: 'comment_target_missing', message: '対象のコメントが見つかりませんでした。', status: response.status };
      }
      return {
        ok: false,
        code: 'comment_like_api_rejected',
        message: noteApiErrorMessage(payload, 'noteがコメントへのスキを受け付けませんでした。'),
        status: response.status
      };
    } catch (error) {
      if (error && error.name === 'AbortError') {
        return { ok: false, code: 'comment_like_result_unknown', message: '10秒以内に結果を確認できませんでした。二重操作を防ぐため自動再送はしていません。' };
      }
      return { ok: false, code: 'comment_like_api_unavailable', message: 'noteとの通信に失敗しました。Reader画面はそのままです。' };
    } finally {
      clearTimeout(timer);
    }
  }

  async function performCommentLike(targetValue) {
    const login = await currentUserState();
    if (login === false) {
      return { ok: false, code: 'login_required', message: 'Firefoxでnoteへログインしてください。' };
    }
    return performDirectCommentLike(targetValue);
  }

  function setEditorValue(editor, value) {
    if (editor instanceof HTMLTextAreaElement || editor instanceof HTMLInputElement) {
      const prototype = editor instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
      const descriptor = Object.getOwnPropertyDescriptor(prototype, 'value');
      if (descriptor && descriptor.set) descriptor.set.call(editor, value);
      else editor.value = value;
      try {
        editor.dispatchEvent(new InputEvent('beforeinput', { bubbles: true, inputType: 'insertText', data: value }));
      } catch (_) {}
      editor.dispatchEvent(new Event('input', { bubbles: true }));
      editor.dispatchEvent(new Event('change', { bubbles: true }));
      editor.dispatchEvent(new Event('keyup', { bubbles: true }));
      return;
    }
    editor.focus();
    editor.textContent = value;
    try {
      editor.dispatchEvent(new InputEvent('input', { bubbles: true, inputType: 'insertText', data: value }));
    } catch (_) {
      editor.dispatchEvent(new Event('input', { bubbles: true }));
    }
  }

  function findSubmitButton(editor) {
    let scope = editor.closest('form,[role="dialog"],[data-testid*="comment"]') || editor.parentElement;
    for (let depth = 0; depth < 5 && scope; depth += 1, scope = scope.parentElement) {
      const button = Array.from(scope.querySelectorAll('button,[role="button"]')).find((element) => {
        const text = accessibleText(element);
        const isSubmit = element instanceof HTMLButtonElement && element.type === 'submit';
        return isVisible(element) && !element.disabled && (isSubmit || /送信|投稿|コメントする/.test(text)) && !/キャンセル|閉じる/.test(text);
      });
      if (button) return button;
    }
    return null;
  }

  function editorIsEmpty(editor) {
    return !String('value' in editor ? editor.value : editor.textContent || '').trim();
  }

  async function performCommentThroughUi(comment, replyTarget) {
    let editor = null;
    if (replyTarget) {
      const target = await findTargetRowQuickly(replyTarget);
      if (!target || !target.replyButton) {
        return { ok: false, code: 'reply_target_missing', message: '返信先のコメントを確認できませんでした。note画面で送信してください。' };
      }
      target.replyButton.scrollIntoView({ block: 'center', behavior: 'auto' });
      target.replyButton.click();
      editor = await waitFor(() => findCommentEditor(target.card), 6000);
    } else {
      editor = findCommentEditor();
      if (!editor) {
        const trigger = await waitFor(findCommentTrigger, 8000);
        if (trigger) {
          trigger.scrollIntoView({ block: 'center', behavior: 'auto' });
          trigger.click();
        }
        editor = await waitFor(findCommentEditor, 6000);
      }
      if (!editor) {
        const composer = findCommentComposerTrigger();
        if (composer) {
          composer.scrollIntoView({ block: 'center', behavior: 'auto' });
          composer.click();
          editor = await waitFor(findCommentEditor, 5000);
        }
      }
    }
    if (!editor) {
      return { ok: false, code: 'comment_editor_missing', message: 'コメント入力欄を確認できませんでした。note画面で送信してください。' };
    }

    editor.scrollIntoView({ block: 'center', behavior: 'auto' });
    editor.focus();
    setEditorValue(editor, comment);
    const filled = await waitFor(() => editorIsEmpty(editor) ? null : editor, 2500);
    if (!filled) {
      return { ok: false, code: 'comment_fill_failed', message: 'コメントを入力できませんでした。note画面で送信してください。' };
    }
    const submit = await waitFor(() => findSubmitButton(editor), 6000);
    if (!submit) {
      return { ok: false, code: 'comment_submit_missing', message: '送信ボタンを確認できませんでした。note画面で送信してください。' };
    }
    submit.scrollIntoView({ block: 'center', behavior: 'auto' });
    submit.click();
    const sent = await waitFor(() => {
      if (editorIsEmpty(editor)) return true;
      const bodies = Array.from(document.querySelectorAll('.m-foldableText p,p.whitespace-pre-line'));
      return bodies.some((body) => compactText(body.textContent) === compactText(comment));
    }, 10000);
    if (!sent) {
      return { ok: false, code: 'comment_result_unknown', message: '送信結果を確認できませんでした。開いたnote画面で内容を確認してください。' };
    }
    return { ok: true, action: 'comment', verified: true, source: 'note_comment_ui' };
  }

  async function performComment(comment, replyTarget, mode) {
    const login = await currentUserState();
    if (login === false) {
      return { ok: false, code: 'login_required', message: 'Firefoxでnoteへログインしてください。' };
    }
    if (mode === 'ui_only') {
      await waitFor(() => document.visibilityState === 'visible' ? true : null, 5000);
      return performCommentThroughUi(comment, replyTarget);
    }
    const direct = await performDirectComment(comment, replyTarget);
    if (direct && direct.ok) return direct;
    if (direct && (direct.code === 'login_required' || direct.code === 'comment_acknowledgement')) return direct;
    if (mode === 'direct_only') return direct;
    const fallback = await performCommentThroughUi(comment, replyTarget);
    return fallback || direct;
  }

  async function performNoteAction(operation) {
    if (!operation || !operation.id || processedOperations.has(operation.id)) {
      return { ok: false, code: 'duplicate', message: '同じ操作の再送信を止めました。' };
    }
    if (operation.action === 'account') {
      processedOperations.add(operation.id);
      return performAccount();
    }
    const currentKey = (location.pathname.match(/\/n\/([a-zA-Z0-9_-]+)/) || [])[1] || '';
    if (!currentKey || currentKey !== operation.articleKey) {
      return { ok: false, code: 'wrong_article', message: '対象の記事を確認できませんでした。' };
    }

    processedOperations.add(operation.id);
    if (processedOperations.size > 100) processedOperations.clear();
    if (operation.action === 'status') return performStatus();
    if (operation.action === 'comments') return performComments();
    if (operation.action === 'magazines') return performMagazines();
    if (operation.action === 'magazine_add') return performMagazineAdd(operation.magazineTarget || null);
    if (operation.action === 'like') return performLike();
    if (operation.action === 'follow') return performFollow();
    if (operation.action === 'comment') return performComment(String(operation.comment || '').trim(), operation.replyTarget || null, String(operation.commentMode || ''));
    if (operation.action === 'comment_like') return performCommentLike(operation.replyTarget || null);
    return { ok: false, code: 'unknown_action', message: '未対応の操作です。' };
  }

  browser.runtime.onMessage.addListener((message) => {
    if (!message || message.type !== 'NERO_NOTE_ACTION') return undefined;
    return performNoteAction(message.operation);
  });

  globalThis.NeroNoteBridgeTest = {
    accessibleText,
    isLiked,
    isFollowing,
    findLikeButton,
    findFollowButton,
    findCommentTrigger,
    findCommentRows,
    findCommentLikeButton,
    isCommentLiked,
    findThreadExpandButtons,
    findCommentListMore,
    expandAllComments,
    findTargetRowQuickly,
    findCommentEditor,
    performCommentThroughUi,
    setEditorValue,
    findSubmitButton,
    noteClientCode,
    noteCommentAst,
    performDirectComment,
    performDirectCommentLike,
    performNoteAction,
    performStatus,
    performComments,
    findArticleSaveButton,
    findMagazinePanel,
    collectMagazineRows,
    publicMagazineRows,
    findMagazineTarget,
    performMagazines,
    performMagazineAdd,
    performAccount,
    performCommentLike,
    performFollow
  };
})();
