'use strict';

(function initializeReaderBridge() {
  const EXTENSION_HOST_ID = 'nero-firefox-bridge-ui';
  let shadow = null;
  let toastTimer = null;
  let currentCommentUrl = '';
  let currentReplyTarget = null;
  let currentCommentSource = '';
  let currentInboxKey = '';
  let currentDraftKey = '';
  let composerPreferredHeight = 0;
  let composerBaselineHeight = 0;
  let composerDrag = null;
  let currentThreadUrl = '';
  let commentsRequest = 0;
  let statusTimer = null;
  let statusRequest = 0;
  let lastStatusUrl = '';
  let inboxRequest = 0;
  let inboxPage = 0;
  let inboxOwner = '';
  let inboxItems = [];
  let inboxCache = null;
  let inboxScanning = false;
  let engagementRequest = 0;
  let engagementScanning = false;
  let currentCreatorStatus = null;
  const commentDrafts = new Map();
  const INBOX_OWNER_STORAGE = 'nero.reader.inboxOwner.v1';
  const INBOX_CACHE_PREFIX = 'nero.reader.inboxCache.v3.';
  const INBOX_CACHE_TTL = 7 * 24 * 60 * 60 * 1000;
  const ENGAGEMENT_CACHE_PREFIX = 'nero.reader.engagementCache.v1.';
  const ENGAGEMENT_WINDOW_MS = 7 * 24 * 60 * 60 * 1000;
  const ENGAGEMENT_RECENT_REFRESH_MS = 24 * 60 * 60 * 1000;
  const ENGAGEMENT_STALE_MS = 7 * 24 * 60 * 60 * 1000;
  const READER_ORIGIN = 'https://cosmos-invest.github.io';

  function createInterface() {
    let host = document.getElementById(EXTENSION_HOST_ID);
    if (host) return host.shadowRoot;
    host = document.createElement('div');
    host.id = EXTENSION_HOST_ID;
    host.style.cssText = 'position:fixed;inset:0;pointer-events:none;z-index:2147483647';
    shadow = host.attachShadow({ mode: 'closed' });
    shadow.innerHTML = `
      <style>
        *{box-sizing:border-box;font-family:Inter,"Noto Sans JP",system-ui,sans-serif}
        .toast{position:fixed;left:50%;top:18px;transform:translate(-50%,-12px);max-width:calc(100vw - 32px);padding:11px 15px;border-radius:999px;background:#28222b;color:#fff;font-size:13px;font-weight:700;box-shadow:0 10px 30px rgba(0,0,0,.24);opacity:0;transition:.18s;pointer-events:none;text-align:center}
        .toast.show{opacity:1;transform:translate(-50%,0)}
        .overlay{position:fixed;inset:0;background:rgba(30,22,30,.48);display:none;align-items:flex-end;justify-content:center;pointer-events:auto}
        .overlay.open{display:flex}
        .dialog{width:min(640px,100%);background:#fff;border-radius:26px 26px 0 0;padding:22px 18px max(24px,env(safe-area-inset-bottom));box-shadow:0 -20px 60px rgba(0,0,0,.2)}
        .thread-dialog{max-height:88dvh;display:flex;flex-direction:column;padding-left:14px;padding-right:14px}
        .thread-head{display:flex;align-items:center;gap:10px;margin-bottom:10px}.thread-head h2{flex:1;margin:0}.close{border:0;background:#f1edf1;color:#625962;width:40px;height:40px;border-radius:50%;font-size:20px}
        .new-comment{border:0;background:#7757c8;color:#fff;border-radius:14px;min-height:46px;padding:0 16px;font-weight:900;margin:0 0 12px}
        .thread-list{overflow:auto;min-height:120px;padding:0 2px 8px}.thread-loading,.thread-empty{padding:30px 12px;text-align:center;color:#827781;font-size:14px}
        .thread-row{border-top:1px solid #eadfe8;padding:14px 8px 12px}.thread-row.depth-1{margin-left:28px;border-left:3px solid #e1d6f5;padding-left:12px;background:#fbf9ff}
        .thread-meta{display:flex;align-items:center;gap:8px}.thread-avatar{width:31px;height:31px;border-radius:50%;object-fit:cover;background:#f1edf1}.thread-author{font-size:13px;font-weight:900;color:#28222b;text-decoration:none;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.thread-author:focus-visible{outline:2px solid #7757c8;outline-offset:2px;border-radius:3px}.thread-time{margin-left:auto;color:#827781;font-size:11px;white-space:nowrap}
        .thread-body{margin:8px 0 10px;color:#3b343d;font-size:14px;line-height:1.65;white-space:pre-wrap;overflow-wrap:anywhere}.thread-actions{display:flex;gap:8px;flex-wrap:wrap}.reply,.thread-like{border:0;border-radius:999px;padding:8px 13px;font-size:12px;font-weight:900}.reply{background:#f1ecff;color:#59389d}.thread-like{background:#ffe5ef;color:#bd245f}.thread-like:disabled{opacity:.62}
        .inbox-dialog{height:min(92dvh,820px);max-height:92dvh;display:flex;flex-direction:column;padding-left:14px;padding-right:14px}
        .inbox-setup{display:grid;grid-template-columns:1fr auto;gap:8px;margin:4px 0 8px}.inbox-setup input{min-width:0;border:1px solid #d8ccd6;border-radius:13px;padding:11px 12px;font-size:16px}.inbox-setup button,.inbox-more{border:0;background:#28222b;color:#fff;border-radius:13px;padding:0 15px;font-weight:900}
        .inbox-note{margin:0 2px 10px;color:#746a73;font-size:12px;line-height:1.55}.inbox-progress{min-height:20px;margin:0 2px 7px;color:#7757c8;font-size:12px;font-weight:800}
        .inbox-list{overflow:auto;min-height:120px;flex:1;padding:0 2px 8px}.inbox-card{border:1px solid #eadfe8;border-radius:17px;padding:13px;margin:0 0 10px;background:#fff}.inbox-article{display:block;color:#7757c8;font-size:12px;font-weight:800;text-decoration:none;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.inbox-actions{display:grid;grid-template-columns:1fr 1fr;gap:8px}.inbox-actions button{min-height:42px;border:0;border-radius:12px;font-size:13px;font-weight:900}.comment-like{background:#ffe5ef;color:#bd245f}.inbox-reply{background:#eee8ff;color:#59389d}.inbox-more{min-height:46px;margin-top:8px}.inbox-more:disabled,.inbox-setup button:disabled{opacity:.45}
        h2{font-size:20px;margin:0 0 8px;color:#28222b}.help{margin:0 0 13px;color:#746a73;font-size:13px;line-height:1.6}
        .composer{position:fixed;left:0;right:0;top:0;height:var(--composer-viewport-height,100dvh);display:none;align-items:flex-end;justify-content:center;padding:0 7px calc(7px + env(safe-area-inset-bottom));pointer-events:none}
        .composer.open{display:flex}.composer .dialog{pointer-events:auto;width:min(640px,100%);height:var(--composer-height,68dvh);max-height:calc(var(--composer-viewport-height,100dvh) - 8px);overflow:hidden;display:flex;flex-direction:column;border:1px solid #eadfe8;border-radius:22px 22px 15px 15px;padding:0 13px 13px;background:rgba(255,255,255,.98);box-shadow:0 15px 55px rgba(30,22,30,.28);backdrop-filter:blur(18px);transition:height .18s ease,border-radius .18s ease}
        .composer.dragging .dialog{transition:none}.composer.keyboard-open{padding:0}.composer.keyboard-open .dialog{width:100%;height:var(--composer-viewport-height,100dvh);max-height:var(--composer-viewport-height,100dvh);border:0;border-radius:0;padding-bottom:max(10px,env(safe-area-inset-bottom));box-shadow:none}
        .composer-handle{flex:0 0 25px;width:100%;border:0;background:transparent;padding:0;display:flex;align-items:center;justify-content:center;touch-action:none;cursor:ns-resize}.composer-handle::before{content:'';width:46px;height:5px;border-radius:999px;background:#c8bec7}.composer.keyboard-open .composer-handle::before{background:#ded6dd}
        .composer-head{flex:0 0 auto;display:flex;align-items:center;gap:10px;min-height:40px}.composer-head h2{flex:1;margin:0;font-size:18px;line-height:1.35}.composer-head .close{width:36px;height:36px;font-size:18px}
        .composer-context{flex:1 1 auto;min-height:72px;overflow:auto;margin:8px 0 10px;padding:11px 13px;border-left:4px solid #bba8e8;border-radius:12px;background:#f7f3ff;color:#3b343d}.composer-context.article-only{flex:0 0 auto;min-height:0}.composer-context span{display:block;color:#7757c8;font-size:11px;font-weight:900}.composer-context strong{display:block;margin-top:3px;font-size:14px;line-height:1.5;overflow-wrap:anywhere}.composer-context small{display:block;margin-top:2px;color:#827781;font-size:11px;line-height:1.45}.composer-context p{margin:7px 0 0;font-size:14px;line-height:1.65;white-space:pre-wrap;overflow-wrap:anywhere}
        .composer textarea{flex:0 0 auto;display:block;width:100%;height:112px;min-height:92px;resize:none;border:1px solid #cbbdcc;border-radius:13px;padding:11px 12px;font-size:16px;line-height:1.6;color:#28222b;background:#fff}
        .composer-footer{flex:0 0 auto;display:grid;grid-template-columns:auto auto minmax(150px,1fr);align-items:center;gap:8px;margin-top:8px}.discard{min-height:42px;border:0;background:#f1edf1;color:#625962;border-radius:12px;padding:0 12px;font-size:12px;font-weight:800}.count{color:#827781;font-size:11px;white-space:nowrap}.send{min-height:48px;border:0;border-radius:14px;background:#7757c8;color:#fff;font-size:15px;font-weight:900}.send:disabled{opacity:.45}
        @media(max-width:430px){.composer{padding-left:5px;padding-right:5px}.composer .dialog{border-radius:20px 20px 12px 12px;padding-left:11px;padding-right:11px}.composer-head h2{font-size:17px}.composer-context{margin-top:6px;padding:10px 11px}.composer-context strong{font-size:13px}.composer-context p{font-size:13.5px}.composer textarea{height:104px}.composer-footer{grid-template-columns:auto auto minmax(130px,1fr);gap:6px}.discard{padding:0 10px}}
      </style>
      <div class="toast" id="toast" role="status"></div>
      <div class="overlay" id="threadOverlay" role="dialog" aria-modal="true" aria-labelledby="threadTitle">
        <section class="dialog thread-dialog">
          <div class="thread-head"><h2 id="threadTitle">コメント</h2><button class="close" id="closeThreads" type="button" aria-label="閉じる">×</button></div>
          <button class="new-comment" id="newComment" type="button">新しくコメントする</button>
          <div class="thread-list" id="threadList"><div class="thread-loading">コメントを読み込んでいます…</div></div>
        </section>
      </div>
      <div class="overlay" id="inboxOverlay" role="dialog" aria-modal="true" aria-labelledby="inboxTitle">
        <section class="dialog inbox-dialog">
          <div class="thread-head"><h2 id="inboxTitle">未対応コメント</h2><button class="close" id="closeInbox" type="button" aria-label="閉じる">×</button></div>
          <p class="inbox-note">自分の全記事を対象に、返信の返信までたどります。赤いハート（自分のスキ）も自分からの返信もないコメントだけを表示します。初回確認後は差分だけを再取得します。</p>
          <div class="inbox-setup"><input id="inboxOwner" autocomplete="off" placeholder="自分のnoteユーザー名"><button id="scanInbox" type="button">全記事を確認</button></div>
          <div class="inbox-progress" id="inboxProgress"></div>
          <div class="inbox-list" id="inboxList"><div class="thread-empty">「全記事を確認」を押すと、過去記事まで順番に調べます。</div></div>
          <button class="inbox-more" id="moreInbox" type="button" hidden>再開する</button>
        </section>
      </div>
      <div class="composer" id="composer" role="dialog" aria-modal="false" aria-labelledby="commentTitle">
        <section class="dialog">
          <button class="composer-handle" id="composerHandle" type="button" aria-label="コメント欄の高さを上下に変更"></button>
          <div class="composer-head"><h2 id="commentTitle">コメントを送る</h2><button class="close" id="closeComposer" type="button" aria-label="下書きを残して閉じる">×</button></div>
          <div class="composer-context" id="commentContext"><span id="commentContextLabel">この記事にコメント</span><strong id="commentContextTitle"></strong><small id="commentArticleTitle" hidden></small><p id="commentContextBody" hidden></p></div>
          <textarea id="commentText" maxlength="500" placeholder="記事を読んで感じたことを書いてください"></textarea>
          <div class="composer-footer"><button class="discard" id="discardDraft" type="button">破棄</button><span class="count" id="count">0 / 500</span><button class="send" id="send" type="button">送信する</button></div>
        </section>
      </div>`;
    document.documentElement.appendChild(host);

    const textarea = shadow.getElementById('commentText');
    textarea.addEventListener('input', () => {
      shadow.getElementById('count').textContent = textarea.value.length + ' / 500';
      if (currentDraftKey) commentDrafts.set(currentDraftKey, textarea.value);
    });
    shadow.getElementById('closeComposer').addEventListener('click', closeComment);
    shadow.getElementById('discardDraft').addEventListener('click', discardCommentDraft);
    const composerHandle = shadow.getElementById('composerHandle');
    composerHandle.addEventListener('pointerdown', startComposerResize);
    composerHandle.addEventListener('pointermove', moveComposerResize);
    composerHandle.addEventListener('pointerup', endComposerResize);
    composerHandle.addEventListener('pointercancel', endComposerResize);
    shadow.getElementById('send').addEventListener('click', submitComment);
    shadow.getElementById('closeThreads').addEventListener('click', closeThreads);
    shadow.getElementById('threadOverlay').addEventListener('click', (event) => {
      if (event.target === shadow.getElementById('threadOverlay')) closeThreads();
    });
    shadow.getElementById('newComment').addEventListener('click', () => openComment(currentThreadUrl, null));
    shadow.getElementById('closeInbox').addEventListener('click', closeInbox);
    shadow.getElementById('inboxOverlay').addEventListener('click', (event) => {
      if (event.target === shadow.getElementById('inboxOverlay')) closeInbox();
    });
    shadow.getElementById('scanInbox').addEventListener('click', () => {
      if (inboxScanning) stopInboxScan();
      else startInboxScan();
    });
    shadow.getElementById('moreInbox').addEventListener('click', startInboxScan);
    if (window.visualViewport) {
      window.visualViewport.addEventListener('resize', syncComposerViewport);
      window.visualViewport.addEventListener('scroll', syncComposerViewport);
    }
    window.addEventListener('resize', syncComposerViewport);
    return shadow;
  }

  function showToast(message, duration) {
    createInterface();
    const toast = shadow.getElementById('toast');
    toast.textContent = message;
    toast.classList.add('show');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => toast.classList.remove('show'), duration || 2600);
  }

  function commentDraftKey(articleUrl, replyTarget) {
    const target = replyTarget && (replyTarget.commentKey || replyTarget.key || replyTarget.rootKey || replyTarget.authorUrlname);
    return String(articleUrl || '') + '::' + String(target || 'new');
  }

  function showCommentArticle(articleUrl) {
    const match = String(articleUrl || '').match(/note\.com\/[^/]+\/n\/([a-zA-Z0-9_-]+)/i);
    if (!match) return;
    document.documentElement.dataset.neroOpenArticleKey = match[1];
    document.documentElement.dataset.neroOpenArticleUrl = articleUrl;
    document.dispatchEvent(new Event('nero-open-article'));
  }

  function currentViewportHeight() {
    return Math.max(320, Math.round(window.visualViewport ? window.visualViewport.height : window.innerHeight));
  }

  function composerHeightBounds(viewportHeight) {
    const maximum = Math.max(280, viewportHeight - 8);
    const minimum = Math.min(maximum, Math.max(320, Math.round(viewportHeight * 0.4)));
    return { minimum, maximum };
  }

  function applyComposerHeight(height, remember) {
    if (!shadow) return;
    const viewportHeight = currentViewportHeight();
    const bounds = composerHeightBounds(viewportHeight);
    const next = Math.max(bounds.minimum, Math.min(bounds.maximum, Math.round(height)));
    shadow.getElementById('composer').style.setProperty('--composer-height', next + 'px');
    document.documentElement.style.setProperty('--nero-composer-height', next + 'px');
    if (remember) composerPreferredHeight = next;
  }

  function syncComposerViewport() {
    if (!shadow) return;
    const composer = shadow.getElementById('composer');
    const viewportHeight = currentViewportHeight();
    composer.style.setProperty('--composer-viewport-height', viewportHeight + 'px');
    if (!composer.classList.contains('open')) return;
    const threshold = Math.max(120, Math.round(composerBaselineHeight * 0.16));
    const keyboardOpen = composerBaselineHeight > 0 && viewportHeight < composerBaselineHeight - threshold;
    composer.classList.toggle('keyboard-open', keyboardOpen);
    if (keyboardOpen) {
      applyComposerHeight(viewportHeight, false);
      return;
    }
    composerBaselineHeight = Math.max(composerBaselineHeight, viewportHeight);
    if (!composerPreferredHeight) composerPreferredHeight = Math.round(viewportHeight * 0.68);
    applyComposerHeight(composerPreferredHeight, false);
  }

  function startComposerResize(event) {
    if (!shadow || event.button > 0) return;
    const composer = shadow.getElementById('composer');
    if (composer.classList.contains('keyboard-open')) {
      shadow.getElementById('commentText').blur();
      return;
    }
    const panel = composer.querySelector('.dialog');
    composerDrag = {
      pointerId: event.pointerId,
      startY: event.clientY,
      startHeight: panel.getBoundingClientRect().height
    };
    composer.classList.add('dragging');
    event.currentTarget.setPointerCapture(event.pointerId);
    event.preventDefault();
  }

  function moveComposerResize(event) {
    if (!composerDrag || event.pointerId !== composerDrag.pointerId) return;
    const nextHeight = composerDrag.startHeight + composerDrag.startY - event.clientY;
    applyComposerHeight(nextHeight, true);
    event.preventDefault();
  }

  function endComposerResize(event) {
    if (!composerDrag || event.pointerId !== composerDrag.pointerId) return;
    const composer = shadow.getElementById('composer');
    composer.classList.remove('dragging');
    try { event.currentTarget.releasePointerCapture(event.pointerId); } catch (_) {}
    composerDrag = null;
  }

  function discardCommentDraft() {
    if (!shadow) return;
    if (currentDraftKey) commentDrafts.delete(currentDraftKey);
    const textarea = shadow.getElementById('commentText');
    textarea.value = '';
    shadow.getElementById('count').textContent = '0 / 500';
    textarea.focus();
  }

  function commentAuthorLabel(replyTarget) {
    const urlname = String(replyTarget && replyTarget.authorUrlname || '').trim();
    const displayName = String(replyTarget && replyTarget.authorName || '').replace(/\s+/g, ' ').trim();
    const userId = urlname ? '@' + urlname : '@noteユーザー';
    if (!displayName || displayName === urlname || displayName === userId) return userId;
    return displayName + '（' + userId + '）';
  }

  function openComment(articleUrl, replyTarget, source, inboxKey, articleTitle) {
    createInterface();
    currentCommentUrl = articleUrl;
    currentReplyTarget = replyTarget || null;
    currentCommentSource = source || 'thread';
    currentInboxKey = inboxKey || '';
    currentDraftKey = commentDraftKey(articleUrl, replyTarget);
    shadow.getElementById('threadOverlay').classList.remove('open');
    shadow.getElementById('inboxOverlay').classList.remove('open');
    showCommentArticle(articleUrl);
    shadow.getElementById('commentTitle').textContent = replyTarget ? '返信' : 'コメント';
    const contextLabel = shadow.getElementById('commentContextLabel');
    const contextTitle = shadow.getElementById('commentContextTitle');
    const articleTitleElement = shadow.getElementById('commentArticleTitle');
    const contextBody = shadow.getElementById('commentContextBody');
    const context = shadow.getElementById('commentContext');
    contextLabel.textContent = replyTarget ? '返信元' : '記事';
    const visibleArticleTitle = articleTitle || document.getElementById('articleTitle')?.textContent || '表示中の記事';
    contextTitle.textContent = replyTarget
      ? commentAuthorLabel(replyTarget)
      : visibleArticleTitle;
    articleTitleElement.textContent = visibleArticleTitle;
    articleTitleElement.hidden = !replyTarget;
    contextBody.textContent = replyTarget ? String(replyTarget.body || '') : '';
    contextBody.hidden = !replyTarget || !replyTarget.body;
    context.classList.toggle('article-only', !replyTarget);
    const textarea = shadow.getElementById('commentText');
    textarea.value = commentDrafts.get(currentDraftKey) || '';
    shadow.getElementById('count').textContent = textarea.value.length + ' / 500';
    const composer = shadow.getElementById('composer');
    composerBaselineHeight = currentViewportHeight();
    composer.classList.add('open');
    document.documentElement.dataset.neroComposer = 'open';
    syncComposerViewport();
    setTimeout(() => {
      textarea.focus();
      setTimeout(syncComposerViewport, 180);
    }, 50);
  }

  function closeComment() {
    if (!shadow) return;
    const composer = shadow.getElementById('composer');
    composer.classList.remove('open', 'keyboard-open', 'dragging');
    delete document.documentElement.dataset.neroComposer;
    document.documentElement.style.removeProperty('--nero-composer-height');
    composerBaselineHeight = 0;
    composerDrag = null;
    currentCommentUrl = '';
    currentReplyTarget = null;
    currentCommentSource = '';
    currentInboxKey = '';
    currentDraftKey = '';
  }

  function closeThreads() {
    if (!shadow) return;
    shadow.getElementById('threadOverlay').classList.remove('open');
    currentThreadUrl = '';
    commentsRequest += 1;
  }

  function normalizeUrlname(value) {
    return String(value || '').trim().replace(/^https?:\/\/(?:www\.)?note\.com\//i, '').replace(/^@/, '').split(/[/?#]/)[0].replace(/[^a-zA-Z0-9_-]/g, '').slice(0, 80);
  }

  function inboxFeedUrl(page, owner) {
    return READER_ORIGIN + '/api/mixed-feed?limit=10&page=' + page + '&creators=' + encodeURIComponent(owner);
  }

  function closeInbox() {
    if (!shadow) return;
    shadow.getElementById('inboxOverlay').classList.remove('open');
  }

  function inboxCacheKey(owner) {
    return INBOX_CACHE_PREFIX + normalizeUrlname(owner);
  }

  async function loadInboxCache(owner) {
    const fallback = { version: 3, owner, articles: {}, updatedAt: 0, completedAt: 0 };
    try {
      const stored = await browser.storage.local.get(inboxCacheKey(owner));
      const value = stored && stored[inboxCacheKey(owner)];
      if (value && value.version === 3 && value.owner === owner && value.articles && typeof value.articles === 'object') return value;
    } catch (_) {}
    return fallback;
  }

  async function saveInboxCache() {
    if (!inboxCache || !inboxOwner) return;
    inboxCache.updatedAt = Date.now();
    try {
      await browser.storage.local.set({ [inboxCacheKey(inboxOwner)]: inboxCache });
    } catch (_) {}
  }

  function restoreInboxItemsFromCache() {
    const restored = [];
    const entries = inboxCache && inboxCache.articles ? Object.values(inboxCache.articles) : [];
    entries.forEach((entry) => {
      (Array.isArray(entry.unresolved) ? entry.unresolved : []).forEach((comment) => {
        const key = inboxKey(entry.articleUrl, comment);
        restored.push({ key, articleUrl: entry.articleUrl, articleTitle: entry.articleTitle, comment });
      });
    });
    inboxItems = restored;
  }

  function stopInboxScan() {
    if (!inboxScanning) return;
    inboxRequest += 1;
    inboxScanning = false;
    const scan = shadow.getElementById('scanInbox');
    scan.textContent = '再開する';
    shadow.getElementById('inboxProgress').textContent = '確認を中断しました。途中結果は保存済みです。';
  }

  function inboxTarget(comment) {
    return {
      key: comment.rootKey || comment.key || '',
      commentKey: comment.key || '',
      rootKey: comment.rootKey || comment.key || '',
      authorUrlname: comment.authorUrlname,
      authorName: comment.authorName || '',
      body: comment.body,
      publishedAt: comment.publishedAt || '',
      depth: comment.depth ? 1 : 0,
      rootAuthorUrlname: comment.rootAuthorUrlname || (comment.depth ? '' : comment.authorUrlname),
      rootBody: comment.rootBody || (comment.depth ? '' : comment.body),
      liked: comment.liked === true
    };
  }

  function unresolvedComments(comments, owner) {
    const groups = new Map();
    (comments || []).forEach((comment, index) => {
      const thread = Number.isFinite(Number(comment.threadIndex)) ? Number(comment.threadIndex) : index;
      if (!groups.has(thread)) groups.set(thread, []);
      groups.get(thread).push(comment);
    });
    const unresolved = [];
    groups.forEach((thread) => {
      let lastOwner = -1;
      thread.forEach((comment, index) => {
        if (comment.authorUrlname === owner) lastOwner = index;
      });
      // Every reader comment after the creator's latest reply needs its own
      // creator-like or a later creator reply. The numeric like count and the
      // current viewer's generic like state are never used here.
      thread.forEach((comment, index) => {
        if (index > lastOwner && comment.authorUrlname !== owner && comment.creatorLiked !== true) unresolved.push(comment);
      });
    });
    return unresolved;
  }

  function inboxKey(articleUrl, comment) {
    return [articleUrl, comment.authorUrlname, comment.publishedAt || '', comment.body].join('|');
  }

  function renderInbox() {
    const list = shadow.getElementById('inboxList');
    list.textContent = '';
    if (!inboxItems.length) {
      const empty = document.createElement('div');
      empty.className = 'thread-empty';
      empty.textContent = inboxPage ? '現在、未対応のコメントは見つかりませんでした。' : '「全記事を確認」を押すと、過去記事まで順番に調べます。';
      list.appendChild(empty);
      return;
    }
    inboxItems.forEach((item) => {
      const card = document.createElement('article');
      card.className = 'inbox-card';
      card.dataset.inboxKey = item.key;
      const article = document.createElement('a');
      article.className = 'inbox-article';
      article.href = item.articleUrl;
      article.target = '_blank';
      article.rel = 'noopener noreferrer';
      article.textContent = item.articleTitle || '記事を開く';
      const meta = document.createElement('div');
      meta.className = 'thread-meta';
      const avatar = document.createElement('img');
      avatar.className = 'thread-avatar';
      avatar.alt = '';
      if (item.comment.avatar) avatar.src = item.comment.avatar;
      const author = document.createElement('a');
      author.className = 'thread-author';
      author.href = 'https://note.com/' + encodeURIComponent(item.comment.authorUrlname);
      author.target = '_blank';
      author.rel = 'noopener noreferrer';
      author.textContent = item.comment.authorName || '@' + item.comment.authorUrlname;
      const time = document.createElement('time');
      time.className = 'thread-time';
      time.textContent = threadTime(item.comment.publishedAt);
      meta.append(avatar, author, time);
      const body = document.createElement('p');
      body.className = 'thread-body';
      body.textContent = item.comment.body;
      const actions = document.createElement('div');
      actions.className = 'inbox-actions';
      const like = document.createElement('button');
      like.className = 'comment-like';
      like.type = 'button';
      like.textContent = '♡ スキで対応';
      like.addEventListener('click', () => handleInboxLike(item, like));
      const reply = document.createElement('button');
      reply.className = 'inbox-reply';
      reply.type = 'button';
      reply.textContent = '返信する';
      reply.addEventListener('click', () => openComment(item.articleUrl, inboxTarget(item.comment), 'inbox', item.key, item.articleTitle));
      actions.append(like, reply);
      card.append(article, meta, body, actions);
      list.appendChild(card);
    });
  }

  function removeInboxItem(key) {
    inboxItems = inboxItems.filter((item) => item.key !== key);
    if (inboxCache && inboxCache.articles) {
      Object.values(inboxCache.articles).forEach((entry) => {
        entry.unresolved = (Array.isArray(entry.unresolved) ? entry.unresolved : []).filter((comment) => inboxKey(entry.articleUrl, comment) !== key);
      });
      saveInboxCache();
    }
    renderInbox();
    shadow.getElementById('inboxOverlay').classList.add('open');
  }

  async function handleInboxLike(item, button) {
    button.disabled = true;
    const ok = await sendAction('comment_like', item.articleUrl, '', inboxTarget(item.comment), { advance: false });
    if (ok) removeInboxItem(item.key);
    else button.disabled = false;
  }

  async function openInbox() {
    createInterface();
    inboxOwner = normalizeUrlname(localStorage.getItem(INBOX_OWNER_STORAGE) || '');
    shadow.getElementById('inboxOwner').value = inboxOwner;
    shadow.getElementById('inboxOverlay').classList.add('open');
    if (inboxOwner && !inboxScanning) {
      inboxCache = await loadInboxCache(inboxOwner);
      restoreInboxItemsFromCache();
      if (inboxCache.completedAt) {
        const checked = new Date(inboxCache.completedAt);
        shadow.getElementById('inboxProgress').textContent = '前回確認: ' + checked.toLocaleString('ja-JP') + ' ／ 未対応 ' + inboxItems.length + '件';
        shadow.getElementById('scanInbox').textContent = '差分を再確認';
      }
    } else if (inboxScanning) {
      shadow.getElementById('scanInbox').textContent = '中断する';
    }
    renderInbox();
  }

  async function startInboxScan() {
    let owner = normalizeUrlname(shadow.getElementById('inboxOwner').value);
    if (!owner) {
      shadow.getElementById('inboxProgress').textContent = 'Firefoxでログイン中のnoteアカウントを確認しています…';
      try {
        const account = await browser.runtime.sendMessage({ type: 'NERO_READER_ACTION', action: 'account' });
        if (account && account.ok) {
          owner = normalizeUrlname(account.urlname);
          shadow.getElementById('inboxOwner').value = owner;
        }
      } catch (_) {}
    }
    if (!owner) {
      shadow.getElementById('inboxProgress').textContent = '自動確認できませんでした。自分のnoteユーザー名を入力してください。';
      return;
    }
    inboxOwner = owner;
    localStorage.setItem(INBOX_OWNER_STORAGE, owner);
    inboxCache = await loadInboxCache(owner);
    restoreInboxItemsFromCache();
    inboxPage = 0;
    renderInbox();
    await scanAllInboxArticles();
  }

  function elapsedEstimate(startedAt, completed, total) {
    if (!completed || completed >= total) return '';
    const remainingMs = (Date.now() - startedAt) / completed * (total - completed);
    const seconds = Math.max(1, Math.round(remainingMs / 1000));
    return seconds < 60 ? '／残り約' + seconds + '秒' : '／残り約' + Math.ceil(seconds / 60) + '分';
  }

  async function scanAllInboxArticles() {
    if (!inboxOwner) return startInboxScan();
    const request = ++inboxRequest;
    const scan = shadow.getElementById('scanInbox');
    const more = shadow.getElementById('moreInbox');
    inboxScanning = true;
    scan.disabled = false;
    scan.textContent = '中断する';
    more.hidden = true;
    const allArticles = [];
    const seen = new Set();
    let page = 1;
    shadow.getElementById('inboxProgress').textContent = '全記事の一覧を取得しています…';
    try {
      for (; page <= 1000; page += 1) {
        if (request !== inboxRequest) return;
        const response = await fetch(inboxFeedUrl(page, inboxOwner));
        const payload = await response.json();
        if (!response.ok) throw new Error('記事一覧を確認できませんでした。');
        const rows = Array.isArray(payload.items) ? payload.items : [];
        let added = 0;
        rows.forEach((item) => {
          if (!item.url || seen.has(item.url)) return;
          seen.add(item.url);
          allArticles.push(item);
          added += 1;
        });
        inboxPage = page;
        shadow.getElementById('inboxProgress').textContent = '全記事の一覧を取得中: ' + allArticles.length + '記事';
        if (rows.length < 10 || added === 0) break;
      }

      const now = Date.now();
      const articleCache = inboxCache.articles || (inboxCache.articles = {});
      const toCheck = [];
      allArticles.forEach((item) => {
        const count = Number(item.commentCount || 0);
        const cached = articleCache[item.url];
        if (!count) {
          articleCache[item.url] = { articleUrl: item.url, articleTitle: item.name, commentCount: 0, unresolved: [], checkedAt: now };
          return;
        }
        const stale = !cached || now - Number(cached.checkedAt || 0) >= INBOX_CACHE_TTL;
        const changed = !cached || Number(cached.commentCount || 0) !== count;
        const hasPending = cached && Array.isArray(cached.unresolved) && cached.unresolved.length > 0;
        if (stale || changed || hasPending) toCheck.push(item);
      });

      let completed = 0;
      let failed = 0;
      let firstFailure = '';
      let cursor = 0;
      const startedAt = Date.now();
      restoreInboxItemsFromCache();
      renderInbox();
      shadow.getElementById('inboxProgress').textContent = allArticles.length + '記事中、確認が必要な' + toCheck.length + '記事を調べます…';
      async function worker() {
        while (cursor < toCheck.length) {
          const index = cursor;
          cursor += 1;
          const item = toCheck[index];
          if (request !== inboxRequest) return;
          try {
            const result = await browser.runtime.sendMessage({
              type: 'NERO_READER_ACTION',
              action: 'comments',
              articleUrl: item.url,
              summaryOnly: true
            });
            if (!result || !result.ok) {
              failed += 1;
              if (!firstFailure) firstFailure = result && result.message ? result.message : 'コメントを取得できませんでした。';
              continue;
            }
            if (result.viewerUrlname && result.viewerUrlname !== inboxOwner) {
              throw new Error('Firefoxでログイン中のnoteアカウントは @' + result.viewerUrlname + ' です。入力欄を合わせてください。');
            }
            articleCache[item.url] = {
              articleUrl: item.url,
              articleTitle: item.name,
              commentCount: Number(item.commentCount || 0),
              unresolved: unresolvedComments(result.comments, inboxOwner),
              checkedAt: Date.now()
            };
          } catch (error) {
            failed += 1;
            if (!firstFailure) firstFailure = error && error.message ? error.message : 'コメントを取得できませんでした。';
          } finally {
            completed += 1;
            if (request === inboxRequest) {
              restoreInboxItemsFromCache();
              shadow.getElementById('inboxProgress').textContent = 'コメント確認中 ' + completed + ' / ' + toCheck.length + '／未対応 ' + inboxItems.length + '件' + elapsedEstimate(startedAt, completed, toCheck.length);
              renderInbox();
              if (completed % 5 === 0) saveInboxCache();
            }
          }
        }
      }
      const concurrency = Math.min(3, toCheck.length);
      await Promise.all(Array.from({ length: concurrency }, worker));
      if (request !== inboxRequest) return;
      if (failed && failed === toCheck.length && toCheck.length) throw new Error(firstFailure);
      Object.keys(articleCache).forEach((url) => { if (!seen.has(url)) delete articleCache[url]; });
      inboxCache.completedAt = Date.now();
      await saveInboxCache();
      restoreInboxItemsFromCache();
      renderInbox();
      shadow.getElementById('inboxProgress').textContent = '全' + allArticles.length + '記事を確認しました。未対応 ' + inboxItems.length + '件' + (failed ? '（取得失敗 ' + failed + '件）' : '') + (toCheck.length < allArticles.length ? '／差分取得 ' + toCheck.length + '記事' : '');
    } catch (error) {
      if (request === inboxRequest) shadow.getElementById('inboxProgress').textContent = error && error.message ? error.message : '確認できませんでした。';
    } finally {
      if (request === inboxRequest) {
        inboxScanning = false;
        scan.disabled = false;
        scan.textContent = inboxCache && inboxCache.completedAt ? '差分を再確認' : '再開する';
      }
    }
  }

  function engagementCacheKey(owner) {
    return ENGAGEMENT_CACHE_PREFIX + normalizeUrlname(owner);
  }

  async function loadEngagementCache(owner) {
    const fallback = { version: 1, owner, articles: {}, updatedAt: 0, completedAt: 0, cutoffMs: 0 };
    try {
      const key = engagementCacheKey(owner);
      const stored = await browser.storage.local.get(key);
      const value = stored && stored[key];
      if (value && value.version === 1 && value.owner === owner && value.articles && typeof value.articles === 'object') return value;
    } catch (_) {}
    return fallback;
  }

  async function saveEngagementCache(cache) {
    if (!cache || !cache.owner) return;
    cache.updatedAt = Date.now();
    try { await browser.storage.local.set({ [engagementCacheKey(cache.owner)]: cache }); } catch (_) {}
  }

  function publishEngagementProgress(id, message, completed, total) {
    document.documentElement.dataset.neroEngagementProgress = JSON.stringify({
      id,
      message: String(message || ''),
      completed: Number(completed || 0),
      total: Number(total || 0)
    });
    document.dispatchEvent(new Event('nero-engagement-progress'));
  }

  function pruneEngagementRows(rows, cutoffMs) {
    const actionTime = globalThis.NeroEngagementCore && globalThis.NeroEngagementCore.actionTime;
    return (Array.isArray(rows) ? rows : []).filter((row) => actionTime ? actionTime(row) >= cutoffMs : Date.parse(row.createdAt || row.publishedAt || '') >= cutoffMs);
  }

  function engagementNeedsRefresh(cached, currentCount, side, now, cutoffMs) {
    if (!cached) return true;
    const countKey = side + 'Count';
    const checkedKey = side + 'CheckedAt';
    if (Number(cached[countKey] || 0) !== Number(currentCount || 0)) return true;
    const checkedAt = Number(cached[checkedKey] || cached.checkedAt || 0);
    if (!checkedAt || now - checkedAt >= ENGAGEMENT_STALE_MS) return true;
    const rows = pruneEngagementRows(cached[side], cutoffMs);
    return rows.length > 0 && now - checkedAt >= ENGAGEMENT_RECENT_REFRESH_MS;
  }

  async function enumerateOwnerArticles(owner, request, id) {
    if (request !== engagementRequest) throw new Error('確認を中断しました。');
    const response = await browser.runtime.sendMessage({ type: 'NERO_READER_ACTION', action: 'creator_articles', urlname: owner });
    if (!response || !response.ok) throw new Error(response && response.message ? response.message : '記事一覧を取得できませんでした。');
    const articles = [];
    const seen = new Set();
    (Array.isArray(response.items) ? response.items : []).forEach((item) => {
      if (!item.url || seen.has(item.url)) return;
      seen.add(item.url);
      articles.push(item);
    });
    publishEngagementProgress(id, '自分の記事一覧を取得中: ' + articles.length + '記事', articles.length, articles.length);
    return { articles, seen };
  }

  async function scanEngagement(requestData) {
    if (engagementScanning) engagementRequest += 1;
    const request = ++engagementRequest;
    engagementScanning = true;
    const id = requestData.id;
    const days = Math.max(1, Math.min(30, Number(requestData.days) || 7));
    const cutoffMs = Date.now() - (days === 7 ? ENGAGEMENT_WINDOW_MS : days * 24 * 60 * 60 * 1000);
    let result;
    try {
      publishEngagementProgress(id, 'Firefoxでログイン中のnoteアカウントを確認しています…', 0, 0);
      const account = await browser.runtime.sendMessage({ type: 'NERO_READER_ACTION', action: 'account' });
      const owner = normalizeUrlname(account && account.urlname);
      if (!account || !account.ok || !owner) throw new Error(account && account.message ? account.message : 'noteのログイン情報を確認できませんでした。');
      const cache = await loadEngagementCache(owner);
      const inventory = await enumerateOwnerArticles(owner, request, id);
      const articleCache = cache.articles || (cache.articles = {});
      const now = Date.now();
      const expandedWindow = !Number(cache.cutoffMs || 0) || cutoffMs < Number(cache.cutoffMs || 0);
      const toCheck = [];

      inventory.articles.forEach((item) => {
        const cached = articleCache[item.url];
        const likeCount = Number(item.likeCount || item.likesCount || 0);
        const commentCount = Number(item.commentCount || item.commentsCount || 0);
        const includeLikes = likeCount > 0 && (expandedWindow || engagementNeedsRefresh(cached, likeCount, 'likes', now, cutoffMs));
        const includeComments = commentCount > 0 && (expandedWindow || engagementNeedsRefresh(cached, commentCount, 'comments', now, cutoffMs));
        const entry = cached || {
          articleUrl: item.url,
          articleTitle: item.name,
          likes: [],
          comments: [],
          likesCount: likeCount,
          commentsCount: commentCount,
          checkedAt: 0
        };
        entry.articleTitle = item.name;
        entry.likesCount = likeCount;
        entry.commentsCount = commentCount;
        if (!likeCount) { entry.likes = []; entry.likesCheckedAt = now; }
        if (!commentCount) { entry.comments = []; entry.commentsCheckedAt = now; }
        articleCache[item.url] = entry;
        if (includeLikes || includeComments) toCheck.push({ item, includeLikes, includeComments });
      });

      let cursor = 0;
      let completed = 0;
      let failed = 0;
      const startedAt = Date.now();
      publishEngagementProgress(id, '交流履歴を確認します: ' + toCheck.length + ' / 全' + inventory.articles.length + '記事', 0, toCheck.length);
      async function worker() {
        while (cursor < toCheck.length) {
          const index = cursor++;
          const target = toCheck[index];
          if (request !== engagementRequest) return;
          try {
            const response = await browser.runtime.sendMessage({
              type: 'NERO_READER_ACTION',
              action: 'engagement_article',
              articleUrl: target.item.url,
              cutoffMs,
              includeLikes: target.includeLikes,
              includeComments: target.includeComments
            });
            const entry = articleCache[target.item.url];
            if (target.includeLikes && response && response.likesOk) {
              entry.likes = pruneEngagementRows(response.likes, cutoffMs);
              entry.likesCheckedAt = Date.now();
            }
            if (target.includeComments && response && response.commentsOk) {
              entry.comments = pruneEngagementRows(response.comments, cutoffMs);
              entry.commentsCheckedAt = Date.now();
            }
            if (!response || (target.includeLikes && !response.likesOk) || (target.includeComments && !response.commentsOk)) failed += 1;
            entry.checkedAt = Date.now();
          } catch (_) {
            failed += 1;
          } finally {
            completed += 1;
            publishEngagementProgress(id, '交流を確認中 ' + completed + ' / ' + toCheck.length + elapsedEstimate(startedAt, completed, toCheck.length), completed, toCheck.length);
            if (completed % 5 === 0) await saveEngagementCache(cache);
          }
        }
      }
      await Promise.all(Array.from({ length: Math.min(3, toCheck.length) }, worker));
      if (request !== engagementRequest) throw new Error('確認を中断しました。');
      Object.keys(articleCache).forEach((url) => {
        if (!inventory.seen.has(url)) delete articleCache[url];
        else {
          articleCache[url].likes = pruneEngagementRows(articleCache[url].likes, cutoffMs);
          articleCache[url].comments = pruneEngagementRows(articleCache[url].comments, cutoffMs);
        }
      });
      cache.completedAt = Date.now();
      cache.cutoffMs = cutoffMs;
      await saveEngagementCache(cache);
      const aggregate = globalThis.NeroEngagementCore.aggregateEngagement(articleCache, owner, cutoffMs);
      result = {
        id,
        ok: true,
        owner,
        creators: aggregate.creators,
        stats: aggregate.stats,
        articleCount: inventory.articles.length,
        refreshedCount: toCheck.length,
        failedCount: failed,
        completedAt: cache.completedAt
      };
      publishEngagementProgress(id, aggregate.stats.creatorCount + '人のありがとうを見つけました。', toCheck.length, toCheck.length);
    } catch (error) {
      result = { id, ok: false, message: error && error.message ? error.message : 'ありがとうフィードを作成できませんでした。' };
    } finally {
      if (request === engagementRequest) engagementScanning = false;
    }
    document.documentElement.dataset.neroEngagementResult = JSON.stringify(result);
    document.dispatchEvent(new Event('nero-engagement-result'));
  }

  function threadTime(value) {
    if (!value) return '';
    const date = new Date(value);
    if (Number.isNaN(date.getTime())) return String(value).slice(0, 16);
    return new Intl.DateTimeFormat('ja-JP', { month: 'short', day: 'numeric' }).format(date);
  }

  function renderThreads(comments) {
    const list = shadow.getElementById('threadList');
    list.textContent = '';
    if (!comments.length) {
      const empty = document.createElement('div');
      empty.className = 'thread-empty';
      empty.textContent = 'まだコメントはありません。';
      list.appendChild(empty);
      return;
    }
    comments.forEach((comment) => {
      const row = document.createElement('article');
      row.className = 'thread-row depth-' + (comment.depth ? '1' : '0');
      const meta = document.createElement('div');
      meta.className = 'thread-meta';
      const avatar = document.createElement('img');
      avatar.className = 'thread-avatar';
      avatar.alt = '';
      if (comment.avatar) avatar.src = comment.avatar;
      const author = document.createElement('a');
      author.className = 'thread-author';
      author.href = 'https://note.com/' + encodeURIComponent(comment.authorUrlname);
      author.target = '_blank';
      author.rel = 'noopener noreferrer';
      author.textContent = comment.authorName || '@' + comment.authorUrlname;
      const time = document.createElement('time');
      time.className = 'thread-time';
      time.textContent = threadTime(comment.publishedAt);
      const body = document.createElement('p');
      body.className = 'thread-body';
      body.textContent = comment.body;
      const actions = document.createElement('div');
      actions.className = 'thread-actions';
      const like = document.createElement('button');
      like.className = 'thread-like';
      like.type = 'button';
      like.textContent = comment.liked ? '♥ スキ済み' : '♡ スキ';
      like.disabled = Boolean(comment.liked);
      like.addEventListener('click', async () => {
        like.disabled = true;
        const ok = await sendAction('comment_like', currentThreadUrl, '', inboxTarget(comment), { advance: false });
        if (ok) like.textContent = '♥ スキ済み';
        else like.disabled = false;
      });
      const reply = document.createElement('button');
      reply.className = 'reply';
      reply.type = 'button';
      reply.textContent = '返信する';
      reply.addEventListener('click', () => openComment(currentThreadUrl, inboxTarget(comment)));
      meta.append(avatar, author, time);
      actions.append(like, reply);
      row.append(meta, body, actions);
      list.appendChild(row);
    });
  }

  async function openThreads(articleUrl) {
    createInterface();
    currentThreadUrl = articleUrl;
    const request = ++commentsRequest;
    const list = shadow.getElementById('threadList');
    list.innerHTML = '<div class="thread-loading">コメントを読み込んでいます…</div>';
    shadow.getElementById('threadOverlay').classList.add('open');
    try {
      const result = await browser.runtime.sendMessage({
        type: 'NERO_READER_ACTION',
        action: 'comments',
        articleUrl
      });
      if (request !== commentsRequest || articleUrl !== currentThreadUrl) return;
      if (result && result.ok) {
        renderThreads(Array.isArray(result.comments) ? result.comments : []);
      } else {
        list.textContent = '';
        const error = document.createElement('div');
        error.className = 'thread-empty';
        error.textContent = result && result.message ? result.message : 'コメントを読み込めませんでした。もう一度お試しください。';
        list.appendChild(error);
      }
    } catch (_) {
      if (request === commentsRequest) list.innerHTML = '<div class="thread-empty">拡張機能との通信に失敗しました。</div>';
    }
  }

  function currentArticleUrl() {
    const like = document.getElementById('like');
    const value = String(like && like.href ? like.href : '').split('#')[0];
    return /^https:\/\/note\.com\//.test(value) ? value : '';
  }

  function setLikeVisual(state) {
    const like = document.getElementById('like');
    if (!like) return;
    delete like.dataset.liked;
    if (state === 'checking') {
      like.textContent = '♡ 確認中…';
      like.title = 'noteのスキ状態を確認しています';
    } else if (state === 'liked') {
      like.textContent = '♥ スキ済み';
      like.dataset.liked = 'true';
      like.title = 'この記事はFirefoxでログイン中のnoteアカウントからスキ済みです';
    } else {
      like.textContent = '♡ スキ';
      like.title = state === 'unknown'
        ? '状態を確認できませんでした。タップするとnoteで確認してスキします'
        : 'Firefoxでログイン中のnoteアカウントからスキします';
    }
  }

  function publishLikedStatus(state) {
    document.documentElement.dataset.neroCurrentLiked = state === 'liked' ? 'true' : (state === 'not-liked' ? 'false' : 'unknown');
    document.dispatchEvent(new Event('nero-liked-status'));
  }

  function publishArticleCompleted(articleUrl, reason) {
    document.documentElement.dataset.neroArticleCompleted = JSON.stringify({
      url: String(articleUrl || '').split('#')[0],
      reason,
      at: Date.now()
    });
    document.dispatchEvent(new Event('nero-article-completed'));
  }

  function publishCreatorStatus(creator) {
    currentCreatorStatus = creator && creator.urlname ? {
      urlname: creator.urlname,
      nickname: creator.nickname || creator.urlname,
      isFollowing: typeof creator.isFollowing === 'boolean' ? creator.isFollowing : null,
      isFollower: typeof creator.isFollower === 'boolean' ? creator.isFollower : null,
      isMe: Boolean(creator.isMe)
    } : null;
    document.documentElement.dataset.neroCreatorStatus = JSON.stringify(currentCreatorStatus || {});
    document.dispatchEvent(new Event('nero-creator-status'));
  }

  function setFollowVisual(creator) {
    const follow = document.getElementById('follow');
    if (!follow) return;
    delete follow.dataset.creatorUrlname;
    follow.classList.remove('visible');
    follow.disabled = false;
    follow.textContent = '＋ フォロー';
    if (!creator || !creator.urlname || creator.isMe || creator.isFollowing) return;
    follow.dataset.creatorUrlname = creator.urlname;
    follow.classList.add('visible');
    follow.title = (creator.nickname || creator.urlname) + 'さんをフォローします';
  }

  async function syncLikeStatus(force) {
    const articleUrl = currentArticleUrl();
    if (!articleUrl || (!force && articleUrl === lastStatusUrl)) return;
    lastStatusUrl = articleUrl;
    const request = ++statusRequest;
    setLikeVisual('checking');
    try {
      const result = await browser.runtime.sendMessage({
        type: 'NERO_READER_ACTION',
        action: 'status',
        articleUrl
      });
      if (request !== statusRequest || articleUrl !== currentArticleUrl()) return;
      if (result && result.ok) {
        const state = result.liked ? 'liked' : 'not-liked';
        setLikeVisual(state);
        setFollowVisual(result.creator || null);
        publishCreatorStatus(result.creator || null);
        publishLikedStatus(state);
      } else {
        setLikeVisual('unknown');setFollowVisual(null);publishCreatorStatus(null);publishLikedStatus('unknown');
      }
    } catch (_) {
      if (request === statusRequest && articleUrl === currentArticleUrl()) {
        setLikeVisual('unknown');setFollowVisual(null);publishCreatorStatus(null);publishLikedStatus('unknown');
      }
    }
  }

  function scheduleLikeStatus(force) {
    clearTimeout(statusTimer);
    statusTimer = setTimeout(() => syncLikeStatus(Boolean(force)), 40);
  }

  async function sendAction(action, articleUrl, comment, replyTarget, options) {
    const isCommentLike = action === 'comment_like';
    const isReplyWithLike = action === 'reply_with_like';
    const isFollow = action === 'follow';
    showToast(action === 'like' ? 'noteへスキを送っています…' : (isCommentLike ? 'コメントへスキを送っています…' : (isReplyWithLike ? '返信とスキを送っています…' : (isFollow ? 'フォローしています…' : 'コメントとスキを送っています…'))), 30000);
    try {
      const request = {
        type: 'NERO_READER_ACTION',
        action,
        articleUrl,
        comment: comment || '',
        replyTarget: replyTarget || null
      };
      const result = await sendMutationRequest(request);
      if (result && result.ok) {
        const message = action === 'like'
          ? (result.already ? 'この記事はスキ済みです' : 'スキを送りました')
          : (isCommentLike ? (result.already ? 'このコメントはスキ済みです' : 'コメントへスキを送りました') : (isReplyWithLike ? '返信とスキを送りました' : (isFollow ? (result.already ? 'フォロー済みです' : 'フォローしました') : (replyTarget ? '返信を送りました' : 'コメントとスキを送りました'))));
        showToast(message);
        if (action === 'like' || action === 'comment') setLikeVisual('liked');
        if (action === 'like' || action === 'comment') publishArticleCompleted(articleUrl, action);
        if (isFollow) {
          const updated = Object.assign({}, currentCreatorStatus || {}, { isFollowing: true });
          setFollowVisual(updated);
          publishCreatorStatus(updated);
        }
        return true;
      }
      const failureCode = result && result.code ? '（' + result.code + '）' : '';
      showToast((result && result.message ? result.message : 'noteで操作を確認してください。') + failureCode, 6000);
      if (action === 'comment' && result && result.partial && result.commentSent) {
        // The comment is already public. Close the composer and discard its
        // draft so a retry cannot create a duplicate; leave the article heart
        // untouched because its mutation was not verified.
        publishArticleCompleted(articleUrl, 'comment');
        return 'partial';
      }
      return false;
    } catch (error) {
      const code = error && error.code ? '（' + error.code + '）' : '';
      showToast('拡張機能との通信に失敗しました' + code + '。もう一度お試しください。', 5000);
      return false;
    }
  }

  function sendMutationRequest(request) {
    if (!browser.runtime.connect) return browser.runtime.sendMessage(request);
    return new Promise((resolve, reject) => {
      let settled = false;
      const port = browser.runtime.connect({ name: 'NERO_MUTATION_V1' });
      const timer = setTimeout(() => {
        if (settled) return;
        settled = true;
        try { port.disconnect(); } catch (_) {}
        const error = new Error('operation timeout');
        error.code = '操作タイムアウト';
        reject(error);
      }, 45000);
      port.onMessage.addListener((message) => {
        if (settled || !message || message.requestId !== request.requestId) return;
        settled = true;
        clearTimeout(timer);
        resolve(message.result);
        try { port.disconnect(); } catch (_) {}
      });
      port.onDisconnect.addListener(() => {
        if (settled) return;
        settled = true;
        clearTimeout(timer);
        const error = new Error('extension port disconnected');
        error.code = '接続切断';
        reject(error);
      });
      request.requestId = String(Date.now()) + ':' + Math.random().toString(36).slice(2);
      port.postMessage(request);
    });
  }

  async function submitComment() {
    const textarea = shadow.getElementById('commentText');
    const text = textarea.value.trim();
    if (!text) {
      showToast('コメントを入力してください。');
      textarea.focus();
      return;
    }
    const send = shadow.getElementById('send');
    send.disabled = true;
    const articleUrl = currentCommentUrl;
    const replyTarget = currentReplyTarget;
    const source = currentCommentSource;
    const inboxKey = currentInboxKey;
    const draftKey = currentDraftKey;
    const action = replyTarget ? 'reply_with_like' : 'comment';
    const ok = await sendAction(action, articleUrl, text, replyTarget, { advance: false });
    send.disabled = false;
    if (!ok) {
      textarea.focus();
      return;
    }
    commentDrafts.delete(draftKey);
    if (source === 'inbox') removeInboxItem(inboxKey);
    closeComment();
  }

  function installConnectedState() {
    document.documentElement.dataset.neroExtension = 'ready';
    document.documentElement.dataset.neroExtensionVersion = '0.1.30';
    const like = document.getElementById('like');
    const comment = document.getElementById('comment');
    if (like) {
      setLikeVisual('checking');
    }
    if (comment) comment.title = 'コメントスレッドを見て、新規コメントや返信を送信します';
    const topbar = document.querySelector('.topbar');
    if (topbar) {
      let status = document.getElementById('neroExtensionStatus');
      if (!status) {
        status = document.createElement('span');
        status.id = 'neroExtensionStatus';
        const manage = document.getElementById('manage');
        topbar.insertBefore(status, manage || null);
      }
      status.textContent = '連携中 v0.1.30';
      status.title = 'Firefox拡張機能 v0.1.30 と連携中';
      status.classList.add('connected');
      if (!status.classList.contains('bridge-status')) {
        status.style.cssText = 'font-size:11px;font-weight:900;color:#2f7b56;background:#e7f8ef;border:1px solid #bce5ce;border-radius:999px;padding:6px 8px;white-space:nowrap';
      }
    }
    showToast('Firefox連携が有効です');
    scheduleLikeStatus(true);
  }

  document.addEventListener('click', (event) => {
    const target = event.target instanceof Element ? event.target.closest('#like,#comment,#inbox,#follow') : null;
    if (!target) return;
    if (target.id === 'inbox') {
      event.preventDefault();
      event.stopImmediatePropagation();
      openInbox();
      return;
    }
    const articleUrl = target.id === 'follow' ? currentArticleUrl() : String(target.href || '').split('#')[0];
    if (!/^https:\/\/note\.com\//.test(articleUrl)) return;
    event.preventDefault();
    event.stopImmediatePropagation();
    if (target.id === 'like') sendAction('like', articleUrl, '', null, { advance: false });
    else if (target.id === 'follow') {
      target.disabled = true;
      sendAction('follow', articleUrl, '', null, { advance: false }).then((ok) => { if (!ok) target.disabled = false; });
    } else openThreads(articleUrl);
  }, true);

  document.addEventListener('nero-search-request', async () => {
    let request = null;
    try { request = JSON.parse(document.documentElement.dataset.neroSearchRequest || ''); } catch (_) {}
    if (!request || !request.id || !String(request.query || '').trim()) return;
    let result;
    try {
      const response = await browser.runtime.sendMessage({
        type: 'NERO_READER_ACTION',
        action: 'search',
        query: String(request.query).slice(0, 80),
        page: Number(request.page) || 1
      });
      result = response && response.ok
        ? { id: request.id, ok: true, items: Array.isArray(response.items) ? response.items : [] }
        : { id: request.id, ok: false, message: response && response.message ? response.message : 'note検索結果を取得できませんでした。' };
    } catch (_) {
      result = { id: request.id, ok: false, message: 'Firefox拡張機能との通信に失敗しました。' };
    }
    document.documentElement.dataset.neroSearchResult = JSON.stringify(result);
    document.dispatchEvent(new Event('nero-search-result'));
  });

  document.addEventListener('nero-account-request', async () => {
    let request = null;
    try { request = JSON.parse(document.documentElement.dataset.neroAccountRequest || ''); } catch (_) {}
    if (!request || !request.id) return;
    let result;
    try {
      const response = await browser.runtime.sendMessage({
        type: 'NERO_READER_ACTION',
        action: 'account'
      });
      result = response && response.ok
        ? { id: request.id, ok: true, urlname: String(response.urlname || '') }
        : { id: request.id, ok: false, message: response && response.message ? response.message : 'ログイン中のnoteアカウントを確認できませんでした。' };
    } catch (_) {
      result = { id: request.id, ok: false, message: 'Firefox拡張機能との通信に失敗しました。' };
    }
    document.documentElement.dataset.neroAccountResult = JSON.stringify(result);
    document.dispatchEvent(new Event('nero-account-result'));
  });

  document.addEventListener('nero-followings-request', async () => {
    let request = null;
    try { request = JSON.parse(document.documentElement.dataset.neroFollowingsRequest || ''); } catch (_) {}
    if (!request || !request.id) return;
    let result;
    try {
      const response = await browser.runtime.sendMessage({
        type: 'NERO_READER_ACTION',
        action: 'followings',
        sampleSize: Number(request.sampleSize) || 18
      });
      result = response && response.ok
        ? {
            id: request.id,
            ok: true,
            creators: Array.isArray(response.creators) ? response.creators : [],
            totalCount: Number(response.totalCount || 0),
            eligibleCount: Number(response.eligibleCount || 0),
            capped: Boolean(response.capped),
            legacyLimit: Boolean(response.legacyLimit)
          }
        : { id: request.id, ok: false, message: response && response.message ? response.message : 'フォロー一覧を取得できませんでした。' };
    } catch (_) {
      result = { id: request.id, ok: false, message: 'Firefox拡張機能との通信に失敗しました。' };
    }
    document.documentElement.dataset.neroFollowingsResult = JSON.stringify(result);
    document.dispatchEvent(new Event('nero-followings-result'));
  });

  document.addEventListener('nero-engagement-request', () => {
    let request = null;
    try { request = JSON.parse(document.documentElement.dataset.neroEngagementRequest || ''); } catch (_) {}
    if (!request || !request.id) return;
    scanEngagement(request);
  });

  document.addEventListener('nero-creator-latest-request', async () => {
    let request = null;
    try { request = JSON.parse(document.documentElement.dataset.neroCreatorLatestRequest || ''); } catch (_) {}
    if (!request || !request.id || !Array.isArray(request.creators)) return;
    let result;
    try {
      const response = await browser.runtime.sendMessage({
        type: 'NERO_READER_ACTION',
        action: 'creator_latest_batch',
        creators: request.creators.slice(0, 200)
      });
      result = response && response.ok
        ? { id: request.id, ok: true, items: Array.isArray(response.items) ? response.items : [], failed: Array.isArray(response.failed) ? response.failed : [] }
        : { id: request.id, ok: false, message: response && response.message ? response.message : '最新記事を取得できませんでした。' };
    } catch (_) {
      result = { id: request.id, ok: false, message: 'Firefox拡張機能との通信に失敗しました。' };
    }
    document.documentElement.dataset.neroCreatorLatestResult = JSON.stringify(result);
    document.dispatchEvent(new Event('nero-creator-latest-result'));
  });

  document.addEventListener('nero-status-batch-request', async () => {
    let request = null;
    try { request = JSON.parse(document.documentElement.dataset.neroStatusBatchRequest || ''); } catch (_) {}
    if (!request || !request.id || !Array.isArray(request.urls)) return;
    let result;
    try {
      const response = await browser.runtime.sendMessage({
        type: 'NERO_READER_ACTION',
        action: 'status_batch',
        urls: request.urls.slice(0, 30)
      });
      result = response && response.ok
        ? { id: request.id, ok: true, results: Array.isArray(response.results) ? response.results : [] }
        : { id: request.id, ok: false, message: response && response.message ? response.message : '未スキ記事を確認できませんでした。' };
    } catch (_) {
      result = { id: request.id, ok: false, message: 'Firefox拡張機能との通信に失敗しました。' };
    }
    document.documentElement.dataset.neroStatusBatchResult = JSON.stringify(result);
    document.dispatchEvent(new Event('nero-status-batch-result'));
  });

  document.addEventListener('nero-magazines-request', async () => {
    let request = null;
    try { request = JSON.parse(document.documentElement.dataset.neroMagazinesRequest || ''); } catch (_) {}
    if (!request || !request.id || !request.articleUrl) return;
    let result;
    try {
      const response = await browser.runtime.sendMessage({
        type: 'NERO_READER_ACTION',
        action: 'magazines',
        articleUrl: String(request.articleUrl)
      });
      result = response && response.ok
        ? { id: request.id, ok: true, magazines: Array.isArray(response.magazines) ? response.magazines : [] }
        : { id: request.id, ok: false, message: response && response.message ? response.message : 'マガジン一覧を確認できませんでした。' };
    } catch (_) {
      result = { id: request.id, ok: false, message: 'Firefox拡張機能との通信に失敗しました。' };
    }
    document.documentElement.dataset.neroMagazinesResult = JSON.stringify(result);
    document.dispatchEvent(new Event('nero-magazines-result'));
  });

  document.addEventListener('nero-magazine-add-request', async () => {
    let request = null;
    try { request = JSON.parse(document.documentElement.dataset.neroMagazineAddRequest || ''); } catch (_) {}
    if (!request || !request.id || !request.articleUrl) return;
    let result;
    try {
      const response = await sendMutationRequest({
        type: 'NERO_READER_ACTION',
        action: 'magazine_add',
        articleUrl: String(request.articleUrl),
        magazineKey: String(request.magazineKey || ''),
        magazineName: String(request.magazineName || ''),
        magazineIndex: Number(request.magazineIndex) || 0,
        expectedAccount: String(request.expectedAccount || '')
      });
      result = response && response.ok
        ? { id: request.id, ok: true, already: Boolean(response.already) }
        : { id: request.id, ok: false, message: response && response.message ? response.message : 'マガジンへ追加できませんでした。' };
    } catch (_) {
      result = { id: request.id, ok: false, message: 'Firefox拡張機能との通信に失敗しました。追加結果はnote側でご確認ください。' };
    }
    document.documentElement.dataset.neroMagazineAddResult = JSON.stringify(result);
    document.dispatchEvent(new Event('nero-magazine-add-result'));
  });

  document.addEventListener('nero-article-shown', () => scheduleLikeStatus(true));

  createInterface();
  installConnectedState();
  const observer = new MutationObserver(() => scheduleLikeStatus(false));
  observer.observe(document.documentElement, {
    subtree: true,
    childList: true,
    attributes: true,
    attributeFilter: ['href']
  });
  globalThis.NeroReaderBridgeTest = { unresolvedComments, normalizeUrlname, inboxFeedUrl, inboxTarget, engagementNeedsRefresh, pruneEngagementRows };
})();
