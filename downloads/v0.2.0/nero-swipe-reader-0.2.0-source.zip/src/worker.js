const PAGE = String.raw`<!doctype html>
<html lang="ja">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<meta name="theme-color" content="#fff8fb">
<title>NERO Favorite Reader</title>
<style>
:root{
  --ink:#28222b;--muted:#827781;--pink:#ed4b85;--pink2:#fff0f6;
  --purple:#7757c8;--purple2:#f1ecff;--line:#eadfe8;--paper:#fff;
  font-family:Inter,"Noto Sans JP",system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;
  color:var(--ink);background:#fbf7fb;color-scheme:light
}
*{box-sizing:border-box}
html,body{margin:0;width:100%;max-width:100vw;height:100%;overflow:hidden}
body{background:radial-gradient(circle at 10% 0,#fff 0,#fff7fb 30%,#f7f1ff 100%)}
button,input,textarea{font:inherit}
button,a{-webkit-tap-highlight-color:transparent}
.app{width:100%;max-width:760px;min-width:0;height:100dvh;display:grid;grid-template-rows:auto minmax(0,1fr) auto;margin:0 auto;overflow:hidden}
.topbar{width:100%;min-width:0;display:flex;align-items:center;gap:12px;padding:12px 16px 9px;background:rgba(255,255,255,.88);backdrop-filter:blur(14px);border-bottom:1px solid rgba(234,223,232,.85);z-index:3;overflow-x:auto;overscroll-behavior-x:contain;scrollbar-width:none}
.topbar::-webkit-scrollbar{display:none}
.brand{min-width:0;flex:1}
.brand strong{display:block;font-size:17px;letter-spacing:.01em;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.brand span{display:block;font-size:11px;color:var(--muted);margin-top:2px}
.counter{font-size:12px;color:var(--muted);white-space:nowrap}
.icon-button{border:1px solid var(--line);background:#fff;color:var(--ink);border-radius:999px;padding:9px 12px;font-weight:800}
.bridge-status{flex:0 0 auto;border:1px solid #efc7a9;background:#fff5eb;color:#9a4f1b;border-radius:999px;padding:8px 10px;font-size:11px;font-weight:900;white-space:nowrap}
.bridge-status.connected{border-color:#bce5ce;background:#e7f8ef;color:#2f7b56}
.inbox-button{border-color:#dacff2;background:#f5f1ff;color:#59389d}
.discover-button{border-color:#f0bfd1;background:#fff0f6;color:#a52b5b}
.nero-button{border-color:#d8c27a;background:#fff8d8;color:#70581b}
.stage{width:100%;min-width:0;min-height:0;padding:10px 10px 8px;position:relative;overflow:hidden}
.card{width:100%;min-width:0;height:100%;overflow-x:hidden;overflow-y:auto;overscroll-behavior:contain;background:var(--paper);border:1px solid var(--line);border-radius:28px;box-shadow:0 18px 55px rgba(75,48,74,.10);scrollbar-width:thin;scrollbar-color:#dbcce0 transparent}
.card-inner{width:100%;min-width:0;max-width:100%;padding:20px 19px 44px;overflow:hidden}
.article-meta{width:100%;min-width:0;display:flex;gap:10px;align-items:center;margin-bottom:12px}
.avatar{width:38px;height:38px;border-radius:50%;object-fit:cover;background:#f0e5f4;border:1px solid var(--line)}
.author{min-width:0;flex:1;overflow:hidden}
.author a{display:block;max-width:100%;color:var(--ink);font-weight:800;text-decoration:none;overflow-wrap:anywhere}
.author time{display:block;color:var(--muted);font-size:12px;margin-top:2px}
.position{margin-left:auto;color:var(--muted);font-size:12px;white-space:nowrap}
.follow{display:none;border:1px solid #dacff2;background:#f5f1ff;color:#59389d;border-radius:999px;padding:7px 10px;font-size:12px;font-weight:900;white-space:nowrap}
.follow.visible{display:inline-flex}.follow:disabled{opacity:.55}
.title{width:100%;min-width:0;max-width:100%;font-size:clamp(23px,5.7vw,34px);line-height:1.38;margin:9px 0 17px;letter-spacing:.01em;overflow-wrap:anywhere;word-break:break-word}
.eyecatch{display:none;width:100%;max-width:100%;max-height:480px;object-fit:contain;background:#f6f1f6;border-radius:18px;margin:0 0 20px}
.reader-body{width:100%;min-width:0;max-width:100%;overflow-x:hidden;font-family:ui-serif,"Noto Serif JP","Yu Mincho",serif;font-size:17px;line-height:1.95;overflow-wrap:anywhere;word-break:break-word}
.reader-body *{min-width:0;max-width:100%}
.reader-body p{margin:0 0 1.25em}
.reader-body h1,.reader-body h2,.reader-body h3,.reader-body h4{font-family:Inter,"Noto Sans JP",sans-serif;line-height:1.5;margin:1.7em 0 .7em}
.reader-body h1{font-size:1.55em}.reader-body h2{font-size:1.35em}.reader-body h3{font-size:1.17em}
.reader-body a{color:#6550bd;text-decoration:underline;text-decoration-thickness:.08em;text-underline-offset:.18em;overflow-wrap:anywhere;word-break:break-word}
.reader-body .note-link-card{display:block;margin:1.25em 0;padding:14px 16px;border:1px solid #d9c9ed;border-radius:15px;background:#f7f3ff;color:#59389d;font-family:Inter,"Noto Sans JP",sans-serif;font-weight:850;text-decoration:none}
.reader-body .external-link-card{display:block;margin:1.25em 0;padding:15px 16px;border:1px solid #d8e2eb;border-radius:15px;background:#f7fbff;color:#334b61;font-family:Inter,"Noto Sans JP",sans-serif;text-decoration:none;overflow:hidden}
.reader-body .external-link-card span{display:block;margin-bottom:4px;color:#6e7f8e;font-size:11px;font-weight:800}.reader-body .external-link-card strong{display:block;font-size:15px;line-height:1.5}.reader-body .external-link-card small{display:block;margin-top:5px;color:#6e7f8e;font-size:11px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.reader-body .external-link-card.note-resource{border-color:#d9c9ed;background:linear-gradient(135deg,#fbf8ff,#f4efff);color:#4f368f}.reader-body .external-link-card.note-resource span{color:#7757c8}.reader-body .external-link-card.note-resource strong{font-size:16px}.reader-body .external-link-card.note-resource small{color:#756a82}
.reader-body img,.reader-body video,.reader-body picture,.reader-body iframe,.reader-body canvas,.reader-body svg{display:block;width:100%!important;max-width:100%!important;height:auto!important;object-fit:contain;margin:1.4em auto;border-radius:12px}
.reader-body .note-embed-shell{width:100%;max-width:100%;margin:1.35em 0;overflow:hidden;border:1px solid var(--line);border-radius:16px;background:#fff;box-shadow:0 5px 18px rgba(75,48,74,.07);font-family:Inter,"Noto Sans JP",sans-serif}
.reader-body iframe.note-embed-frame{display:block;width:100%!important;max-width:100%!important;margin:0!important;border:0!important;border-radius:0!important;background:#fff;object-fit:initial}
.reader-body iframe.note-embed-frame.article{height:238px!important;min-height:238px}
.reader-body iframe.note-embed-frame.money{height:430px!important;min-height:430px}
.reader-body iframe.note-embed-frame.qa{height:590px!important;min-height:590px}
.reader-body iframe.note-embed-frame.sound{height:190px!important;min-height:190px}
.reader-body .note-embed-open{display:block;margin:0!important;padding:12px 15px;border-top:1px solid var(--line);background:#f7f3ff;color:#59389d;text-align:center;font-size:14px;font-weight:900;text-decoration:none}
.reader-body figure{width:100%;max-width:100%;margin:1.5em 0;overflow:hidden}.reader-body figcaption{text-align:center;color:var(--muted);font-size:.82em;margin-top:.5em}
.reader-body blockquote{margin:1.4em 0;padding:.2em 0 .2em 1em;border-left:4px solid #d9c9ed;color:#665e68}
.reader-body ul,.reader-body ol{padding-left:1.45em;margin:1.1em 0}
.reader-body table{display:block;width:100%;max-width:100%;overflow-x:auto;border-collapse:collapse}.reader-body pre{width:100%;max-width:100%;overflow:auto;padding:14px;border-radius:12px;background:#f6f2f7;line-height:1.55}
.reader-body code{font-family:ui-monospace,SFMono-Regular,Menlo,monospace;font-size:.9em}
.reader-body hr{border:0;border-top:1px solid var(--line);margin:2em 0}
.plain-copy{white-space:pre-wrap}
.end-card{margin:28px 0 5px;padding:18px;border-radius:18px;background:linear-gradient(135deg,var(--pink2),var(--purple2));text-align:center}
.end-card strong{display:block;margin-bottom:6px}.end-card span{font-size:13px;color:var(--muted)}
.save-card{margin:28px 0 12px;padding:16px;border:1px solid #bfe2cf;border-radius:20px;background:linear-gradient(135deg,#f1fbf5,#e8f7ef);font-family:Inter,"Noto Sans JP",sans-serif}
.save-label{display:block;color:#2f7b56;font-size:11px;font-weight:950;letter-spacing:.08em}.save-title{display:block;margin-top:3px;font-size:17px;line-height:1.45}.save-help{display:block;margin-top:5px;color:#607168;font-size:12px;line-height:1.6}
.magazine-open{width:100%;min-height:48px;margin-top:13px;border:0;border-radius:14px;background:#2f7b56;color:#fff;font-weight:950;cursor:pointer}.magazine-open:disabled{opacity:.55}
.actions{width:100%;min-width:0;display:grid;grid-template-columns:58px minmax(0,1fr) minmax(0,1fr) 58px;gap:8px;padding:8px 10px max(8px,env(safe-area-inset-bottom));background:rgba(255,255,255,.93);backdrop-filter:blur(16px);border-top:1px solid var(--line);z-index:3;overflow:hidden}
html[data-nero-composer="open"] .app{grid-template-rows:auto minmax(0,1fr) 0}
html[data-nero-composer="open"] .actions{height:0;min-height:0;padding:0;border:0;visibility:hidden}
html[data-nero-composer="open"] .card-inner{padding-bottom:calc(var(--nero-composer-height,360px) + 24px)}
html[data-nero-composer="open"] .topbar{pointer-events:none}
html[data-nero-composer="open"] .reader-body a,html[data-nero-composer="open"] .article-meta a{pointer-events:none}
.action{min-width:0;min-height:54px;border:0;border-radius:18px;display:flex;align-items:center;justify-content:center;gap:6px;text-decoration:none;font-weight:900;cursor:pointer;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.action.prev,.action.next{background:#f2edf1;color:#625962;font-size:13px}
.action.like{background:#ffe5ef;color:#bd245f}
.action.comment{background:#eee8ff;color:#59389d}
.action[aria-disabled=true]{opacity:.38;pointer-events:none}
.loading{color:var(--muted);text-align:center;padding:40px 12px}
.notice{position:absolute;left:50%;top:22px;transform:translateX(-50%);z-index:4;padding:9px 13px;border-radius:999px;background:rgba(40,34,43,.88);color:#fff;font-size:12px;box-shadow:0 8px 24px rgba(0,0,0,.15);opacity:0;pointer-events:none;transition:opacity .2s;white-space:nowrap}
.notice.show{opacity:1}
.sheet{position:fixed;inset:0;z-index:10;background:rgba(30,22,30,.42);display:none;align-items:flex-end;justify-content:center}
.sheet.open{display:flex}
.panel{width:min(760px,100%);max-height:88dvh;overflow:auto;background:#fff;border-radius:28px 28px 0 0;padding:22px 18px max(28px,env(safe-area-inset-bottom));box-shadow:0 -18px 60px rgba(0,0,0,.15)}
.panel-head{display:flex;align-items:center;gap:12px}
.panel-head h2{margin:0;flex:1;font-size:21px}
.panel-head button{border:0;background:#f3eef3;border-radius:999px;width:40px;height:40px;font-size:18px}
.help{color:var(--muted);font-size:13px;line-height:1.7}
.add-row{display:grid;grid-template-columns:1fr auto;gap:8px;margin:16px 0 8px}
.search-row{display:grid;grid-template-columns:1fr auto;gap:8px;margin:16px 0 10px}
.search-actions{display:grid;grid-template-columns:1fr 1fr;gap:8px}.search-actions button{min-height:46px}
.source-badge{display:inline-flex;align-items:center;gap:6px;margin:0 0 10px;padding:7px 10px;border-radius:999px;background:#fff0f6;color:#a52b5b;font-size:12px;font-weight:900}
.feed-options{display:grid;gap:9px;margin:14px 0}.feed-option{width:100%;border:1px solid var(--line);background:#fff;border-radius:17px;padding:13px 15px;text-align:left;color:var(--ink)}
.feed-option strong{display:block;font-size:15px}.feed-option span{display:block;margin-top:4px;color:var(--muted);font-size:12px;line-height:1.55}.feed-option.active{border-color:#bba8e8;background:#f5f1ff;color:#59389d}
.article-badges{display:flex;flex-wrap:wrap;gap:5px;margin-top:5px}.article-badge{display:none;width:max-content;max-width:100%;padding:4px 7px;border-radius:999px;font-size:10px;font-weight:900;line-height:1.25}.article-badge.visible{display:inline-flex}.article-badge.thanks{background:#fff0f6;color:#a52b5b}.article-badge.relation{background:#eef8f2;color:#2f7b56}
.list-tools{display:grid;grid-template-columns:minmax(0,1fr) auto auto auto;gap:7px;margin:13px 0}.list-tools button{padding:0 10px;min-height:44px}.list-tools select{min-width:0}
.field{width:100%;border:1px solid #d8ccd6;border-radius:14px;padding:12px 13px;background:#fff;color:var(--ink)}
.primary{border:0;border-radius:14px;padding:0 17px;background:var(--ink);color:#fff;font-weight:900}
.bulk{min-height:86px;resize:vertical;line-height:1.55;margin-top:10px}
.bulk-button{width:100%;margin-top:8px;padding:12px}
.watch-count{font-weight:900;color:var(--purple)}
.chips{display:flex;flex-wrap:wrap;gap:8px;margin:16px 0}
.chip{display:flex;align-items:center;gap:7px;background:#f5f0f4;border:1px solid var(--line);border-radius:999px;padding:8px 9px 8px 12px;font-size:13px}
.chip button{border:0;background:#fff;border-radius:50%;width:24px;height:24px;color:#7a6d77}
.error{min-height:20px;margin:7px 0;color:#b72255;font-size:13px}
.disclosure{border-top:1px solid var(--line);padding-top:14px;color:var(--muted);font-size:12px;line-height:1.65}
.magazine-context{margin:10px 0 0;padding:12px 14px;border-radius:15px;background:#eef8f2;color:#315f49;font-size:13px;line-height:1.65}.magazine-context strong{display:block;color:#244d39;overflow-wrap:anywhere}
.magazine-status{min-height:22px;margin:13px 2px 8px;color:var(--muted);font-size:12px;line-height:1.55}.magazine-status.error{color:#b72255}
.magazine-list{display:grid;gap:9px;margin:8px 0 14px}.magazine-row{display:grid;grid-template-columns:minmax(0,1fr) auto;gap:12px;align-items:center;padding:13px;border:1px solid var(--line);border-radius:17px;background:#fff}.magazine-copy{min-width:0}.magazine-copy strong{display:block;overflow-wrap:anywhere}.magazine-meta{display:flex;flex-wrap:wrap;gap:5px;margin-top:5px}.magazine-badge{display:inline-flex;padding:3px 7px;border-radius:999px;background:#f2eef2;color:#6f6470;font-size:10px;font-weight:850}.magazine-add{min-width:74px;min-height:40px;border:0;border-radius:12px;background:#2f7b56;color:#fff;font-size:12px;font-weight:950}.magazine-add:disabled{background:#eef2ef;color:#68746d}.magazine-empty{padding:22px 14px;border:1px dashed #cfc3cd;border-radius:16px;color:var(--muted);text-align:center;font-size:13px;line-height:1.7}
.nero-panel{background:linear-gradient(180deg,#fffdf5,#fff 190px)}
.nero-target{margin:12px 0;padding:14px 15px;border:1px solid #ead69a;border-radius:18px;background:#fff9df}.nero-target span{display:block;color:#8b7227;font-size:11px;font-weight:900;letter-spacing:.06em}.nero-target strong{display:block;margin-top:3px;font-size:19px}
.nero-grid{display:grid;grid-template-columns:1fr 130px;gap:9px;margin:10px 0}.nero-grid.full{grid-template-columns:1fr}.nero-controls{display:grid;grid-template-columns:1fr 1fr;gap:9px;margin:10px 0}.nero-controls button{min-height:46px}
.nero-status{min-height:22px;margin:10px 2px;color:#725d1e;font-size:12px;font-weight:800;line-height:1.55}.nero-status.error{color:#b72255}
.nero-results{display:grid;gap:9px;margin:12px 0}.nero-card{display:grid;grid-template-columns:auto minmax(0,1fr);gap:11px;padding:13px;border:1px solid #eadfe8;border-radius:17px;background:#fff}.nero-card input{width:20px;height:20px;margin:2px 0 0;accent-color:#7757c8}.nero-card strong{display:block;font-size:14px;line-height:1.5}.nero-card small{display:block;margin-top:4px;color:var(--muted);font-size:11px;line-height:1.45}.nero-reasons{display:flex;flex-wrap:wrap;gap:5px;margin-top:7px}.nero-reason{padding:3px 7px;border-radius:999px;background:#f1ecff;color:#59389d;font-size:10px;font-weight:850}.nero-reason.liked{background:#ffe5ef;color:#bd245f}.nero-reason.warn{background:#fff0e5;color:#96531e}.nero-empty{padding:24px 14px;border:1px dashed #d9ca9e;border-radius:17px;text-align:center;color:var(--muted);font-size:13px;line-height:1.7}.nero-run{width:100%;min-height:52px;border:0;border-radius:15px;background:#28222b;color:#fff;font-weight:950}.nero-run.stop{background:#9a3150}.nero-run:disabled{opacity:.45}.nero-note{margin:10px 2px;color:var(--muted);font-size:11px;line-height:1.6}
@media(max-width:430px){
  .topbar{padding-left:10px;padding-right:10px;gap:7px}.brand{flex:0 1 145px}.brand strong{font-size:15px}.brand span{display:none}.counter{display:none}.icon-button{flex:0 0 auto;padding:8px 9px;font-size:12px}
  .bridge-status{padding:8px;font-size:0}.bridge-status::before{content:'●';font-size:11px}.list-tools{grid-template-columns:1fr auto auto auto;gap:5px}.list-tools button{padding:0 7px;font-size:11px}
  .stage{padding:7px 7px 6px}.card{border-radius:23px}.card-inner{padding:18px 17px 40px}
  .actions{gap:6px;padding-left:7px;padding-right:7px;grid-template-columns:52px minmax(0,1fr) minmax(0,1fr) 52px}
  .action{font-size:14px}.action.prev,.action.next{font-size:12px}
  .nero-grid,.nero-controls{grid-template-columns:1fr}.nero-panel{max-height:94dvh}
}
</style>
</head>
<body>
<div class="app">
  <header class="topbar">
    <div class="brand"><strong>NERO Favorite Reader</strong><span>ネロのお気に入り候補を読む／保存する</span></div>
    <span class="counter" id="counter"></span>
    <button class="icon-button" id="mode" type="button" title="表示モードを切り替える">未完了</button>
    <button class="icon-button discover-button" id="discover" type="button">フィード</button>
    <button class="icon-button nero-button" id="neroFavorites" type="button" hidden>🌙 お気に入り</button>
    <button class="icon-button inbox-button" id="inbox" type="button">未対応</button>
    <button class="bridge-status" id="neroExtensionStatus" type="button" aria-live="polite" title="Firefox拡張機能の接続状態">未接続</button>
    <button class="icon-button" id="manage" type="button">登録</button>
  </header>
  <main class="stage">
    <div class="notice" id="notice" role="status"></div>
    <article class="card" id="card">
      <div class="card-inner">
        <div class="article-meta">
          <img class="avatar" id="avatar" alt="">
          <div class="author"><a id="authorLink" target="_blank" rel="noopener noreferrer"></a><time id="date"></time><div class="article-badges"><span class="article-badge thanks" id="thanksBadge"></span><span class="article-badge relation" id="relationBadge"></span></div></div>
          <button class="follow" id="follow" type="button">＋ フォロー</button>
          <span class="position" id="position"></span>
        </div>
        <h1 class="title" id="articleTitle">フィードを準備中</h1>
        <img class="eyecatch" id="eyecatch" alt="">
        <div class="reader-body" id="body"><div class="loading">読み込み中…</div></div>
      </div>
    </article>
  </main>
  <nav class="actions" aria-label="記事の操作">
    <button class="action prev" id="prev" type="button">前へ</button>
    <a class="action like" id="like" target="_blank" rel="noopener noreferrer">♡ noteでスキ</a>
    <a class="action comment" id="comment" target="_blank" rel="noopener noreferrer">💬 コメントを見る</a>
    <button class="action next" id="next" type="button">次へ</button>
  </nav>
</div>
<div class="sheet" id="neroSheet" role="dialog" aria-modal="true" aria-labelledby="neroTitle">
  <section class="panel nero-panel">
    <div class="panel-head"><h2 id="neroTitle">🌙 ネロのお気に入り収集室</h2><button id="closeNero" type="button" aria-label="閉じる">×</button></div>
    <div class="nero-target"><span>追加先マガジン</span><strong>ネロのお気に入り🌙</strong></div>
    <p class="help">ネロがスキした記事と、自己紹介・挑戦・交流の空気がある記事を集めます。検索候補は理由付きで選び、チェックした記事だけを順番に追加します。</p>
    <div class="nero-grid">
      <input class="field" id="neroAccount" autocomplete="off" maxlength="80" placeholder="ネロのnote ID（空欄なら現在のログインを固定）">
      <button class="icon-button" id="verifyNero" type="button">本人確認・固定</button>
    </div>
    <div class="nero-status" id="neroAccountStatus" role="status"></div>
    <div class="nero-grid full">
      <textarea class="field bulk" id="neroTags" placeholder="#自己紹介&#10;#note初心者&#10;#noteを楽しむ"></textarea>
    </div>
    <div class="nero-grid">
      <select class="field" id="neroPages" aria-label="各ハッシュタグから取得するページ数"><option value="1">各タグ 最新1ページ</option><option value="2" selected>各タグ 最新2ページ</option><option value="3">各タグ 最新3ページ</option></select>
      <select class="field" id="neroDailyCap" aria-label="1日の追加上限"><option value="20">1日20件まで</option><option value="40" selected>1日40件まで</option><option value="60">1日60件まで</option></select>
    </div>
    <label class="chip" style="width:max-content"><input id="neroAutoLike" type="checkbox" checked> Readerでスキした記事を自動追加</label>
    <div class="nero-controls"><button class="primary" id="scanNero" type="button">候補を探す</button><button class="icon-button" id="selectNero" type="button">おすすめだけ選択</button></div>
    <div class="nero-status" id="neroStatus" role="status"></div>
    <div class="nero-results" id="neroResults"><div class="nero-empty">ハッシュタグを入力して「候補を探す」を押してください。</div></div>
    <button class="nero-run" id="runNero" type="button" disabled>選んだ記事をマガジンへ追加</button>
    <p class="nero-note">操作は1件ずつ行い、途中で停止できます。認証切れ・追加失敗・note側の制限表示を検知した場合は、その場で止まります。ID・候補・履歴はこの端末内だけに保存します。</p>
  </section>
</div>
<div class="sheet" id="searchSheet" role="dialog" aria-modal="true" aria-labelledby="searchTitle">
  <section class="panel">
    <div class="panel-head"><h2 id="searchTitle">フィードを選ぶ</h2><button id="closeSearch" type="button" aria-label="閉じる">×</button></div>
    <div class="feed-options">
      <button class="feed-option" id="useWatchFeed" type="button"><strong>🌸 特に読みたい人</strong><span>選択中のウォッチリストから、未読優先でランダム表示します。</span></button>
      <button class="feed-option" id="useFollowingLatest" type="button"><strong>🆕 フォロー中・最新記事優先</strong><span>各ユーザーの記事を公開日時で比べ、固定記事ではなく最新の1記事を表示します。</span></button>
      <button class="feed-option" id="useFollowingFirst" type="button"><strong>📌 フォロー中・固定記事優先</strong><span>各ユーザーの記事一覧の1記事目を表示します。固定記事がある場合は、その記事が選ばれます。</span></button>
      <button class="feed-option" id="useFollowingProfile" type="button"><strong>👤 フォロー中・プロフィール優先</strong><span>プロフィール記事を設定しているユーザーだけを対象に、その記事を表示します。</span></button>
      <button class="feed-option" id="useThanksLatest" type="button"><strong>💐 ありがとう・最新記事優先</strong><span>過去7日間にスキやコメントをくれた人から、最新記事を1人1記事で表示します。</span></button>
      <button class="feed-option" id="useThanksProfile" type="button"><strong>🌷 ありがとう・プロフィール優先</strong><span>過去7日間に交流があり、プロフィール記事を設定している人だけを表示します。</span></button>
    </div>
    <p class="help">または、登録済みユーザーに関係なく、キーワードや <strong>#ハッシュタグ</strong> から新しい記事を探します。</p>
    <form class="search-row" id="searchForm">
      <input class="field" id="searchInput" autocomplete="off" maxlength="80" placeholder="例: 投資初心者 / #AI創作">
      <button class="primary" id="startSearch" type="submit">探す</button>
    </form>
    <div class="error" id="searchError" role="alert"></div>
    <div id="activeSource" hidden><span class="source-badge" id="sourceBadge"></span></div>
    <div class="search-actions">
      <button class="primary" id="backToWatch" type="button">特に読みたい人へ</button>
      <button class="icon-button" id="searchAgain" type="button">別の検索をする</button>
    </div>
    <p class="disclosure">#ハッシュタグは公開情報から取得します。通常のキーワード検索はFirefox拡張機能を通じ、ログイン中のnote検索結果だけをReaderへ渡します。ありがとうフィードの回数・日時・フォロー関係は端末内だけに保存し、公開記事を取るために選ばれたnoteユーザー名だけをReaderへ一時的に渡します。検索語・検索結果・交流履歴をデータベースへ保存しません。</p>
  </section>
</div>
<div class="sheet" id="magazineSheet" role="dialog" aria-modal="true" aria-labelledby="magazineTitle">
  <section class="panel">
    <div class="panel-head"><h2 id="magazineTitle">📚 マガジンに保存</h2><button id="closeMagazine" type="button" aria-label="閉じる">×</button></div>
    <div class="magazine-context"><span>保存する記事</span><strong id="magazineArticleTitle"></strong></div>
    <p class="help">一覧を開いただけでは追加されません。保存先の「追加」を押したときだけ、ログイン中のnoteアカウントで操作します。</p>
    <div class="magazine-status" id="magazineStatus" role="status"></div>
    <div class="magazine-list" id="magazineList"></div>
    <p class="disclosure">追加済みのマガジンは確認だけでき、Readerから削除はしません。マガジン名や追加履歴をReaderの運営側へ保存せず、マガジン追加だけで記事を読了扱いにすることもありません。</p>
  </section>
</div>
<div class="sheet" id="sheet" role="dialog" aria-modal="true" aria-labelledby="managerTitle">
  <section class="panel">
    <div class="panel-head"><h2 id="managerTitle">特に読みたい人</h2><button id="close" type="button" aria-label="閉じる">×</button></div>
    <div class="list-tools">
      <select class="field" id="watchlistSelect" aria-label="ウォッチリストを選択"></select>
      <button class="icon-button" id="newWatchlist" type="button">新規</button>
      <button class="icon-button" id="renameWatchlist" type="button">改名</button>
      <button class="icon-button" id="deleteWatchlist" type="button">削除</button>
    </div>
    <p class="help">複数のリストを作り、目的ごとに切り替えられます。選択中の登録数: <span class="watch-count" id="watchCount"></span></p>
    <form class="add-row" id="addForm">
      <input class="field" id="creatorInput" autocomplete="off" placeholder="note.com/ユーザー名 または @ユーザー名">
      <button class="primary" id="addCreator" type="submit">追加</button>
    </form>
    <div class="error" id="managerError" role="alert"></div>
    <div class="chips" id="chips"></div>
    <p class="help">50人をまとめて登録する場合は、URLやユーザー名を改行区切りで貼り付けられます。</p>
    <textarea class="field bulk" id="bulkInput" placeholder="https://note.com/example&#10;@another_user"></textarea>
    <button class="primary bulk-button" id="bulkAdd" type="button">まとめて追加</button>
    <p class="disclosure">登録内容と読了状態は、このブラウザ内だけに保存されます。記事を表示したり「次へ」で送っただけでは読了にならず、記事へのスキ、または新規コメントの送信に成功した時だけ読了になります。Firefox拡張機能の利用時は、コメントと返信スレッドをReader内で確認し、ご本人のnoteアカウントから送信できます。「未対応」は押したときだけ自分の全記事を確認し、返信の返信まで含めて、自分の赤いハートも返信もないコメントを表示します。初回以降は端末内の結果を使って差分確認します。認証情報とコメント本文を運営側へ保存することはありません。</p>
  </section>
</div>
<script>
(function(){
  'use strict';
  var CREATOR_STORAGE='nero.reader.creators.v1';
  var WATCHLIST_STORAGE='nero.reader.watchlists.v2';
  // v1 treated merely moving to the next card as "read".  Start a clean,
  // engagement-backed history instead of migrating those false positives.
  var COMPLETED_STORAGE='nero.reader.completed.v2';
  var MODE_STORAGE='nero.reader.mode.v1';
  var SOURCE_STORAGE='nero.reader.source.v1';
  var NERO_STORAGE='nero.reader.favorites.settings.v1';
  var NERO_HISTORY_STORAGE='nero.reader.favorites.history.v1';
  var NERO_TARGET='ネロのお気に入り🌙';
  var IS_NERO_MODE=true;
  var MAX_CREATORS=50;
  var MAX_WATCHLISTS=10;
  var DEFAULT_CREATORS=[];
  var legacyCreators=readJson(CREATOR_STORAGE,DEFAULT_CREATORS);
  var watchlists=readJson(WATCHLIST_STORAGE,null);
  if(!Array.isArray(watchlists)||!watchlists.length)watchlists=[{id:'favorites',name:'特に読みたい人',creators:Array.isArray(legacyCreators)?legacyCreators:DEFAULT_CREATORS}];
  var completedMap=readJson(COMPLETED_STORAGE,{});
  var viewMode=localStorage.getItem(MODE_STORAGE)==='all'?'all':'unfinished';
  var source=readJson(SOURCE_STORAGE,{mode:'watch',query:'',listId:watchlists[0].id});
  if(!source||!['watch','search','following','thanks'].includes(source.mode))source={mode:'watch',query:'',listId:watchlists[0].id};
  if(source.mode==='search'&&!String(source.query||'').trim())source={mode:'watch',query:'',listId:watchlists[0].id};
  if(source.mode==='following'&&!['latest','first','profile'].includes(source.followingMode))source.followingMode='latest';
  if(source.mode==='thanks'&&!['latest','profile'].includes(source.thanksMode))source.thanksMode='latest';
  if(!watchlists.some(function(list){return list.id===source.listId}))source.listId=watchlists[0].id;
  var creators=activeWatchlist().creators;
  var queue=[];
  var allRows=[];
  var articleCache=new Map();
  var likedStateCache=new Map();
  var current=0;
  var renderToken=0;
  var touchStart=null;
  var recycled=false;
  var feedPage=1;
  var loadingOlder=false;
  var olderExhausted=false;
  var MAX_FEED_PAGES=20;
  var likedSkipStreak=0;
  var extensionSearchSequence=0;
  var extensionFollowingSequence=0;
  var extensionStatusSequence=0;
  var extensionEngagementSequence=0;
  var extensionMagazineSequence=0;
  var magazineArticleUrl='';
  var magazineRequestId='';
  var magazineRows=[];
  var neroSettings=readJson(NERO_STORAGE,{account:'',tags:['#自己紹介','#note初心者','#はじめてのnote','#初投稿','#挑戦','#日常','#noteを楽しむ','#創作'],pages:2,dailyCap:40,autoLike:true});
  var neroHistory=readJson(NERO_HISTORY_STORAGE,[]);
  if(!Array.isArray(neroHistory))neroHistory=[];
  var neroCandidates=[];
  var neroAdding=false;
  var neroStopRequested=false;
  var neroAutoPending=new Set();
  var neroAutoQueue=[];
  var neroAutoRunning=false;
  var neroAutoStopped=false;
  var followingStats=null;
  var followingPool=[];
  var followingRounds=0;
  var thanksStats=null;
  var thanksPool=[];
  var thanksBatchCursor=0;
  var THANKS_BATCH_SIZE=50;

  function $(id){return document.getElementById(id)}
  function readJson(key,fallback){
    try{var value=JSON.parse(localStorage.getItem(key));return value||fallback}catch(_){return fallback}
  }
  function activeWatchlist(){return watchlists.find(function(list){return list.id===source.listId})||watchlists[0]}
  function saveWatchlists(){
    var active=activeWatchlist();if(active)active.creators=creators;
    localStorage.setItem(WATCHLIST_STORAGE,JSON.stringify(watchlists));
    localStorage.setItem(CREATOR_STORAGE,JSON.stringify(creators));
  }
  function saveCreators(){saveWatchlists()}
  function saveCompleted(){
    var entries=Object.entries(completedMap).sort(function(a,b){return b[1]-a[1]}).slice(0,3000);
    completedMap=Object.fromEntries(entries);
    localStorage.setItem(COMPLETED_STORAGE,JSON.stringify(completedMap));
  }
  function idFor(item){return String(item.key||item.url||'')}
  function articleUrlKey(value){
    try{
      var parsed=new URL(String(value||''),'https://note.com/');
      parsed.hash='';parsed.search='';
      return parsed.href.replace(/\/$/,'');
    }catch(_){return String(value||'').split('#')[0].split('?')[0].replace(/\/$/,'')}
  }
  function markArticleCompleted(articleUrl){
    if(!queue.length)return false;
    var wanted=articleUrlKey(articleUrl);
    var item=queue.find(function(row){return articleUrlKey(row.url)===wanted});
    if(!item)return false;
    completedMap[idFor(item)]=Date.now();saveCompleted();
    return true;
  }
  function safeUrl(value,base){
    if(!value)return '';
    try{
      var raw=String(value).trim();
      if(raw.indexOf('//')===0)raw='https:'+raw;
      var parsed=new URL(raw,base||'https://note.com/');
      return parsed.protocol==='https:'||parsed.protocol==='http:'?parsed.href:'';
    }catch(_){return ''}
  }
  function setNotice(message){
    var n=$('notice');n.textContent=message;n.classList.add('show');
    clearTimeout(setNotice.timer);setNotice.timer=setTimeout(function(){n.classList.remove('show')},1800);
  }
  function saveNeroSettings(){
    neroSettings={
      account:normalizeCreator($('neroAccount').value),
      tags:String($('neroTags').value||'').split(/[\n,、]+/).map(function(value){value=String(value||'').trim();return value?(value.charAt(0)==='#'?value:'#'+value):''}).filter(Boolean).slice(0,12),
      pages:Math.max(1,Math.min(Number($('neroPages').value)||2,3)),
      dailyCap:[20,40,60].includes(Number($('neroDailyCap').value))?Number($('neroDailyCap').value):40,
      autoLike:Boolean($('neroAutoLike').checked)
    };
    localStorage.setItem(NERO_STORAGE,JSON.stringify(neroSettings));
  }
  function cleanNeroHistory(){
    var cutoff=Date.now()-30*24*60*60*1000;
    neroHistory=neroHistory.filter(function(row){return row&&row.url&&Number(row.at)>=cutoff}).slice(-1200);
    localStorage.setItem(NERO_HISTORY_STORAGE,JSON.stringify(neroHistory));
  }
  function neroTodayCount(){
    var now=new Date(),start=new Date(now.getFullYear(),now.getMonth(),now.getDate()).getTime();
    return neroHistory.filter(function(row){return Number(row.at)>=start&&row.ok!==false}).length;
  }
  function setNeroStatus(message,isError){
    var node=$('neroStatus');node.textContent=String(message||'');node.classList.toggle('error',Boolean(isError));
  }
  function setNeroAccountStatus(message,isError){
    var node=$('neroAccountStatus');node.textContent=String(message||'');node.classList.toggle('error',Boolean(isError));
  }
  function requestNeroAccount(){
    if(document.documentElement.dataset.neroExtension!=='ready'||!extensionAtLeast('0.1.30'))return Promise.reject(new Error('ネロのお気に入り機能にはFirefox拡張機能0.1.30以降が必要です。'));
    return new Promise(function(resolve,reject){
      var id='account-'+Date.now()+'-'+(++extensionMagazineSequence);
      var timer=setTimeout(function(){cleanup();reject(new Error('ログイン中のnoteアカウント確認がタイムアウトしました。'))},12000);
      function cleanup(){clearTimeout(timer);document.removeEventListener('nero-account-result',receive)}
      function receive(){
        var result=null;try{result=JSON.parse(document.documentElement.dataset.neroAccountResult||'')}catch(_){return}
        if(!result||result.id!==id)return;cleanup();
        if(result.ok)resolve(result);else reject(new Error(result.message||'ログイン中のnoteアカウントを確認できませんでした。'));
      }
      document.addEventListener('nero-account-result',receive);
      document.documentElement.dataset.neroAccountRequest=JSON.stringify({id:id});
      document.dispatchEvent(new Event('nero-account-request'));
    });
  }
  async function verifyNeroAccount(){
    saveNeroSettings();
    var account=await requestNeroAccount();
    var current=normalizeCreator(account.urlname);
    if(!current)throw new Error('ログイン中のnote IDを確認できませんでした。');
    if(!neroSettings.account){
      neroSettings.account=current;$('neroAccount').value=current;saveNeroSettings();
      setNeroAccountStatus('@'+account.urlname+' をこの端末のネロとして固定しました。',false);
      return account;
    }
    if(current!==neroSettings.account)throw new Error('現在は @'+account.urlname+' でログイン中です。@'+neroSettings.account+' に切り替えてください。');
    setNeroAccountStatus('@'+account.urlname+' で本人確認できました。',false);
    return account;
  }
  function requestNeroMagazineAdd(article){
    return new Promise(function(resolve,reject){
      var id='nero-add-'+Date.now()+'-'+(++extensionMagazineSequence);
      var timer=setTimeout(function(){cleanup();reject(new Error('追加結果を確認できませんでした。二重追加を避けるため停止します。'))},35000);
      function cleanup(){clearTimeout(timer);document.removeEventListener('nero-magazine-add-result',receive)}
      function receive(){
        var result=null;try{result=JSON.parse(document.documentElement.dataset.neroMagazineAddResult||'')}catch(_){return}
        if(!result||result.id!==id)return;cleanup();
        if(result.ok)resolve(result);else reject(new Error(result.message||'マガジンへ追加できませんでした。'));
      }
      document.addEventListener('nero-magazine-add-result',receive);
      document.documentElement.dataset.neroMagazineAddRequest=JSON.stringify({id:id,articleUrl:articleUrlKey(article.url),magazineKey:'',magazineName:NERO_TARGET,magazineIndex:0,expectedAccount:neroSettings.account});
      document.dispatchEvent(new Event('nero-magazine-add-request'));
    });
  }
  function neroKeywordScore(item){
    var text=(String(item.name||'')+' '+String(item.description||'')).replace(/\s+/g,' ');
    var score=0,reasons=[];
    var groups=[
      {pattern:/自己紹介|はじめまして|プロフィール|note初心者|初投稿|初めてのnote/i,points:5,label:'人柄・自己紹介'},
      {pattern:/挑戦|頑張|やってみた|書いてみた|作ってみた|始めました|続けて|成長|学び|振り返り|記録/i,points:4,label:'挑戦・積み重ね'},
      {pattern:/つなが|交流|仲間|コメント|読んでほしい|おすすめ記事|一緒に|遊びに/i,points:5,label:'つながり'},
      {pattern:/会社員|子育て|育児|仕事|暮らし|日常|家族/i,points:4,label:'等身大の日常'}
    ];
    groups.forEach(function(group){if(group.pattern.test(text)){score+=group.points;reasons.push(group.label)}});
    var blocked=/必ず稼げる|爆益|最短で稼|コピペだけ|誰でも月[0-9０-９]|フォロバ100|スキ返し100|相互フォロー100/i.test(text);
    if(blocked)reasons.push('強い勧誘表現');
    return {score:score,reasons:reasons,blocked:blocked};
  }
  function renderNeroCandidates(){
    var root=$('neroResults');root.innerHTML='';
    if(!neroCandidates.length){root.innerHTML='<div class="nero-empty">条件に合う候補がまだありません。</div>';$('runNero').disabled=true;return}
    neroCandidates.forEach(function(item,index){
      var card=document.createElement('label');card.className='nero-card';
      var check=document.createElement('input');check.type='checkbox';check.checked=Boolean(item.selected);check.addEventListener('change',function(){item.selected=check.checked;updateNeroRunLabel()});
      var copy=document.createElement('div');
      var title=document.createElement('strong');title.textContent=item.name||'無題の記事';
      var meta=document.createElement('small');meta.textContent='@'+(item.urlname||'unknown')+(item.publishAt?'・'+dateText(item.publishAt):'')+'・思想スコア '+item.score;
      var reasons=document.createElement('div');reasons.className='nero-reasons';
      if(item.liked){var liked=document.createElement('span');liked.className='nero-reason liked';liked.textContent='♥ スキ済み';reasons.appendChild(liked)}
      (item.reasons||[]).forEach(function(value){var badge=document.createElement('span');badge.className='nero-reason'+(value==='強い勧誘表現'?' warn':'');badge.textContent=value;reasons.appendChild(badge)});
      var sourceBadge=document.createElement('span');sourceBadge.className='nero-reason';sourceBadge.textContent=item.sourceTag;reasons.appendChild(sourceBadge);
      copy.append(title,meta,reasons);card.append(check,copy);root.appendChild(card);
    });
    updateNeroRunLabel();
  }
  function updateNeroRunLabel(){
    var selected=neroCandidates.filter(function(item){return item.selected}).length;
    $('runNero').disabled=neroAdding||selected===0;
    if(!neroAdding)$('runNero').textContent='選んだ'+selected+'件をマガジンへ追加';
  }
  async function scanNeroCandidates(){
    saveNeroSettings();cleanNeroHistory();
    if(!neroSettings.tags.length)throw new Error('検索するハッシュタグを1つ以上入力してください。');
    $('scanNero').disabled=true;setNeroStatus('ハッシュタグから候補を探しています…',false);
    var seen=new Map(),requests=[];
    neroSettings.tags.forEach(function(tag){for(var page=1;page<=neroSettings.pages;page++)requests.push({tag:tag,page:page})});
    for(var i=0;i<requests.length;i++){
      var request=requests[i];setNeroStatus('検索中 '+(i+1)+' / '+requests.length+'：'+request.tag,false);
      try{
        var response=await fetch('/api/search-feed?q='+encodeURIComponent(request.tag)+'&page='+request.page);
        var payload=await response.json();
        (payload.items||[]).forEach(function(item){
          var url=articleUrlKey(item.url);if(!url||seen.has(url))return;
          var judged=neroKeywordScore(item);seen.set(url,Object.assign({},item,{url:url,sourceTag:request.tag,score:judged.score,reasons:judged.reasons,blocked:judged.blocked,liked:false,selected:judged.score>=4&&!judged.blocked}));
        });
      }catch(_){/* The remaining tags can still produce a useful list. */}
      if(seen.size>=120)break;
    }
    neroCandidates=Array.from(seen.values()).filter(function(item){return !neroHistory.some(function(row){return articleUrlKey(row.url)===item.url&&row.ok!==false})});
    if(document.documentElement.dataset.neroExtension==='ready'&&neroCandidates.length){
      for(var start=0;start<neroCandidates.length;start+=30){
        try{
          var statuses=await requestStatusBatch(neroCandidates.slice(start,start+30).map(function(item){return item.url}));
          statuses.forEach(function(status){var found=neroCandidates.find(function(item){return item.url===articleUrlKey(status.url)});if(found&&status.ok&&status.liked){found.liked=true;found.selected=true;found.reasons.unshift('ネロが選んだ記事')}});
        }catch(_){break}
      }
    }
    neroCandidates.sort(function(left,right){return Number(right.liked)-Number(left.liked)||right.score-left.score||(Date.parse(right.publishAt||'')||0)-(Date.parse(left.publishAt||'')||0)});
    renderNeroCandidates();setNeroStatus(neroCandidates.length+'件を確認しました。スキ済みと思想スコア4以上を選択しています。',false);$('scanNero').disabled=false;
  }
  async function runNeroQueue(){
    if(neroAdding){neroStopRequested=true;$('runNero').textContent='停止しています…';return}
    saveNeroSettings();await verifyNeroAccount();cleanNeroHistory();
    var remaining=Math.max(0,neroSettings.dailyCap-neroTodayCount());
    var targets=neroCandidates.filter(function(item){return item.selected&&!item.blocked}).slice(0,remaining);
    if(!remaining)throw new Error('本日の追加上限 '+neroSettings.dailyCap+'件に達しています。');
    if(!targets.length)throw new Error('追加する記事を選んでください。');
    neroAdding=true;neroStopRequested=false;neroAutoStopped=false;$('runNero').disabled=false;$('runNero').classList.add('stop');$('runNero').textContent='停止する';
    try{
      for(var i=0;i<targets.length;i++){
        if(neroStopRequested){setNeroStatus('停止しました。追加済み '+i+'件。',false);break}
        var item=targets[i];setNeroStatus('追加中 '+(i+1)+' / '+targets.length+'：'+(item.name||'無題の記事'),false);
        var result=await requestNeroMagazineAdd(item);
        neroHistory.push({url:item.url,name:item.name||'',at:Date.now(),already:Boolean(result.already),ok:true});cleanNeroHistory();
        item.selected=false;item.added=true;
        if(i<targets.length-1){setNeroStatus('追加済み '+(i+1)+'件。次の操作まで待機しています…',false);await new Promise(function(resolve){setTimeout(resolve,12000)})}
      }
      if(!neroStopRequested)setNeroStatus('完了しました。今回 '+targets.length+'件を「'+NERO_TARGET+'」へ追加しました。',false);
    }catch(error){
      neroAutoStopped=true;
      setNeroStatus('追加を停止しました。'+(error.message||String(error))+' 自動追加も再確認まで停止しています。',true);
      throw error;
    }finally{
      neroAdding=false;neroStopRequested=false;$('runNero').classList.remove('stop');renderNeroCandidates();processNeroAutoQueue();
    }
  }
  function autoAddNeroFavorite(articleUrl){
    if(!IS_NERO_MODE||!neroSettings.autoLike)return;
    var url=articleUrlKey(articleUrl);if(!url||neroAutoPending.has(url)||neroHistory.some(function(row){return articleUrlKey(row.url)===url&&row.ok!==false}))return;
    neroAutoPending.add(url);neroAutoQueue.push(url);
    if(neroAutoStopped){setNotice('🌙 自動追加停止中・未処理 '+neroAutoQueue.length+'件');return}
    setNotice('🌙 マガジン追加待ち '+neroAutoQueue.length+'件');
    processNeroAutoQueue();
  }
  async function processNeroAutoQueue(){
    if(neroAutoRunning||neroAdding||neroAutoStopped||!neroAutoQueue.length)return;
    neroAutoRunning=true;
    try{
      await verifyNeroAccount();
      while(neroAutoQueue.length&&!neroAdding&&!neroAutoStopped){
        if(neroTodayCount()>=neroSettings.dailyCap)throw new Error('本日の自動追加上限 '+neroSettings.dailyCap+'件に達しました。');
        var url=neroAutoQueue[0];
        await requestNeroMagazineAdd({url:url});
        neroHistory.push({url:url,name:'Readerでスキした記事',at:Date.now(),ok:true});cleanNeroHistory();
        neroAutoQueue.shift();neroAutoPending.delete(url);
        setNotice('🌙 「'+NERO_TARGET+'」へ追加しました');
        if(neroAutoQueue.length)await new Promise(function(resolve){setTimeout(resolve,12000)});
      }
    }catch(error){
      neroAutoStopped=true;
      setNotice('🌙 自動追加を停止：'+(error.message||String(error)));
      setNeroStatus('自動追加を停止しました。'+(error.message||String(error))+' 未処理 '+neroAutoQueue.length+'件。',true);
    }finally{neroAutoRunning=false}
  }
  function updateBridgeStatus(){
    var status=$('neroExtensionStatus');if(!status)return;
    var ready=document.documentElement.dataset.neroExtension==='ready';
    var version=String(document.documentElement.dataset.neroExtensionVersion||'').trim();
    status.classList.toggle('connected',ready);
    status.textContent=ready?'連携中'+(version?' v'+version:''):'未接続';
    status.title=ready?'Firefox拡張機能'+(version?' v'+version:'')+'と連携中':'拡張機能が未接続です。タップすると確認方法を表示します';
  }
  function shuffle(rows){
    var copy=rows.slice();
    for(var i=copy.length-1;i>0;i--){var j=Math.floor(Math.random()*(i+1));var x=copy[i];copy[i]=copy[j];copy[j]=x}
    return copy;
  }
  function normalizeCreator(raw){
    var value=String(raw||'').trim().replace(/^https?:\/\/(?:www\.)?note\.com\//i,'').replace(/^@/,'').split(/[/?#]/)[0].replace(/[^a-zA-Z0-9_-]/g,'').slice(0,80);
    return value;
  }
  function dateText(value){
    if(!value)return '';
    var date=new Date(value);
    return Number.isNaN(date.getTime())?'':new Intl.DateTimeFormat('ja-JP',{year:'numeric',month:'short',day:'numeric'}).format(date);
  }
  function escapeText(value){
    var div=document.createElement('div');div.textContent=String(value||'');return div.innerHTML;
  }
  function sanitizeNoteHtml(raw){
    raw=String(raw||'');
    if(!raw)return '';
    if(!/<[a-z][\s\S]*>/i.test(raw))return '<div class="plain-copy">'+escapeText(raw)+'</div>';
    var doc=new DOMParser().parseFromString('<div>'+raw+'</div>','text/html');
    var root=doc.body.firstElementChild;
    var out=document.createElement('div');
    var allowed=new Set(['P','BR','A','STRONG','B','EM','I','U','S','H1','H2','H3','H4','UL','OL','LI','BLOCKQUOTE','PRE','CODE','HR','FIGURE','FIGCAPTION','IMG','PICTURE','SOURCE','VIDEO']);
    var drop=new Set(['SCRIPT','STYLE','NOSCRIPT','OBJECT','EMBED','FORM','INPUT','BUTTON','SVG','MATH','TEMPLATE']);
    function noteKeyFromUrl(value){
      var href=safeUrl(value,'https://note.com/');if(!href)return '';
      var match=href.match(/note\.com\/[a-zA-Z0-9_-]+\/n\/([a-zA-Z0-9_-]+)/i)||href.match(/\/notes\/([a-zA-Z0-9_-]+)/i);
      if(match)return match[1];
      try{var nested=new URL(href).searchParams.get('url');return nested?noteKeyFromUrl(nested):''}catch(_){return ''}
    }
    function internalLink(href,label){
      var key=noteKeyFromUrl(href);if(!key)return null;
      var link=document.createElement('a');link.href=href||'#';link.dataset.noteKey=key;link.className='note-link-card';link.textContent=label||'関連記事をReaderで開く';return link;
    }
    function noteEmbed(value){
      var href=safeUrl(value,'https://note.com/');if(!href)return null;
      try{
        var url=new URL(href),match;
        if(url.hostname==='note.com'&&(match=url.pathname.match(/^\/embed\/notes\/([a-zA-Z0-9_-]+)$/)))return {src:url.href,type:'article',key:match[1],title:'note関連記事'};
        if(url.hostname==='note.com'&&(match=url.pathname.match(/^\/[a-zA-Z0-9_-]+\/n\/([a-zA-Z0-9_-]+)$/)))return {src:'https://note.com/embed/notes/'+match[1],type:'article',key:match[1],title:'note関連記事'};
        if(url.hostname==='note.com'&&/^\/qa\/embed\/[a-zA-Z0-9_-]+$/.test(url.pathname))return {src:url.href,type:'qa',title:'note 質問箱'};
        if(url.hostname==='note.com'&&(match=url.pathname.match(/^\/qa\/([a-zA-Z0-9_-]+)$/)))return {src:'https://note.com/qa/embed/'+match[1],type:'qa',title:'note 質問箱'};
        if(url.hostname==='note.com'&&/^\/embed\/sounds\/[a-zA-Z0-9_-]+$/.test(url.pathname))return {src:url.href,type:'sound',title:'note 音声'};
        if(url.hostname==='money.note.com'&&/^\/embed\/charts\/[0-9]+$/.test(url.pathname))return {src:url.href,type:'money',title:'noteマネー 株価チャート'};
      }catch(_){}
      return null;
    }
    function noteResource(value){
      var href=safeUrl(value,'https://note.com/');if(!href)return null;
      try{
        var url=new URL(href),path=url.pathname.replace(/\/+$/,'')||'/',match;
        if(url.hostname!=='note.com'&&url.hostname!=='www.note.com')return null;
        if((match=path.match(/^\/([a-zA-Z0-9_-]+)\/n\/([a-zA-Z0-9_-]+)$/)))return {kind:'記事',title:'noteの記事を開く',urlname:match[1]};
        if((match=path.match(/^\/([a-zA-Z0-9_-]+)\/m\/([a-zA-Z0-9_-]+)$/))||path.match(/^\/magazines\/([a-zA-Z0-9_-]+)$/))return {kind:'マガジン',title:'noteマガジンを開く',urlname:match.length>2?match[1]:''};
        if((match=path.match(/^\/([a-zA-Z0-9_-]+)\/membership(?:\/.*)?$/))||/^\/membership(?:\/.*)?$/.test(path))return {kind:'メンバーシップ',title:'noteメンバーシップを開く',urlname:match&&match[1]||''};
        if(/^\/qa(?:\/|$)/.test(path)||/^\/[a-zA-Z0-9_-]+\/(?:qa|questions?|question-box)(?:\/|$)/i.test(path)||/\/(?:questions?|question-box)(?:\/|$)/i.test(path))return {kind:'質問箱',title:'note質問箱を開く',urlname:''};
        if((match=path.match(/^\/([a-zA-Z0-9_-]+)$/))&&!['help','info','terms','privacy','login','signup','search','explore','notifications','messages','settings'].includes(match[1]))return {kind:'クリエイター',title:'noteクリエイターページを開く',urlname:match[1]};
      }catch(_){}
      return null;
    }
    function externalLinkCard(value,hint){
      var href=safeUrl(value,'https://note.com/');if(!href)return document.createDocumentFragment();
      var card=document.createElement('a');card.href=href;card.target='_blank';card.rel='noopener noreferrer';card.className='external-link-card';
      var label=document.createElement('span');label.textContent='記事内リンク';
      var title=document.createElement('strong');
      var detail=document.createElement('small');
      var resource=noteResource(href);
      if(resource){card.classList.add('note-resource');label.textContent='note '+resource.kind;title.textContent=resource.title+(resource.urlname?'（@'+resource.urlname+'）':'')}
      else try{title.textContent=String(hint||'').trim()||new URL(href).hostname+' を開く'}catch(_){title.textContent='リンク先を開く'}
      detail.textContent=href;card.append(label,title,detail);return card;
    }
    function embedFrame(node){
      var embed=noteEmbed(node.getAttribute('src')||node.getAttribute('data-src'));if(!embed)return document.createDocumentFragment();
      var shell=document.createElement('div');shell.className='note-embed-shell '+embed.type;
      var frame=document.createElement('iframe');frame.src=embed.src;frame.className='note-embed-frame '+embed.type;frame.title=node.getAttribute('title')||embed.title;frame.loading='lazy';frame.referrerPolicy='strict-origin-when-cross-origin';
      frame.setAttribute('sandbox','allow-scripts allow-same-origin allow-forms allow-popups allow-popups-to-escape-sandbox');
      shell.appendChild(frame);
      if(embed.key){
        var open=internalLink(embed.src,'Readerでこの記事を読む');
        if(open){open.className='note-embed-open';shell.appendChild(open)}
      }
      return shell;
    }
    function clean(node){
      if(node.nodeType===Node.TEXT_NODE)return document.createTextNode(node.textContent||'');
      if(node.nodeType!==Node.ELEMENT_NODE)return document.createDocumentFragment();
      var tag=node.tagName.toUpperCase();
      if(tag==='IFRAME'){
        return embedFrame(node);
      }
      if(tag==='FIGURE'&&node.getAttribute('data-src')){
        var embedded=embedFrame(node);
        if(embedded.nodeType===Node.ELEMENT_NODE)return embedded;
        return externalLinkCard(node.getAttribute('data-src'),node.textContent);
      }
      if(drop.has(tag))return document.createDocumentFragment();
      if(!allowed.has(tag)){
        var fragment=document.createDocumentFragment();
        Array.from(node.childNodes).forEach(function(child){fragment.appendChild(clean(child))});
        return fragment;
      }
      var el=document.createElement(tag.toLowerCase());
      if(tag==='A'){
        var href=safeUrl(node.getAttribute('href'),'https://note.com/');
        if(href){
          el.href=href;
          var key=noteKeyFromUrl(href);
          if(key)el.dataset.noteKey=key;
          else{el.target='_blank';el.rel='noopener noreferrer'}
        }
      }
      if(tag==='IMG'){
        var src=safeUrl(node.getAttribute('data-src')||node.getAttribute('data-original')||node.getAttribute('src'),'https://note.com/');
        if(!src)return document.createDocumentFragment();
        el.src=src;el.alt=node.getAttribute('alt')||'';el.loading='lazy';el.decoding='async';
      }
      if(tag==='SOURCE'){
        var source=safeUrl(node.getAttribute('src'),'https://note.com/');
        if(source)el.src=source;
        var type=node.getAttribute('type');if(type&&/^[a-z0-9.+-]+\/[a-z0-9.+-]+$/i.test(type))el.type=type;
      }
      if(tag==='VIDEO'){
        var videoSrc=safeUrl(node.getAttribute('src'),'https://note.com/');
        var poster=safeUrl(node.getAttribute('poster'),'https://note.com/');
        if(videoSrc)el.src=videoSrc;if(poster)el.poster=poster;el.controls=true;el.preload='metadata';
      }
      Array.from(node.childNodes).forEach(function(child){el.appendChild(clean(child))});
      return el;
    }
    Array.from(root.childNodes).forEach(function(node){out.appendChild(clean(node))});
    return out.innerHTML;
  }

  function renderChips(){
    creators=activeWatchlist().creators;
    $('watchlistSelect').innerHTML='';
    watchlists.forEach(function(list){
      var option=document.createElement('option');option.value=list.id;option.textContent=list.name+'（'+list.creators.length+'人）';option.selected=list.id===activeWatchlist().id;$('watchlistSelect').appendChild(option);
    });
    $('watchCount').textContent=creators.length+' / '+MAX_CREATORS;
    $('chips').innerHTML='';
    creators.forEach(function(creator){
      var chip=document.createElement('div');chip.className='chip';
      var label=document.createElement('span');label.textContent='@'+creator.urlname;
      var remove=document.createElement('button');remove.type='button';remove.textContent='×';remove.setAttribute('aria-label','@'+creator.urlname+' を削除');
      remove.addEventListener('click',function(){
        creators=creators.filter(function(row){return row.urlname!==creator.urlname});
        activeWatchlist().creators=creators;saveCreators();renderChips();loadFeeds();
      });
      chip.append(label,remove);$('chips').appendChild(chip);
    });
  }

  async function fetchFeedPage(page){
    if(source.mode==='search'){
      var query=String(source.query||'').trim();
      if(!query)throw new Error('検索語を入力してください');
      if(query.charAt(0)!=='#')return requestExtensionSearch(query,page);
      var searchResponse=await fetch('/api/search-feed?q='+encodeURIComponent(query)+'&page='+page);
      var searchPayload=await searchResponse.json();
      if(!searchResponse.ok)throw new Error(searchPayload.error||'検索結果を取得できませんでした');
      return searchPayload;
    }
    if(source.mode==='thanks'){
      if(!thanksPool.length){
        var engagement=await requestEngagementScan();
        thanksStats=engagement;
        thanksPool=Array.isArray(engagement.creators)?engagement.creators:[];
        thanksBatchCursor=0;
      }
      var batch=thanksPool.slice(thanksBatchCursor,thanksBatchCursor+THANKS_BATCH_SIZE);
      if(!batch.length)return {items:[],failed:[],thanksStats:thanksStats};
      thanksBatchCursor+=batch.length;
      var names=batch.map(function(creator){return creator.urlname}).filter(Boolean);
      var thanksMode=source.thanksMode==='profile'?'profile':'latest';
      var thanksResponse=await fetch('/api/mixed-feed?limit=2&page=1&selection='+encodeURIComponent(thanksMode)+'&creators='+encodeURIComponent(names.join(',')));
      var thanksPayload=await thanksResponse.json();
      if(!thanksResponse.ok)throw new Error(thanksPayload.error||'ありがとうフィードを取得できませんでした');
      var byCreator=new Map();
      (thanksPayload.items||[]).forEach(function(item){if(!byCreator.has(item.urlname))byCreator.set(item.urlname,item)});
      thanksPayload.items=batch.map(function(engagementRow){
        var item=byCreator.get(engagementRow.urlname);
        if(!item)return null;
        item.engagement=engagementRow;
        return item;
      }).filter(Boolean);
      thanksPayload.thanksStats=thanksStats;
      return thanksPayload;
    }
    if(source.mode==='following'){
      if(page===1||!followingPool.length){
        var following=await requestFollowingSample(50);
        followingStats=following;
        followingPool=(following.creators||[]).map(function(c){return c.urlname}).filter(Boolean);
      }
      var followingNames=followingPool.join(',');
      if(!followingNames)throw new Error('記事を公開しているフォロー中ユーザーを抽選できませんでした');
      var followingMode=['latest','first','profile'].includes(source.followingMode)?source.followingMode:'latest';
      var followingResponse=await fetch('/api/mixed-feed?limit=2&page='+page+'&selection='+encodeURIComponent(followingMode)+'&creators='+encodeURIComponent(followingNames));
      var followingPayload=await followingResponse.json();
      if(!followingResponse.ok)throw new Error(followingPayload.error||'フォロー中フィードを取得できませんでした');
      followingPayload.followingStats=followingStats;
      return followingPayload;
    }
    var names=creators.map(function(c){return c.urlname}).join(',');
    var response=await fetch('/api/mixed-feed?limit=8&page='+page+'&creators='+encodeURIComponent(names));
    var payload=await response.json();
    if(!response.ok)throw new Error(payload.error||'フィードを取得できませんでした');
    return payload;
  }

  function requestEngagementScan(){
    if(!extensionAtLeast('0.1.27'))return Promise.reject(new Error('ありがとうフィードにはFirefox拡張機能0.1.27以降が必要です。'));
    return new Promise(function(resolve,reject){
      var id='engagement-'+Date.now()+'-'+(++extensionEngagementSequence);
      var timer=setTimeout(function(){cleanup();reject(new Error('交流履歴の確認がタイムアウトしました。もう一度お試しください。'))},10*60*1000);
      function cleanup(){clearTimeout(timer);document.removeEventListener('nero-engagement-result',receive);document.removeEventListener('nero-engagement-progress',progress)}
      function progress(){
        var value=null;try{value=JSON.parse(document.documentElement.dataset.neroEngagementProgress||'')}catch(_){return}
        if(value&&value.id===id&&value.message)$('body').innerHTML='<div class="loading">'+escapeText(value.message)+'</div>';
      }
      function receive(){
        var result=null;try{result=JSON.parse(document.documentElement.dataset.neroEngagementResult||'')}catch(_){return}
        if(!result||result.id!==id)return;
        cleanup();
        if(result.ok)resolve(result);else reject(new Error(result.message||'ありがとうフィードを作成できませんでした'));
      }
      document.addEventListener('nero-engagement-progress',progress);
      document.addEventListener('nero-engagement-result',receive);
      document.documentElement.dataset.neroEngagementRequest=JSON.stringify({id:id,days:7});
      document.dispatchEvent(new Event('nero-engagement-request'));
    });
  }

  function requestFollowingSample(sampleSize){
    if(document.documentElement.dataset.neroExtension!=='ready'){
      return Promise.reject(new Error('フォロー中フィードにはFirefox拡張機能0.1.8が必要です。'));
    }
    return new Promise(function(resolve,reject){
      var id='following-'+Date.now()+'-'+(++extensionFollowingSequence);
      var timer=setTimeout(function(){cleanup();reject(new Error('フォロー一覧の抽選がタイムアウトしました。もう一度お試しください。'))},25000);
      function cleanup(){clearTimeout(timer);document.removeEventListener('nero-followings-result',receive)}
      function receive(){
        var raw=document.documentElement.dataset.neroFollowingsResult||'';
        var result=null;try{result=JSON.parse(raw)}catch(_){return}
        if(!result||result.id!==id)return;
        cleanup();
        if(result.ok)resolve(result);
        else reject(new Error(result.message||'フォロー一覧を取得できませんでした'));
      }
      document.addEventListener('nero-followings-result',receive);
      document.documentElement.dataset.neroFollowingsRequest=JSON.stringify({id:id,sampleSize:sampleSize});
      document.dispatchEvent(new Event('nero-followings-request'));
    });
  }

  function extensionAtLeast(required){
    var current=String(document.documentElement.dataset.neroExtensionVersion||'0').split('.').map(function(value){return Number(value)||0});
    var minimum=String(required||'0').split('.').map(function(value){return Number(value)||0});
    for(var i=0;i<Math.max(current.length,minimum.length);i++){
      var left=current[i]||0,right=minimum[i]||0;
      if(left!==right)return left>right;
    }
    return true;
  }

  function requestStatusBatch(urls){
    if(!extensionAtLeast('0.1.8')){
      return Promise.reject(new Error('未スキだけの表示にはFirefox拡張機能0.1.8以降が必要です。'));
    }
    return new Promise(function(resolve,reject){
      var id='status-'+Date.now()+'-'+(++extensionStatusSequence);
      var timer=setTimeout(function(){cleanup();reject(new Error('未スキ記事の確認がタイムアウトしました。'))},15000);
      function cleanup(){clearTimeout(timer);document.removeEventListener('nero-status-batch-result',receive)}
      function receive(){
        var raw=document.documentElement.dataset.neroStatusBatchResult||'';
        var result=null;try{result=JSON.parse(raw)}catch(_){return}
        if(!result||result.id!==id)return;
        cleanup();
        if(result.ok)resolve(Array.isArray(result.results)?result.results:[]);
        else reject(new Error(result.message||'未スキ記事を確認できませんでした'));
      }
      document.addEventListener('nero-status-batch-result',receive);
      document.documentElement.dataset.neroStatusBatchRequest=JSON.stringify({id:id,urls:urls});
      document.dispatchEvent(new Event('nero-status-batch-request'));
    });
  }

  async function selectPlayableRows(rows,target){
    var candidates=(source.mode==='thanks'?(rows||[]).slice():shuffle(rows||[])).filter(function(item){return safeUrl(item.url)});
    if(viewMode!=='unfinished')return candidates.slice(0,target||candidates.length);
    if(!extensionAtLeast('0.1.8'))throw new Error('未スキだけの表示にはFirefox拡張機能0.1.8以降が必要です。');
    var accepted=[];
    for(var start=0;start<candidates.length&&accepted.length<(target||20);start+=30){
      var chunk=candidates.slice(start,start+30);
      var pending=chunk.filter(function(item){return !likedStateCache.has(item.url)});
      if(pending.length){
        var results=await requestStatusBatch(pending.map(function(item){return item.url}));
        results.forEach(function(result){likedStateCache.set(result.url,result.ok?(result.liked?'liked':'unliked'):'unknown')});
        pending.forEach(function(item){if(!likedStateCache.has(item.url))likedStateCache.set(item.url,'unknown')});
      }
      chunk.forEach(function(item){if(likedStateCache.get(item.url)==='unliked')accepted.push(item)});
    }
    return accepted.slice(0,target||20);
  }

  function requestExtensionSearch(query,page){
    if(document.documentElement.dataset.neroExtension!=='ready'){
      return Promise.reject(new Error('通常のキーワード検索にはFirefox拡張機能0.1.6が必要です。#ハッシュタグ検索はそのまま使えます。'));
    }
    return new Promise(function(resolve,reject){
      var id='search-'+Date.now()+'-'+(++extensionSearchSequence);
      var timer=setTimeout(function(){cleanup();reject(new Error('note検索がタイムアウトしました。もう一度お試しください。'))},10000);
      function cleanup(){clearTimeout(timer);document.removeEventListener('nero-search-result',receive)}
      function receive(){
        var raw=document.documentElement.dataset.neroSearchResult||'';
        var result=null;try{result=JSON.parse(raw)}catch(_){return}
        if(!result||result.id!==id)return;
        cleanup();
        if(result.ok)resolve({items:Array.isArray(result.items)?result.items:[],failed:[],page:page});
        else reject(new Error(result.message||'note検索結果を取得できませんでした'));
      }
      document.addEventListener('nero-search-result',receive);
      document.documentElement.dataset.neroSearchRequest=JSON.stringify({id:id,query:query,page:page});
      document.dispatchEvent(new Event('nero-search-request'));
    });
  }

  function appendUniqueRows(rows){
    var known=new Set(allRows.map(idFor));
    var added=[];
    (rows||[]).forEach(function(item){
      var id=idFor(item);
      if(id&&!known.has(id)){known.add(id);allRows.push(item);added.push(item)}
    });
    return added;
  }

  async function loadFeeds(){
    renderChips();
    if(source.mode==='watch'&&!creators.length){
      queue=[];allRows=[];$('articleTitle').textContent='ウォッチリストが空です';$('body').innerHTML='<div class="loading">右上の「登録」からnoteクリエイターを追加してください。</div>';
      updateControls();return;
    }
    var loadingText=source.mode==='search'?'検索結果を探しています…':(source.mode==='following'?'フォロー中の人を抽選しています…':(source.mode==='thanks'?'過去7日間のありがとうを確認しています…':'未読の記事を探しています…'));
    $('body').innerHTML='<div class="loading">'+loadingText+'</div>';
    $('articleTitle').textContent='フィードを準備中';
    $('eyecatch').style.display='none';
    try{
      allRows=[];queue=[];feedPage=1;olderExhausted=false;recycled=false;followingStats=null;followingPool=[];followingRounds=1;thanksStats=null;thanksPool=[];thanksBatchCursor=0;
      var payload=await fetchFeedPage(feedPage);
      appendUniqueRows(payload.items||[]);
      var candidates=viewMode==='unfinished'?allRows.filter(function(item){return !completedMap[idFor(item)]}):allRows.slice();
      if(viewMode==='unfinished'){$('body').innerHTML='<div class="loading">未完了の記事だけを確認しています…</div>'}
      queue=await selectPlayableRows(candidates,20);
      var initialScanLimit=viewMode==='unfinished'?Math.min(MAX_FEED_PAGES,8):2;
      while(!queue.length&&(source.mode==='following'?followingRounds<initialScanLimit:(source.mode==='thanks'?thanksBatchCursor<thanksPool.length:feedPage<initialScanLimit))){
        if(source.mode==='following'){
          followingRounds++;followingPool=[];
        }else if(source.mode!=='thanks')feedPage++;
        $('body').innerHTML='<div class="loading">'+(viewMode==='unfinished'?'未完了の記事を過去へ確認中… '+allRows.length+'件':'過去の記事を探しています…')+'</div>';
        payload=await fetchFeedPage(source.mode==='following'||source.mode==='thanks'?1:feedPage);
        var older=appendUniqueRows(payload.items||[]);
        if(viewMode==='unfinished')older=older.filter(function(item){return !completedMap[idFor(item)]});
        queue=await selectPlayableRows(older,20);
        if(!(payload.items||[]).length)break;
      }
      current=0;
      if(payload.failed&&payload.failed.length)setNotice(payload.failed.length+'人は今回読み込めませんでした');
      if(payload.followingStats&&payload.followingStats.legacyLimit)setNotice('今回はnoteの予備経路で600人を母集団にしています');
      else if(payload.followingStats&&payload.followingStats.capped)setNotice('フォロー一覧のうち最大5,000人を母集団にしています');
      else if(payload.thanksStats&&payload.thanksStats.failedCount)setNotice('一部の記事は取得できず、確認できた交流から表示しています');
      if(!queue.length)throw new Error(viewMode==='unfinished'?'未完了の記事が見つかりませんでした。モードを「すべて」にすると再読できます。':'表示できる記事が見つかりませんでした');
      showCurrent();
    }catch(error){
      queue=[];$('articleTitle').textContent='読み込みに失敗しました';
      $('body').innerHTML='<div class="loading">'+escapeText(error.message||error)+'<br><br><button class="icon-button" id="retry" type="button">もう一度試す</button></div>';
      var retry=$('retry');if(retry)retry.addEventListener('click',loadFeeds);
      updateControls();
    }
  }

  function updateControls(){
    var list=activeWatchlist();
    var followingLabel=source.followingMode==='first'?'固定':(source.followingMode==='profile'?'プロフィール':'最新');
    var thanksLabel=source.thanksMode==='profile'?'プロフィール':'最新';
    $('counter').textContent=source.mode==='search'?'検索: '+source.query:(source.mode==='following'?(followingLabel+'・'+(followingStats?followingStats.eligibleCount+'人から抽選':'フォロー中から抽選')):(source.mode==='thanks'?(thanksLabel+'・'+(thanksStats&&thanksStats.stats?thanksStats.stats.creatorCount+'人のありがとう':'交流を確認中')):(list.name+' '+creators.length+'人')));
    $('mode').textContent=viewMode==='unfinished'?'未完了':'すべて';
    $('mode').title=viewMode==='unfinished'?'スキも新規コメントもない記事だけ表示します。押すとすべて表示':'読了済みも含めて表示します。押すと未完了だけ表示';
    $('discover').textContent=source.mode==='search'?'検索':(source.mode==='following'?'フォロー':(source.mode==='thanks'?'感謝':'特選'));
    $('position').textContent=queue.length?(current+1)+' / '+queue.length:'';
    $('prev').setAttribute('aria-disabled',current<=0?'true':'false');
    $('next').setAttribute('aria-disabled',queue.length?'false':'true');
  }

  function relationText(engagement){
    if(!engagement)return '';
    var following=engagement.isFollowing,follower=engagement.isFollower;
    if(following===true&&follower===true)return '相互フォロー';
    if(follower===true)return 'あなたをフォロー中';
    if(following===true)return 'こちらからフォロー中';
    if(following===false&&follower===false)return 'まだ相互フォローではありません';
    return 'フォロー関係を確認中';
  }

  function renderEngagementBadges(item){
    var engagement=item&&item.engagement;
    var thanks=$('thanksBadge'),relation=$('relationBadge');
    thanks.classList.toggle('visible',Boolean(engagement));
    relation.classList.toggle('visible',Boolean(engagement));
    thanks.textContent=engagement?'今週 '+Number(engagement.score||0)+'回（♡'+Number(engagement.likeCount||0)+'・💬'+Number(engagement.commentCount||0)+'）':'';
    relation.textContent=relationText(engagement);
  }

  function closeMagazineSheet(){
    $('magazineSheet').classList.remove('open');
    magazineArticleUrl='';magazineRequestId='';magazineRows=[];
  }

  function setMagazineStatus(message,isError){
    var status=$('magazineStatus');
    status.textContent=String(message||'');
    status.classList.toggle('error',Boolean(isError));
  }

  function renderMagazineRows(){
    var list=$('magazineList');list.innerHTML='';
    if(!magazineRows.length){
      var empty=document.createElement('div');empty.className='magazine-empty';empty.textContent='追加できるマガジンが見つかりませんでした。note側でマガジンを作成してから、もう一度お試しください。';list.appendChild(empty);return;
    }
    magazineRows.forEach(function(magazine,index){
      var row=document.createElement('div');row.className='magazine-row';
      var copy=document.createElement('div');copy.className='magazine-copy';
      var name=document.createElement('strong');name.textContent=magazine.name||'名称未設定のマガジン';copy.appendChild(name);
      var meta=document.createElement('div');meta.className='magazine-meta';
      if(magazine.kind){var kind=document.createElement('span');kind.className='magazine-badge';kind.textContent=magazine.kind;meta.appendChild(kind)}
      if(magazine.reason){var reason=document.createElement('span');reason.className='magazine-badge';reason.textContent=magazine.reason;meta.appendChild(reason)}
      if(meta.childNodes.length)copy.appendChild(meta);
      var button=document.createElement('button');button.type='button';button.className='magazine-add';
      var unavailable=magazine.available===false;
      button.textContent=magazine.already?'追加済':(unavailable?'対象外':'追加');
      button.disabled=Boolean(magazine.already||unavailable);
      if(!button.disabled)button.addEventListener('click',function(){addToMagazine(index,button)});
      row.append(copy,button);list.appendChild(row);
    });
  }

  function requestMagazineList(item){
    magazineArticleUrl=articleUrlKey(item.url);magazineRows=[];
    $('magazineArticleTitle').textContent=item.name||'無題の記事';
    $('magazineList').innerHTML='';
    $('magazineSheet').classList.add('open');
    if(document.documentElement.dataset.neroExtension!=='ready'||!extensionAtLeast('0.1.28')){
      setMagazineStatus('この機能にはFirefox拡張機能0.1.28以降が必要です。',true);renderMagazineRows();return;
    }
    setMagazineStatus('noteのマガジン一覧を確認しています…',false);
    var id='magazines-'+Date.now()+'-'+(++extensionMagazineSequence);magazineRequestId=id;
    var timer=setTimeout(function(){cleanup();if(magazineRequestId===id)setMagazineStatus('確認がタイムアウトしました。もう一度お試しください。',true)},30000);
    function cleanup(){clearTimeout(timer);document.removeEventListener('nero-magazines-result',receive)}
    function receive(){
      var result=null;try{result=JSON.parse(document.documentElement.dataset.neroMagazinesResult||'')}catch(_){return}
      if(!result||result.id!==id)return;cleanup();
      if(magazineRequestId!==id||magazineArticleUrl!==articleUrlKey(item.url))return;
      if(!result.ok){setMagazineStatus(result.message||'マガジン一覧を確認できませんでした。',true);renderMagazineRows();return}
      magazineRows=Array.isArray(result.magazines)?result.magazines:[];
      setMagazineStatus(magazineRows.length?'保存先を選んで「追加」を押してください。':'追加できるマガジンがありません。',false);renderMagazineRows();
    }
    document.addEventListener('nero-magazines-result',receive);
    document.documentElement.dataset.neroMagazinesRequest=JSON.stringify({id:id,articleUrl:magazineArticleUrl});
    document.dispatchEvent(new Event('nero-magazines-request'));
  }

  function addToMagazine(index,button){
    var magazine=magazineRows[index];if(!magazine||magazine.already||magazine.available===false||!magazineArticleUrl)return;
    if(document.documentElement.dataset.neroExtension!=='ready'||!extensionAtLeast('0.1.28')){setMagazineStatus('Firefox拡張機能0.1.28以降が必要です。',true);return}
    var buttons=Array.from($('magazineList').querySelectorAll('.magazine-add'));buttons.forEach(function(value){value.disabled=true});
    button.textContent='追加中…';setMagazineStatus('「'+(magazine.name||'選択したマガジン')+'」へ追加しています…',false);
    var id='magazine-add-'+Date.now()+'-'+(++extensionMagazineSequence);
    var timer=setTimeout(function(){cleanup();button.textContent='追加';buttons.forEach(function(value,rowIndex){value.disabled=Boolean(magazineRows[rowIndex]&&(magazineRows[rowIndex].already||magazineRows[rowIndex].available===false))});setMagazineStatus('追加結果を確認できませんでした。二重操作を避けるため、note側をご確認ください。',true)},30000);
    function cleanup(){clearTimeout(timer);document.removeEventListener('nero-magazine-add-result',receive)}
    function receive(){
      var result=null;try{result=JSON.parse(document.documentElement.dataset.neroMagazineAddResult||'')}catch(_){return}
      if(!result||result.id!==id)return;cleanup();
      if(result.ok){magazine.already=true;setMagazineStatus('「'+(magazine.name||'マガジン')+'」へ追加しました。',false)}
      else setMagazineStatus(result.message||'マガジンへ追加できませんでした。',true);
      renderMagazineRows();
    }
    document.addEventListener('nero-magazine-add-result',receive);
    document.documentElement.dataset.neroMagazineAddRequest=JSON.stringify({id:id,articleUrl:magazineArticleUrl,magazineKey:String(magazine.key||''),magazineName:String(magazine.name||''),magazineIndex:Number.isFinite(Number(magazine.index))?Number(magazine.index):index});
    document.dispatchEvent(new Event('nero-magazine-add-request'));
  }

  function appendArticleEnd(item){
    var save=document.createElement('section');save.className='save-card';save.setAttribute('aria-label','記事を自分のマガジンに保存');
    var label=document.createElement('span');label.className='save-label';label.textContent='ARTICLE SAVE';
    var title=document.createElement('strong');title.className='save-title';title.textContent='読み返したい記事を、自分の本棚へ';
    var help=document.createElement('span');help.className='save-help';help.textContent='スキ・コメント・フォローとは別の保存操作です。';
    var button=document.createElement('button');button.className='magazine-open';button.type='button';button.textContent='📚 マガジンを選ぶ';button.addEventListener('click',function(){requestMagazineList(item)});
    save.append(label,title,help,button);$('body').appendChild(save);
    var end=document.createElement('div');end.className='end-card';end.innerHTML='<strong>この記事はここまで</strong><span>上へスワイプ、または「次へ」でランダムな未読記事へ</span>';$('body').appendChild(end);
  }

  async function showCurrent(){
    if(!queue.length){updateControls();return}
    var token=++renderToken;
    var item=queue[current];
    closeMagazineSheet();
    $('card').scrollTop=0;
    $('authorLink').textContent=item.nickname||item.urlname||'note';
    $('authorLink').href='https://note.com/'+encodeURIComponent(item.urlname||'');
    $('follow').classList.remove('visible');$('follow').disabled=false;$('follow').textContent='＋ フォロー';
    $('date').textContent=dateText(item.publishAt);
    renderEngagementBadges(item);
    $('articleTitle').textContent=item.name||'無題の記事';
    $('body').innerHTML='<div class="loading">本文を読み込み中…</div>';
    var avatar=safeUrl(item.userIcon);
    $('avatar').src=avatar||'data:image/svg+xml,%3Csvg xmlns=%22http://www.w3.org/2000/svg%22 width=%2238%22 height=%2238%22%3E%3Crect width=%2238%22 height=%2238%22 rx=%2219%22 fill=%22%23eadff1%22/%3E%3C/svg%3E';
    var eye=safeUrl(item.eyecatch);
    if(eye){$('eyecatch').src=eye;$('eyecatch').alt='';$('eyecatch').style.display='block'}else{$('eyecatch').removeAttribute('src');$('eyecatch').style.display='none'}
    $('like').href=item.url;
    $('comment').href=item.url+'#comments';
    document.dispatchEvent(new Event('nero-article-shown'));
    updateControls();
    try{
      var article=articleCache.get(item.key);
      if(!article){
        var response=await fetch('/api/article?key='+encodeURIComponent(item.key));
        article=await response.json();
        if(!response.ok)throw new Error(article.error||'本文を取得できませんでした');
        articleCache.set(item.key,article);
      }
      if(token!==renderToken)return;
      var rich=sanitizeNoteHtml(article.body||article.description||item.description);
      $('body').innerHTML=rich||'<p>'+escapeText(item.description||'本文はnoteでお読みください。')+'</p>';
      if(!eye&&article.eyecatch){
        var articleEye=safeUrl(article.eyecatch);
        if(articleEye){$('eyecatch').src=articleEye;$('eyecatch').style.display='block'}
      }
      appendArticleEnd(item);
      if(recycled)setNotice('すべての記事を新しい順番で表示しています');
    }catch(error){
      if(token!==renderToken)return;
      $('body').innerHTML='<p>'+escapeText(item.description||'本文を取得できませんでした。')+'</p>';
      appendArticleEnd(item);
    }
  }

  async function openLinkedArticle(noteKey,href){
    if(!noteKey)return;
    $('articleTitle').textContent='関連記事を読み込み中';
    $('body').innerHTML='<div class="loading">Reader内で記事を開いています…</div>';
    try{
      var article=articleCache.get(noteKey);
      if(!article){
        var response=await fetch('/api/article?key='+encodeURIComponent(noteKey));
        article=await response.json();
        if(!response.ok)throw new Error(article.error||'関連記事を取得できませんでした');
        articleCache.set(noteKey,article);
      }
      var item={
        key:noteKey,
        name:article.name||'無題の記事',
        description:article.description||'',
        eyecatch:article.eyecatch||'',
        publishAt:article.publishAt||'',
        url:article.url||safeUrl(href)||'',
        urlname:article.urlname||'',
        nickname:article.nickname||article.urlname||'note',
        userIcon:article.userIcon||''
      };
      if(!item.url)throw new Error('関連記事のURLを確認できませんでした');
      var existing=queue.findIndex(function(row){return idFor(row)===idFor(item)});
      if(existing>=0)current=existing;
      else{queue.splice(current+1,0,item);current++}
      showCurrent();
      setNotice('関連記事をReader内で開きました');
    }catch(error){
      $('articleTitle').textContent='関連記事を開けませんでした';
      $('body').innerHTML='<div class="loading">'+escapeText(error.message||error)+'</div>';
    }
  }

  async function loadOlder(){
    if(loadingOlder||olderExhausted)return 0;
    loadingOlder=true;
    setNotice(source.mode==='following'?'別のフォロー中ユーザーを抽選しています…':(source.mode==='thanks'?'別のありがとうを確認しています…':'過去の記事を探しています…'));
    try{
      var queuedIds=new Set(queue.map(idFor));
      var remaining=allRows.filter(function(item){return !queuedIds.has(idFor(item))&&(viewMode!=='unfinished'||!completedMap[idFor(item)])});
      var remainingPlayable=await selectPlayableRows(remaining,20);
      if(remainingPlayable.length){queue=queue.concat(remainingPlayable);return remainingPlayable.length}
      if(source.mode==='thanks'){
        while(thanksBatchCursor<thanksPool.length){
          var thanksPayload=await fetchFeedPage(1);
          var thanksFresh=appendUniqueRows(thanksPayload.items||[]);
          if(viewMode==='unfinished')thanksFresh=thanksFresh.filter(function(item){return !completedMap[idFor(item)]});
          var thanksPlayable=await selectPlayableRows(thanksFresh,20);
          if(thanksPlayable.length){
            queue=queue.concat(thanksPlayable);
            setNotice('別のありがとうを'+thanksPlayable.length+'人追加しました');
            return thanksPlayable.length;
          }
        }
        olderExhausted=true;
        return 0;
      }
      if(source.mode==='following'){
        while(followingRounds<MAX_FEED_PAGES){
          followingRounds++;followingPool=[];
          var followingPayload=await fetchFeedPage(1);
          var fresh=appendUniqueRows(followingPayload.items||[]);
          if(viewMode==='unfinished')fresh=fresh.filter(function(item){return !completedMap[idFor(item)]});
          var freshPlayable=await selectPlayableRows(fresh,20);
          if(freshPlayable.length){
            queue=queue.concat(freshPlayable);
            setNotice('別のフォロー中ユーザーを'+freshPlayable.length+'人追加しました');
            return freshPlayable.length;
          }
        }
        olderExhausted=true;
        return 0;
      }
      while(feedPage<MAX_FEED_PAGES){
        feedPage++;
        var payload=await fetchFeedPage(feedPage);
        var added=appendUniqueRows(payload.items||[]);
        var candidates=viewMode==='unfinished'?added.filter(function(item){return !completedMap[idFor(item)]}):added;
        if(candidates.length){
          var playable=await selectPlayableRows(candidates,20);
          if(playable.length){
            queue=queue.concat(playable);
            setNotice('過去の記事を'+playable.length+'件追加しました');
            return playable.length;
          }
        }
        if(!added.length&&source.mode!=='following'){olderExhausted=true;break}
      }
      olderExhausted=true;
      return 0;
    }catch(_){
      setNotice('過去の記事を今回は取得できませんでした');
      return 0;
    }finally{loadingOlder=false}
  }
  async function move(delta){
    if(!queue.length)return;
    var next=current+delta;
    if(next<0)return;
    if(next>=queue.length){
      var added=await loadOlder();
      if(added){current=next;recycled=false;showCurrent();return}
      if(viewMode==='unfinished'){
        setNotice('未完了の記事はここまでです');
        return;
      }
      if(source.mode==='thanks'){
        setNotice('新しい重み付き順番を作ります');
        await loadFeeds();
        return;
      }
      queue=shuffle(allRows);current=0;recycled=true;setNotice('新しい順番で再生します');
    }else current=next;
    showCurrent();
  }
  function renderSearchState(){
    var followingLabel=source.followingMode==='first'?'固定記事優先':(source.followingMode==='profile'?'プロフィール優先':'最新記事優先');
    var thanksLabel=source.thanksMode==='profile'?'プロフィール優先':'最新記事優先';
    var label=source.mode==='search'?'検索: '+source.query:(source.mode==='following'?'フォロー中・'+followingLabel:(source.mode==='thanks'?'ありがとう・'+thanksLabel:activeWatchlist().name));
    $('activeSource').hidden=false;
    $('sourceBadge').textContent='現在: '+label;
    $('backToWatch').disabled=source.mode==='watch';
    $('useWatchFeed').classList.toggle('active',source.mode==='watch');
    $('useFollowingLatest').classList.toggle('active',source.mode==='following'&&source.followingMode==='latest');
    $('useFollowingFirst').classList.toggle('active',source.mode==='following'&&source.followingMode==='first');
    $('useFollowingProfile').classList.toggle('active',source.mode==='following'&&source.followingMode==='profile');
    $('useThanksLatest').classList.toggle('active',source.mode==='thanks'&&source.thanksMode==='latest');
    $('useThanksProfile').classList.toggle('active',source.mode==='thanks'&&source.thanksMode==='profile');
    if(source.mode==='search')$('searchInput').value=source.query;
    updateControls();
  }

  function useSource(nextSource,message){
    source=nextSource;
    if(!source.listId)source.listId=activeWatchlist().id;
    localStorage.setItem(SOURCE_STORAGE,JSON.stringify(source));
    creators=activeWatchlist().creators;
    followingStats=null;thanksStats=null;thanksPool=[];thanksBatchCursor=0;renderChips();renderSearchState();$('searchSheet').classList.remove('open');loadFeeds();
    if(message)setNotice(message);
  }

  document.addEventListener('nero-liked-status',function(){
    var state=document.documentElement.dataset.neroCurrentLiked||'unknown';
    var item=queue[current];if(!item||!item.url)return;
    likedStateCache.set(item.url,state==='true'?'liked':(state==='false'?'unliked':'unknown'));
    if(state==='true')markArticleCompleted(item.url);
  });

  document.addEventListener('nero-article-completed',function(){
    var payload=null;
    try{payload=JSON.parse(document.documentElement.dataset.neroArticleCompleted||'')}catch(_){return}
    if(!payload||!payload.url)return;
    if(markArticleCompleted(payload.url)&&payload.reason==='like')likedStateCache.set(payload.url,'liked');
    if(payload.reason==='like')autoAddNeroFavorite(payload.url);
  });

  document.addEventListener('nero-creator-status',function(){
    var status=null;try{status=JSON.parse(document.documentElement.dataset.neroCreatorStatus||'')}catch(_){return}
    var item=queue[current];
    if(!item||!item.engagement||!status||status.urlname!==item.urlname)return;
    if(typeof status.isFollowing==='boolean')item.engagement.isFollowing=status.isFollowing;
    if(typeof status.isFollower==='boolean')item.engagement.isFollower=status.isFollower;
    renderEngagementBadges(item);
  });

  $('prev').addEventListener('click',function(){move(-1)});
  $('next').addEventListener('click',function(){move(1)});
  $('mode').addEventListener('click',function(){
    viewMode=viewMode==='unfinished'?'all':'unfinished';localStorage.setItem(MODE_STORAGE,viewMode);likedSkipStreak=0;
    updateControls();setNotice(viewMode==='unfinished'?'スキも新規コメントもない記事だけ表示します':'読了済みも含めて表示します');loadFeeds();
  });
  $('discover').addEventListener('click',function(){renderSearchState();$('searchSheet').classList.add('open');if(source.mode==='search')$('searchInput').focus()});
  $('closeSearch').addEventListener('click',function(){$('searchSheet').classList.remove('open')});
  $('searchSheet').addEventListener('click',function(event){if(event.target===$('searchSheet'))$('searchSheet').classList.remove('open')});
  $('searchForm').addEventListener('submit',async function(event){
    event.preventDefault();$('searchError').textContent='';
    var query=String($('searchInput').value||'').trim().slice(0,80);
    if(!query){$('searchError').textContent='キーワード、または #ハッシュタグを入力してください。';return}
    source={mode:'search',query:query,listId:activeWatchlist().id};localStorage.setItem(SOURCE_STORAGE,JSON.stringify(source));renderSearchState();
    $('startSearch').disabled=true;$('startSearch').textContent='検索中';
    try{await loadFeeds();$('searchSheet').classList.remove('open');setNotice('検索結果をランダム再生します')}
    catch(error){$('searchError').textContent=error.message||String(error)}
    finally{$('startSearch').disabled=false;$('startSearch').textContent='探す'}
  });
  $('backToWatch').addEventListener('click',function(){
    useSource({mode:'watch',query:'',listId:activeWatchlist().id},activeWatchlist().name+'に切り替えました');
  });
  $('useWatchFeed').addEventListener('click',function(){useSource({mode:'watch',query:'',listId:activeWatchlist().id},activeWatchlist().name+'から再生します')});
  $('useFollowingLatest').addEventListener('click',function(){useSource({mode:'following',followingMode:'latest',query:'',listId:activeWatchlist().id},'フォロー中から最新記事を抽選します')});
  $('useFollowingFirst').addEventListener('click',function(){useSource({mode:'following',followingMode:'first',query:'',listId:activeWatchlist().id},'フォロー中から固定記事を抽選します')});
  $('useFollowingProfile').addEventListener('click',function(){useSource({mode:'following',followingMode:'profile',query:'',listId:activeWatchlist().id},'プロフィール記事を設定している人から抽選します')});
  $('useThanksLatest').addEventListener('click',function(){useSource({mode:'thanks',thanksMode:'latest',query:'',listId:activeWatchlist().id},'過去7日間の交流から最新記事を表示します')});
  $('useThanksProfile').addEventListener('click',function(){useSource({mode:'thanks',thanksMode:'profile',query:'',listId:activeWatchlist().id},'交流のある人のプロフィール記事を表示します')});
  $('searchAgain').addEventListener('click',function(){$('searchInput').value='';$('searchInput').focus()});
  $('inbox').addEventListener('click',function(){
    if(document.documentElement.dataset.neroExtension!=='ready')setNotice('Firefox拡張機能0.1.30で利用できます');
  });
  $('neroExtensionStatus').addEventListener('click',function(){
    var ready=document.documentElement.dataset.neroExtension==='ready';
    var version=String(document.documentElement.dataset.neroExtensionVersion||'').trim();
    setNotice(ready?'Firefox拡張機能'+(version?' v'+version:'')+'で連携中です':'アドオンを有効にしてReaderを再読み込みしてください');
  });
  $('body').addEventListener('click',function(event){
    var link=event.target instanceof Element?event.target.closest('a[data-note-key]'):null;
    if(!link)return;
    event.preventDefault();
    openLinkedArticle(String(link.dataset.noteKey||''),link.href||'');
  });
  document.addEventListener('nero-open-article',function(){
    var noteKey=String(document.documentElement.dataset.neroOpenArticleKey||'').trim();
    var href=String(document.documentElement.dataset.neroOpenArticleUrl||'').trim();
    if(noteKey)openLinkedArticle(noteKey,href);
  });
  $('card').addEventListener('touchstart',function(event){
    var touch=event.changedTouches[0];touchStart={x:touch.clientX,y:touch.clientY,top:$('card').scrollTop};
  },{passive:true});
  $('card').addEventListener('touchend',function(event){
    if(!touchStart)return;
    var touch=event.changedTouches[0],dx=touch.clientX-touchStart.x,dy=touch.clientY-touchStart.y;
    var card=$('card'),atBottom=card.scrollTop+card.clientHeight>=card.scrollHeight-28;
    if(document.documentElement.dataset.neroComposer==='open'){touchStart=null;return}
    if(Math.abs(dy)>Math.abs(dx)&&Math.abs(dy)>80){
      if(dy<0&&atBottom)move(1);
      else if(dy>0&&card.scrollTop<12)move(-1);
    }
    touchStart=null;
  },{passive:true});

  $('manage').addEventListener('click',function(){$('sheet').classList.add('open');$('creatorInput').focus()});
  $('close').addEventListener('click',function(){$('sheet').classList.remove('open')});
  $('sheet').addEventListener('click',function(event){if(event.target===$('sheet'))$('sheet').classList.remove('open')});
  $('closeMagazine').addEventListener('click',closeMagazineSheet);
  $('magazineSheet').addEventListener('click',function(event){if(event.target===$('magazineSheet'))closeMagazineSheet()});
  $('neroFavorites').addEventListener('click',function(){if(!IS_NERO_MODE){location.href='/nero-favorites';return}$('neroSheet').classList.add('open')});
  $('closeNero').addEventListener('click',function(){if(!neroAdding)$('neroSheet').classList.remove('open')});
  $('neroSheet').addEventListener('click',function(event){if(event.target===$('neroSheet')&&!neroAdding)$('neroSheet').classList.remove('open')});
  $('verifyNero').addEventListener('click',async function(){
    $('verifyNero').disabled=true;setNeroAccountStatus('ログイン中のアカウントを確認しています…',false);
    try{await verifyNeroAccount();neroAutoStopped=false;processNeroAutoQueue()}catch(error){setNeroAccountStatus(error.message||String(error),true)}finally{$('verifyNero').disabled=false}
  });
  $('scanNero').addEventListener('click',function(){scanNeroCandidates().catch(function(error){$('scanNero').disabled=false;setNeroStatus(error.message||String(error),true)})});
  $('selectNero').addEventListener('click',function(){neroCandidates.forEach(function(item){item.selected=item.liked||(item.score>=4&&!item.blocked)});renderNeroCandidates()});
  $('runNero').addEventListener('click',function(){runNeroQueue().catch(function(error){neroAdding=false;neroStopRequested=false;$('runNero').classList.remove('stop');setNeroStatus(error.message||String(error),true);renderNeroCandidates()})});
  ['neroAccount','neroTags','neroPages','neroDailyCap','neroAutoLike'].forEach(function(id){$(id).addEventListener('change',saveNeroSettings)});

  $('watchlistSelect').addEventListener('change',function(){
    var id=$('watchlistSelect').value;if(!watchlists.some(function(list){return list.id===id}))return;
    source={mode:'watch',query:'',listId:id};creators=activeWatchlist().creators;localStorage.setItem(SOURCE_STORAGE,JSON.stringify(source));renderChips();renderSearchState();loadFeeds();
  });
  $('newWatchlist').addEventListener('click',function(){
    if(watchlists.length>=MAX_WATCHLISTS){$('managerError').textContent='作成できるリストは10個までです。';return}
    var name=String(prompt('新しいウォッチリスト名','読みたい人リスト '+(watchlists.length+1))||'').trim().slice(0,30);if(!name)return;
    var id='list-'+Date.now().toString(36);watchlists.push({id:id,name:name,creators:[]});source={mode:'watch',query:'',listId:id};creators=[];saveWatchlists();localStorage.setItem(SOURCE_STORAGE,JSON.stringify(source));renderChips();renderSearchState();loadFeeds();
  });
  $('renameWatchlist').addEventListener('click',function(){
    var list=activeWatchlist();var name=String(prompt('ウォッチリスト名を変更',list.name)||'').trim().slice(0,30);if(!name)return;
    list.name=name;saveWatchlists();renderChips();renderSearchState();
  });
  $('deleteWatchlist').addEventListener('click',function(){
    if(watchlists.length<=1){$('managerError').textContent='最後の1リストは削除できません。';return}
    var list=activeWatchlist();if(!confirm('「'+list.name+'」を削除しますか？'))return;
    watchlists=watchlists.filter(function(row){return row.id!==list.id});source={mode:'watch',query:'',listId:watchlists[0].id};creators=watchlists[0].creators;saveWatchlists();localStorage.setItem(SOURCE_STORAGE,JSON.stringify(source));renderChips();renderSearchState();loadFeeds();
  });

  $('addForm').addEventListener('submit',async function(event){
    event.preventDefault();$('managerError').textContent='';
    var input=normalizeCreator($('creatorInput').value);
    if(!input){$('managerError').textContent='noteのプロフィールURL、または @ユーザー名を入力してください。';return}
    if(creators.some(function(c){return c.urlname===input})){$('managerError').textContent='すでに登録されています。';return}
    if(creators.length>=MAX_CREATORS){$('managerError').textContent='登録できるのは50人までです。';return}
    $('addCreator').disabled=true;$('addCreator').textContent='確認中';
    try{
      var response=await fetch('/api/creator-feed?limit=1&urlname='+encodeURIComponent(input));
      var payload=await response.json();
      if(!response.ok)throw new Error('クリエイターを確認できませんでした');
      creators.push({urlname:input,nickname:(payload.creator&&payload.creator.nickname)||input});
      activeWatchlist().creators=creators;
      saveCreators();$('creatorInput').value='';renderChips();await loadFeeds();setNotice('@'+input+' を追加しました');
    }catch(error){$('managerError').textContent=error.message||String(error)}
    finally{$('addCreator').disabled=false;$('addCreator').textContent='追加'}
  });

  $('bulkAdd').addEventListener('click',function(){
    $('managerError').textContent='';
    var values=String($('bulkInput').value||'').split(/[\s,]+/).map(normalizeCreator).filter(Boolean);
    var existing=new Set(creators.map(function(c){return c.urlname}));
    var added=0;
    values.forEach(function(name){
      if(creators.length<MAX_CREATORS&&!existing.has(name)){creators.push({urlname:name,nickname:name});existing.add(name);added++}
    });
    if(!added){$('managerError').textContent='追加できる新しいユーザー名がありません。';return}
    activeWatchlist().creators=creators;saveCreators();$('bulkInput').value='';renderChips();loadFeeds();setNotice(added+'人をまとめて追加しました');
  });

  new MutationObserver(updateBridgeStatus).observe(document.documentElement,{attributes:true,attributeFilter:['data-nero-extension','data-nero-extension-version']});
  $('neroFavorites').hidden=false;
  $('neroFavorites').textContent=IS_NERO_MODE?'🌙 お気に入り':'🌙 ネロ用';
  if(IS_NERO_MODE){
    document.querySelector('.brand strong').textContent='NERO Favorite Reader';
    document.querySelector('.brand span').textContent='好きな記事から、素敵な人の輪を広げる';
    document.title='ネロのお気に入り収集室';
    $('neroAccount').value=neroSettings.account||'';
    $('neroTags').value=(Array.isArray(neroSettings.tags)?neroSettings.tags:[]).join('\n');
    $('neroPages').value=String(neroSettings.pages||2);
    $('neroDailyCap').value=String(neroSettings.dailyCap||40);
    $('neroAutoLike').checked=neroSettings.autoLike!==false;
    cleanNeroHistory();
  }
  updateBridgeStatus();saveWatchlists();renderChips();renderSearchState();loadFeeds();
})();
</script>
</body>
</html>`;

const GUIDE_PAGE = String.raw`<!doctype html>
<html lang="ja">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<meta name="theme-color" content="#fff8fb">
<meta name="robots" content="noindex,nofollow,noarchive">
<title>NERO Favorite Reader はじめ方</title>
<style>
:root{--ink:#2b2430;--muted:#756b75;--paper:#fff;--bg:#fbf7fb;--pink:#e84680;--pink-soft:#fff0f6;--purple:#7054bd;--purple-soft:#f2edff;--line:#eadfe8;--green:#267a53;--green-soft:#e9f8f0;--amber:#955817;--amber-soft:#fff4e5;--red:#b32953;font-family:Inter,"Noto Sans JP",system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;color:var(--ink);background:var(--bg);color-scheme:light}
*{box-sizing:border-box}html{scroll-behavior:smooth}body{margin:0;background:radial-gradient(circle at 12% 0,#fff 0,#fff7fb 35%,#f6f1ff 100%);line-height:1.75}button,a{-webkit-tap-highlight-color:transparent}.wrap{width:min(860px,100%);margin:0 auto;padding:0 18px}.hero{padding:56px 0 26px}.eyebrow{display:inline-flex;align-items:center;gap:7px;padding:7px 11px;border:1px solid #efc3d3;border-radius:999px;background:rgba(255,255,255,.8);color:#a72d5b;font-size:12px;font-weight:900}.hero h1{max-width:720px;margin:17px 0 12px;font-size:clamp(34px,8vw,58px);line-height:1.13;letter-spacing:-.035em}.hero p{max-width:660px;margin:0;color:var(--muted);font-size:16px}.version{margin-top:18px;color:var(--muted);font-size:12px}.device-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:11px;margin:22px 0 14px}.device{padding:17px;border:1px solid var(--line);border-radius:20px;background:rgba(255,255,255,.88);box-shadow:0 8px 28px rgba(72,45,70,.06)}.device .icon{font-size:27px}.device strong{display:block;margin-top:7px}.device span{display:block;margin-top:2px;color:var(--muted);font-size:12px;line-height:1.5}.device.ok{border-color:#bde6cf;background:var(--green-soft)}.device.beta{border-color:#f0d2a7;background:var(--amber-soft)}.device.no{border-color:#efc4d1;background:#fff0f4}.device .state{display:inline-flex;margin-top:9px;padding:4px 8px;border-radius:999px;background:#fff;color:var(--ink);font-size:11px;font-weight:900}.toc{position:sticky;top:0;z-index:5;border-block:1px solid rgba(234,223,232,.85);background:rgba(255,255,255,.9);backdrop-filter:blur(14px)}.toc .wrap{display:flex;gap:8px;padding-block:10px;overflow:auto;scrollbar-width:none}.toc .wrap::-webkit-scrollbar{display:none}.toc a{flex:0 0 auto;padding:8px 11px;border-radius:999px;background:#f5f0f4;color:var(--ink);font-size:12px;font-weight:850;text-decoration:none}.section{padding:42px 0 8px;scroll-margin-top:76px}.section-head{display:flex;gap:13px;align-items:flex-start;margin-bottom:20px}.num{flex:0 0 auto;display:grid;place-items:center;width:38px;height:38px;border-radius:13px;background:linear-gradient(135deg,var(--pink),var(--purple));color:#fff;font-weight:950}.section h2{margin:0;font-size:clamp(25px,5vw,34px);line-height:1.25}.section-head p{margin:5px 0 0;color:var(--muted);font-size:14px}.notice{margin:16px 0;padding:16px 17px;border-radius:18px;background:var(--purple-soft);border:1px solid #d9cff4}.notice strong{display:block;margin-bottom:3px}.notice p{margin:0;color:#5f5273;font-size:13px}.notice.warn{background:var(--amber-soft);border-color:#efd2a9}.notice.danger{background:#fff0f4;border-color:#efc4d1}.checklist{display:grid;gap:9px;padding:0;list-style:none}.checklist li{position:relative;padding:13px 15px 13px 46px;border:1px solid var(--line);border-radius:16px;background:#fff}.checklist li::before{content:'✓';position:absolute;left:15px;top:13px;display:grid;place-items:center;width:23px;height:23px;border-radius:50%;background:var(--green-soft);color:var(--green);font-weight:950}.choice{display:grid;grid-template-columns:1fr 1fr;gap:11px}.choice a{display:block;padding:18px;border-radius:19px;border:1px solid var(--line);background:#fff;color:var(--ink);text-decoration:none;box-shadow:0 7px 25px rgba(72,45,70,.05)}.choice strong{display:block}.choice span{display:block;margin-top:4px;color:var(--muted);font-size:12px}.steps{display:grid;gap:17px;counter-reset:step}.step{counter-increment:step;display:grid;grid-template-columns:minmax(0,1fr) minmax(220px,310px);gap:18px;padding:20px;border:1px solid var(--line);border-radius:24px;background:#fff;box-shadow:0 9px 32px rgba(72,45,70,.05)}.step-copy h3{margin:0 0 8px;font-size:19px;line-height:1.45}.step-copy h3::before{content:counter(step);display:inline-grid;place-items:center;width:28px;height:28px;margin-right:9px;border-radius:10px;background:var(--pink-soft);color:var(--red);font-size:13px;font-weight:950}.step-copy p{margin:0;color:var(--muted);font-size:14px}.screen{position:relative;min-height:174px;padding:14px;border:1px solid #d9ced7;border-radius:21px;background:#faf8fa;box-shadow:inset 0 0 0 5px #fff;overflow:hidden}.screen-bar{display:flex;align-items:center;gap:7px;margin:-2px 0 12px;color:#8d818b;font-size:10px}.dot{width:7px;height:7px;border-radius:50%;background:#d8cad5}.screen-title{font-size:13px;font-weight:900}.menu-row{display:flex;align-items:center;gap:10px;margin-top:8px;padding:10px 11px;border-radius:12px;background:#fff;border:1px solid #eee4ec;font-size:11px}.menu-row b{flex:1}.callout{display:inline-grid;place-items:center;width:22px;height:22px;border-radius:50%;background:var(--pink);color:#fff;font-size:11px;font-weight:950;font-style:normal;box-shadow:0 4px 10px rgba(232,70,128,.3)}.urlbar{padding:9px 11px;border-radius:999px;background:#ece7eb;color:#6e646d;font:10px ui-monospace,SFMono-Regular,Menlo,monospace;white-space:nowrap;overflow:hidden}.file{display:flex;align-items:center;gap:9px;margin-top:10px;padding:11px;border-radius:13px;background:#fff;border:1px solid #e8dde6;font-size:11px}.file .paper{font-size:23px}.dialog{margin-top:9px;padding:12px;border-radius:14px;background:#fff;border:1px solid #dfd4dd;font-size:11px}.dialog strong{display:block;margin-bottom:8px}.dialog .buttons{display:flex;justify-content:flex-end;gap:6px}.mini-btn{padding:6px 9px;border-radius:9px;background:#ece7eb}.mini-btn.primary{background:#6c4fc0;color:#fff;font-weight:900}.reader-shot{min-height:190px;background:linear-gradient(150deg,#fff,#faf1f8)}.reader-top{display:flex;gap:5px;align-items:center;padding-bottom:8px;border-bottom:1px solid #eee4ec}.reader-brand{flex:1;font-size:10px;font-weight:950}.pill{padding:4px 6px;border-radius:999px;background:#f2ebf0;font-size:8px}.pill.connected{background:#e7f8ef;color:#267a53}.article-shot{padding:13px 7px}.article-shot small{color:#8d818b}.article-shot h4{margin:5px 0;font-size:14px;line-height:1.4}.article-shot p{margin:0;color:#756b75;font-size:9px;line-height:1.6}.reader-actions{display:grid;grid-template-columns:1fr 1.5fr 1.5fr 1fr;gap:4px;margin-top:10px}.reader-actions span{padding:7px 2px;border-radius:8px;background:#f0ebef;text-align:center;font-size:7px}.reader-actions .like{background:#ffe5ef;color:#b9225b}.reader-actions .comment{background:#eee8ff;color:#59389d}.feature-grid{display:grid;grid-template-columns:repeat(2,1fr);gap:11px}.feature{padding:18px;border:1px solid var(--line);border-radius:19px;background:#fff}.feature strong{display:block;margin-bottom:4px}.feature p{margin:0;color:var(--muted);font-size:13px}.mode-list{display:grid;gap:9px;margin-top:12px}.mode{padding:14px 15px;border-radius:16px;background:#fff;border:1px solid var(--line)}.mode b{display:block}.mode span{color:var(--muted);font-size:12px}.faq{display:grid;gap:10px}.faq details{border:1px solid var(--line);border-radius:17px;background:#fff;padding:0 16px}.faq summary{padding:15px 0;font-weight:850;cursor:pointer}.faq p{margin:0 0 16px;color:var(--muted);font-size:13px}.cta{margin:46px 0 24px;padding:26px;border-radius:28px;background:linear-gradient(135deg,#ffe8f1,#eee7ff);text-align:center}.cta h2{margin:0 0 7px}.cta p{margin:0 auto 17px;max-width:530px;color:#6e6171;font-size:13px}.button{display:inline-flex;align-items:center;justify-content:center;min-height:50px;padding:0 20px;border-radius:15px;background:var(--ink);color:#fff;font-weight:900;text-decoration:none}.subnote{margin-top:12px;color:#80737e;font-size:11px}.footer{padding:18px 0 45px;text-align:center;color:#8e818b;font-size:11px}
@media(max-width:680px){.wrap{padding-inline:14px}.hero{padding-top:38px}.device-grid{grid-template-columns:1fr}.device{display:grid;grid-template-columns:auto 1fr auto;column-gap:12px;align-items:center;padding:14px}.device .icon{grid-row:1/3}.device strong{margin:0}.device span{margin:0}.device .state{grid-column:3;grid-row:1/3;margin:0}.choice,.feature-grid{grid-template-columns:1fr}.step{grid-template-columns:1fr;padding:17px}.screen{min-height:168px}.section{padding-top:34px}}
@media(prefers-reduced-motion:reduce){html{scroll-behavior:auto}}
</style>
</head>
<body>
<header class="hero"><div class="wrap">
  <span class="eyebrow">🌸 メンバー向けスタートガイド</span>
  <h1>NERO Swipe Reader<br>はじめ方</h1>
  <p>noteの記事を、読む・スキ・コメント返信までひとつの画面で。はじめての方も、下の順番どおりに進めれば利用できます。</p>
  <div class="version">対応ガイド：Bridge v0.1.30</div>
  <div class="device-grid" aria-label="対応端末">
    <div class="device ok"><span class="icon">📱</span><div><strong>Android</strong><span>Firefox 142以降</span></div><span class="state">利用できます</span></div>
    <div class="device beta"><span class="icon">💻</span><div><strong>Windows / Mac</strong><span>Firefox 140以降</span></div><span class="state">確認中</span></div>
    <div class="device no"><span class="icon">🍎</span><div><strong>iPhone / iPad</strong><span>ブラウザを問わず</span></div><span class="state">利用できません</span></div>
  </div>
  <div class="notice danger"><strong>iPhone版Firefoxでは使えません</strong><p>iPhone・iPad版Firefoxは、このReaderに必要なFirefox拡張機能へ対応していません。Firefoxを追加インストールしても利用できません。</p></div>
</div></header>
<nav class="toc" aria-label="ページ内メニュー"><div class="wrap"><a href="#before">準備</a><a href="#android">Android</a><a href="#pc">パソコン</a><a href="#use">使い方</a><a href="#modes">記事の選び方</a><a href="#trouble">困ったとき</a></div></nav>
<main class="wrap">
<section class="section" id="before"><div class="section-head"><span class="num">1</span><div><h2>はじめる前の準備</h2><p>3つそろっていれば、数分で始められます。</p></div></div>
  <ul class="checklist"><li>このメンバー限定記事から、署名済みの <strong>.xpiファイル</strong>をダウンロード</li><li>利用する端末に<strong>Firefox</strong>をインストール</li><li>同じFirefoxで<strong>noteにログイン</strong></li></ul>
  <div class="notice"><strong>ファイルはメンバー限定記事から取得してください</strong><p>ガイドページ上では拡張機能を配布していません。ZIPファイルは開発用で、インストールには「署名済み .xpi」が必要です。</p></div>
  <div class="choice"><a href="#android"><strong>📱 Androidで使う</strong><span>スマートフォン向けの正式手順</span></a><a href="#pc"><strong>💻 パソコンで試す</strong><span>Windows / Mac向け・現在は確認中</span></a></div>
</section>

<section class="section" id="android"><div class="section-head"><span class="num">2</span><div><h2>Androidにインストール</h2><p>Firefoxの隠し設定を一度だけ有効にします。</p></div></div>
  <div class="steps">
    <article class="step"><div class="step-copy"><h3>XPIを保存する</h3><p>メンバー限定記事のダウンロードリンクをFirefoxで開きます。ファイル名の末尾が <strong>.xpi</strong> になっていることを確認してください。</p></div><div class="screen"><div class="screen-bar"><span class="dot"></span><span class="dot"></span><span class="dot"></span><b>ダウンロード</b></div><div class="file"><span class="paper">🧩</span><b>nero-swipe-reader.xpi</b><span class="callout">1</span></div></div></article>
    <article class="step"><div class="step-copy"><h3>デバッグメニューを出す</h3><p>Firefoxの「︙」→「設定」→「Firefoxについて」を開き、Firefoxロゴを<strong>5回連続</strong>でタップします。</p></div><div class="screen"><div class="screen-title">Firefoxについて</div><div style="display:grid;place-items:center;height:90px"><span style="font-size:48px">🦊</span><span class="callout" style="position:absolute;right:28px;top:70px">2</span></div><div class="menu-row"><b>ロゴを5回タップ</b><span>5×</span></div></div></article>
    <article class="step"><div class="step-copy"><h3>ファイルから追加する</h3><p>設定へ戻り「ファイルから拡張機能をインストール」を選びます。先ほど保存したXPIをタップします。</p></div><div class="screen"><div class="screen-title">設定</div><div class="menu-row"><span>🧩</span><b>ファイルから拡張機能をインストール</b><span class="callout">3</span></div><div class="file"><span class="paper">📄</span><b>nero-swipe-reader.xpi</b></div></div></article>
    <article class="step"><div class="step-copy"><h3>「追加」を押す</h3><p>表示された権限を確認して「追加」をタップします。完了メッセージが出たらインストール成功です。</p></div><div class="screen"><div class="dialog"><strong>NERO Favorite Reader Bridgeを追加しますか？</strong><span>note.comとReaderでデータを読み取る権限</span><div class="buttons"><span class="mini-btn">キャンセル</span><span class="mini-btn primary">追加 <i class="callout">4</i></span></div></div></div></article>
    <article class="step"><div class="step-copy"><h3>Readerを開いて確認</h3><p>下のボタンからReaderを開き、上部の表示が緑色の<strong>「連携中」</strong>になれば準備完了です。</p><p style="margin-top:12px"><a class="button" href="/" target="_blank" rel="noopener">Readerを開く</a></p></div><div class="screen reader-shot"><div class="reader-top"><b class="reader-brand">NERO Swipe Reader</b><span class="pill">フィード</span><span class="pill">未対応</span><span class="pill connected">● 連携中</span></div><div class="article-shot"><small>nero｜2026.08.15</small><h4>読みたい記事がここに表示されます</h4><p>本文は縦にスクロールして読めます。次の記事へ進むときは下のボタンを使います。</p></div><div class="reader-actions"><span>前へ</span><span class="like">♡ noteでスキ</span><span class="comment">💬 コメント</span><span>次へ</span></div></div></article>
  </div>
</section>

<section class="section" id="pc"><div class="section-head"><span class="num">3</span><div><h2>パソコンにインストール</h2><p>Windows / Mac版Firefox向けです。</p></div></div>
  <div class="notice warn"><strong>パソコン版は現在ベータ扱いです</strong><p>拡張機能の仕組み上はFirefox 140以降に対応していますが、実機での一連の動作確認はまだ行っていません。不具合があればAndroid版をご利用ください。</p></div>
  <div class="steps">
    <article class="step"><div class="step-copy"><h3>アドオン管理を開く</h3><p>Firefoxのアドレス欄へ <strong>about:addons</strong> と入力してEnterを押し、左側の「拡張機能」を選びます。</p></div><div class="screen"><div class="urlbar">about:addons</div><div class="menu-row"><span>🧩</span><b>拡張機能</b><span class="callout">1</span></div></div></article>
    <article class="step"><div class="step-copy"><h3>XPIを選ぶ</h3><p>歯車ボタンから「ファイルからアドオンをインストール」を選び、メンバー限定記事から保存したXPIを開きます。</p></div><div class="screen"><div class="screen-title">拡張機能を管理</div><div class="menu-row"><span>⚙️</span><b>ファイルからアドオンをインストール…</b><span class="callout">2</span></div><div class="file"><span class="paper">📄</span><b>nero-swipe-reader.xpi</b></div></div></article>
    <article class="step"><div class="step-copy"><h3>追加してReaderを開く</h3><p>権限を確認して「追加」を押します。同じFirefoxでnoteへログインしてからReaderを開き、「連携中」を確認します。</p><p style="margin-top:12px"><a class="button" href="/" target="_blank" rel="noopener">Readerを開く</a></p></div><div class="screen"><div class="dialog"><strong>NERO Favorite Reader Bridgeを追加しますか？</strong><div class="buttons"><span class="mini-btn">キャンセル</span><span class="mini-btn primary">追加 <i class="callout">3</i></span></div></div><div class="menu-row"><b>Reader上部：● 連携中</b><span style="color:var(--green)">OK</span></div></div></article>
  </div>
</section>

<section class="section" id="use"><div class="section-head"><span class="num">4</span><div><h2>インストール後の使い方</h2><p>読む・交流する・保存するを、ひとつの流れで進められます。</p></div></div>
  <div class="feature-grid"><div class="feature"><strong>① フィードを選ぶ</strong><p>上部の「フィード」から、フォロー中・ありがとう・特に読みたい人・検索を選びます。</p></div><div class="feature"><strong>② 記事を読む</strong><p>本文は上下にスクロール。「前へ」「次へ」で記事を切り替えます。横スワイプでも移動できます。</p></div><div class="feature"><strong>③ スキする</strong><p>「♡ noteでスキ」を押すと、Firefoxでログイン中のnoteアカウントから送信します。成功した記事だけ読了になります。</p></div><div class="feature"><strong>④ コメントを確認・返信</strong><p>「コメントを見る」から会話を確認し、Reader内で新規コメントや返信を送れます。</p></div><div class="feature"><strong>⑤ マガジンに保存</strong><p>記事の最後にある緑色の「マガジンを選ぶ」から、自分のマガジンへ追加できます。追加だけでは読了になりません。</p></div></div>
  <div class="notice"><strong>「次へ」だけでは読了になりません</strong><p>記事へのスキ、または新規コメントの送信に成功したときだけ読了になります。あとで読み返したい記事を飛ばしても消えません。</p></div>
</section>

<section class="section" id="modes"><div class="section-head"><span class="num">5</span><div><h2>読みたい記事の選び方</h2><p>上部の「フィード」で切り替えられます。</p></div></div>
  <div class="mode-list"><div class="mode"><b>💐 ありがとうフィード</b><span>過去7日間にスキやコメントをくれた人を表示します。回数が多い人ほど早めに出やすくしつつ、同じ人は1巡に1回だけです。最新記事優先／プロフィール優先を選べます。</span></div><div class="mode"><b>🆕 最新記事優先</b><span>各ユーザーの記事を公開日時（時分秒まで）で比べ、いちばん新しい記事を表示します。</span></div><div class="mode"><b>📌 固定記事優先</b><span>各ユーザーの記事一覧の1記事目を表示します。自己紹介などの固定記事を読みたいときに向いています。</span></div><div class="mode"><b>👤 プロフィール優先</b><span>プロフィール記事を設定しているユーザーだけを対象に、その記事を表示します。</span></div><div class="mode"><b>🌸 特に読みたい人</b><span>自分で作ったリストから、未読を優先しつつ偏りを抑えて表示します。</span></div><div class="mode"><b>🔎 キーワード / #ハッシュタグ</b><span>登録していない人の記事も探せます。通常のキーワード検索には拡張機能の連携が必要です。</span></div></div>
</section>

<section class="section" id="trouble"><div class="section-head"><span class="num">6</span><div><h2>困ったとき</h2><p>よくある原因から順番に確認してください。</p></div></div>
  <div class="faq"><details open><summary>「未接続」と表示される</summary><p>Readerとnoteを同じFirefoxで開いてください。それでも変わらない場合は、Firefoxの「アドオン」からNERO Favorite Reader Bridgeが有効か確認し、Readerを再読み込みします。</p></details><details><summary>XPIを選んでもインストールできない</summary><p>ファイルの末尾が .xpi か確認してください。ZIPはインストール用ではありません。古いXPIが残っている場合は削除し、メンバー限定記事から最新版を保存し直します。</p></details><details><summary>記事やコメントが読み込まれない</summary><p>同じFirefoxでnote.comを開き、ログイン状態を確認してください。通信が不安定な場合は少し待ってからReaderを再読み込みします。</p></details><details><summary>機種変更やFirefoxのデータ削除をした</summary><p>「特に読みたい人」のリストと読了状態は端末内に保存されるため、自動では引き継がれません。必要なユーザーを新しい端末で登録し直してください。</p></details><details><summary>アップデートのお知らせが来た</summary><p>古いBridgeをFirefoxのアドオン画面から削除し、メンバー限定記事にある新しい署名済みXPIをインストールしてください。</p></details></div>
</section>

<section class="cta"><h2>準備ができたら、さっそく読んでみましょう</h2><p>Readerは公開ページですが、連携機能を使うにはメンバー限定で配布するBridgeが必要です。ログイン情報やコメント本文を運営側へ保存することはありません。</p><a class="button" href="/">NERO Favorite Readerを開く</a><div class="subnote">※ NERO Favorite Readerはnote株式会社の公式サービスではありません。</div></section>
</main>
<footer class="footer"><div class="wrap">NERO Favorite Reader Guide · Bridge v0.1.30</div></footer>
</body>
</html>`;

const JSON_HEADERS = {
  "content-type": "application/json; charset=utf-8",
  "cache-control": "public, max-age=120",
};

function json(data, status = 200, extra = {}) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { ...JSON_HEADERS, ...extra },
  });
}

function normalizeUrlname(value) {
  return String(value || "")
    .trim()
    .replace(/^https?:\/\/(?:www\.)?note\.com\//i, "")
    .replace(/^@/, "")
    .split(/[/?#]/)[0]
    .replace(/[^a-zA-Z0-9_-]/g, "")
    .slice(0, 80);
}

function normalizeKey(value) {
  const raw = String(value || "").trim();
  if (/^[a-zA-Z0-9_-]{4,160}$/.test(raw)) return raw;
  const match = raw.match(/note\.com\/[^/]+\/n\/([a-zA-Z0-9_-]+)/i);
  return match ? match[1] : "";
}

async function noteFetch(url, ttl = 180) {
  let cache = null;
  const cacheKey = new Request(url, { method: "GET" });
  try {
    cache = caches.default;
    const cached = await cache.match(cacheKey);
    if (cached) return cached;
  } catch (_) {
    cache = null;
  }

  const response = await fetch(url, {
    headers: {
      accept: "application/json, text/plain, */*",
      "user-agent": "NERO-Favorite-Reader/0.1.30 (+https://note.com)",
    },
  });

  if (!response.ok) {
    throw new Error("note API returned " + response.status);
  }

  const stored = new Response(response.body, response);
  stored.headers.set("cache-control", "public, max-age=" + ttl);
  if (cache) {
    try {
      await cache.put(cacheKey, stored.clone());
    } catch (_) {
      // Sites may disable the default Worker cache. The response remains usable.
    }
  }
  return stored;
}

function contentRows(payload) {
  const data = payload && payload.data ? payload.data : payload;
  if (Array.isArray(data)) return data;
  if (data && Array.isArray(data.contents)) return data.contents;
  if (data && data.contents && Array.isArray(data.contents.contents)) return data.contents.contents;
  if (data && Array.isArray(data.notes)) return data.notes;
  return [];
}

function profileData(payload) {
  const data = payload && payload.data ? payload.data : payload;
  return data && data.user ? data.user : data || {};
}

function normalizeContent(row, fallbackUrlname, profile = {}) {
  const user = row.user || row.author || row.actor || {};
  const urlname = user.urlname || row.urlname || fallbackUrlname;
  const key = row.key || row.noteKey || row.id || "";
  const canonical = row.noteUrl || row.url || (key ? "https://note.com/" + urlname + "/n/" + key : "https://note.com/" + urlname);
  return {
    key,
    name: row.name || row.title || "無題の記事",
    description: row.description || row.bodyText || row.summary || "",
    eyecatch: row.eyecatch || row.eyecatchUrl || row.eyecatch_url || row.image || "",
    publishAt: row.publishAt || row.publish_at || row.createdAt || row.created_at || "",
    url: canonical,
    urlname,
    nickname: user.nickname || user.name || profile.nickname || profile.name || urlname,
    userIcon: user.userProfileImagePath || user.profileImageUrl || user.user_profile_image_url || user.profile_image_url || profile.userProfileImagePath || profile.profileImageUrl || profile.user_profile_image_url || "",
    likeCount: row.likeCount || row.like_count || 0,
    commentCount: row.commentCount || row.comment_count || 0,
    isPinned: row.isPinned === true || row.is_pinned === true,
    isProfiled: row.isProfiled === true || row.is_profiled === true,
  };
}

function selectCreatorContents(rows, selection, limit) {
  const sourceRows = Array.isArray(rows) ? rows : [];
  if (selection === "profile") {
    const profiled = sourceRows.find((row) => row && (row.isProfiled === true || row.is_profiled === true));
    return profiled ? [profiled] : [];
  }
  if (selection === "first") return sourceRows.slice(0, 1);
  if (selection === "latest") {
    return sourceRows.slice().sort((left, right) => {
      const rightTime = Date.parse(right && (right.publishAt || right.publish_at || right.createdAt || right.created_at) || "") || 0;
      const leftTime = Date.parse(left && (left.publishAt || left.publish_at || left.createdAt || left.created_at) || "") || 0;
      return rightTime - leftTime;
    }).slice(0, 1);
  }
  return sourceRows.slice(0, limit);
}

async function fetchContents(urlname, limit, page = 1, selection = "") {
  const contentsUrl = "https://note.com/api/v2/creators/" + encodeURIComponent(urlname) + "/contents?kind=note&page=" + page;
  const contentsRes = await noteFetch(contentsUrl, 180);
  const contentsPayload = await contentsRes.json();
  return selectCreatorContents(contentRows(contentsPayload), selection, limit)
    .map((row) => normalizeContent(row, urlname));
}

async function creatorFeed(request) {
  const url = new URL(request.url);
  const urlname = normalizeUrlname(url.searchParams.get("urlname"));
  const limit = Math.max(1, Math.min(Number(url.searchParams.get("limit")) || 6, 20));
  if (!urlname) return json({ error: "creator is required" }, 400);

  try {
    const profileUrl = "https://note.com/api/v2/creators/" + encodeURIComponent(urlname);
    const [profileRes, contentsRes] = await Promise.all([
      noteFetch(profileUrl, 600),
      noteFetch("https://note.com/api/v2/creators/" + encodeURIComponent(urlname) + "/contents?kind=note&page=1", 180),
    ]);
    const profilePayload = await profileRes.json();
    const contentsPayload = await contentsRes.json();
    const profile = profileData(profilePayload);
    const items = contentRows(contentsPayload)
      .slice(0, limit)
      .map((row) => normalizeContent(row, urlname, profile));
    return json({ creator: { urlname, nickname: profile.nickname || profile.name || urlname }, items });
  } catch (error) {
    return json({ error: "creator feed could not be loaded", detail: String(error.message || error) }, 502);
  }
}

async function mixedFeed(request) {
  const url = new URL(request.url);
  const creators = [...new Set(String(url.searchParams.get("creators") || "")
    .split(",")
    .map(normalizeUrlname)
    .filter(Boolean))].slice(0, 50);
  const perCreator = Math.max(1, Math.min(Number(url.searchParams.get("limit")) || 8, 10));
  const selection = ["latest", "first", "profile"].includes(url.searchParams.get("selection")) ? url.searchParams.get("selection") : "";
  // Reader feeds normally stop much earlier, while the owner's explicit
  // inbox audit may need to walk hundreds of archive pages.
  const page = Math.max(1, Math.min(Number(url.searchParams.get("page")) || 1, 1000));
  if (!creators.length) return json({ error: "creators are required" }, 400);

  const settled = await Promise.allSettled(creators.map((name) => fetchContents(name, perCreator, page, selection)));
  const items = [];
  const failed = [];
  settled.forEach((result, index) => {
    if (result.status === "fulfilled") items.push(...result.value);
    else failed.push(creators[index]);
  });
  const status = items.length || failed.length < creators.length ? 200 : 502;
  return json({ items, failed, creatorCount: creators.length, page, selection }, status);
}

async function searchFeed(request) {
  const url = new URL(request.url);
  const raw = String(url.searchParams.get("q") || "").trim().slice(0, 80);
  const page = Math.max(1, Math.min(Number(url.searchParams.get("page")) || 1, 30));
  if (!raw) return json({ error: "search query is required" }, 400);
  if (!raw.startsWith("#")) {
    return json({ error: "keyword search requires the Firefox extension", requiresExtension: true }, 409);
  }
  const tag = raw.replace(/^#+/, "").trim();
  if (!tag) return json({ error: "hashtag is required" }, 400);
  try {
    const endpoint = "https://note.com/api/v3/hashtags/" + encodeURIComponent(tag) + "/notes?order=new&page=" + page + "&paid_only=false";
    const response = await noteFetch(endpoint, 120);
    const payload = await response.json();
    const items = contentRows(payload).map((row) => normalizeContent(row, ""));
    return json({ items, failed: [], page, query: "#" + tag });
  } catch (error) {
    return json({ error: "hashtag search could not be loaded", detail: String(error.message || error) }, 502);
  }
}

async function hydrateMoneyEmbeds(body, articleUrl) {
  let html = String(body || "");
  if (!articleUrl || !/data-src=["']https:\/\/money\.note\.com\/companies\/[0-9]+/i.test(html)) return html;
  try {
    const response = await noteFetch(articleUrl, 300);
    const page = await response.text();
    const embeds = [...page.matchAll(/https:\/\/money\.note\.com\/embed\/charts\/([0-9]+)[^"'<]*/gi)]
      .map((match) => ({ company: match[1], src: match[0] }));
    for (const embed of embeds) {
      const companyPattern = new RegExp('data-src=(["\\\'])https:\\/\\/money\\.note\\.com\\/companies\\/' + embed.company + '\\1', 'i');
      html = html.replace(companyPattern, 'data-src="' + embed.src + '"');
    }
  } catch (_) {
    // If note's rendered page cannot be read, the sanitizer still shows a
    // visible link card instead of leaving an unexplained blank space.
  }
  return html;
}

async function article(request) {
  const url = new URL(request.url);
  const key = normalizeKey(url.searchParams.get("key"));
  if (!key) return json({ error: "article key is required" }, 400);
  try {
    const response = await noteFetch("https://note.com/api/v3/notes/" + encodeURIComponent(key), 300);
    const payload = await response.json();
    const data = payload && payload.data ? payload.data : payload;
    const user = data.user && typeof data.user === "object" ? data.user : {};
    const urlname = user.urlname || data.urlname || "";
    const articleUrl = urlname ? "https://note.com/" + urlname + "/n/" + key : "";
    const body = await hydrateMoneyEmbeds(data.body || data.bodyHtml || data.body_html || "", articleUrl);
    return json({
      key,
      name: data.name || data.title || "無題の記事",
      body,
      description: data.description || data.summary || "",
      eyecatch: data.eyecatch || data.eyecatchUrl || "",
      publishAt: data.publishAt || data.publish_at || "",
      urlname,
      nickname: user.nickname || user.name || urlname,
      userIcon: user.userProfileImagePath || user.profileImageUrl || user.user_profile_image_url || user.profile_image_url || "",
      url: articleUrl,
    });
  } catch (error) {
    return json({ error: "article could not be loaded", detail: String(error.message || error) }, 502);
  }
}

export default {
  async fetch(request) {
    const url = new URL(request.url);
    if (request.method !== "GET") return new Response("Method Not Allowed", { status: 405 });
    if (url.pathname === "/api/creator-feed") return creatorFeed(request);
    if (url.pathname === "/api/mixed-feed") return mixedFeed(request);
    if (url.pathname === "/api/search-feed") return searchFeed(request);
    if (url.pathname === "/api/article") return article(request);
    if (url.pathname === "/members/start" || url.pathname === "/members/start/") {
      return new Response(GUIDE_PAGE, {
        headers: {
          "content-type": "text/html; charset=utf-8",
          "cache-control": "no-cache",
          "content-security-policy": "default-src 'self'; script-src 'none'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'none'; frame-ancestors 'none'; base-uri 'none'; form-action 'none'",
          "referrer-policy": "no-referrer",
          "x-content-type-options": "nosniff",
          "x-robots-tag": "noindex, nofollow, noarchive",
        },
      });
    }
    if (url.pathname === "/" || url.pathname === "/index.html" || url.pathname === "/nero-favorites" || url.pathname === "/nero-favorites/") {
      return new Response(PAGE, {
        headers: {
          "content-type": "text/html; charset=utf-8",
          "cache-control": "no-cache",
          "content-security-policy": "default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; img-src 'self' https: data:; media-src https:; connect-src 'self'; frame-src https://note.com https://money.note.com; frame-ancestors 'none'; base-uri 'none'; form-action 'none'",
          "referrer-policy": "strict-origin-when-cross-origin",
          "x-content-type-options": "nosniff",
          "x-robots-tag": "noindex, nofollow, noarchive",
        },
      });
    }
    return new Response("Not Found", { status: 404 });
  },
};
