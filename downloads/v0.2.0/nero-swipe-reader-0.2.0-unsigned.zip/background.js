'use strict';

const READER_URL = browser.runtime.getURL('reader/index.html');
const READER_ORIGIN = new URL(READER_URL).origin;
const NOTE_ARTICLE = /^https:\/\/(?:www\.)?note\.com\/[a-zA-Z0-9_-]+\/n\/[a-zA-Z0-9_-]+(?:[/?#].*)?$/;
const NOTE_API = 'https://note.com/api';
const recentOperations = new Map();
const statusCache = new Map();
const STATUS_CACHE_MS = 2 * 60 * 1000;
const ACCOUNT_CACHE_MS = 10 * 60 * 1000;
let viewerAccountCache = null;
let activeOperation = null;

function isAllowedArticleUrl(value) {
  try {
    const url = new URL(String(value || ''));
    return NOTE_ARTICLE.test(url.href) && url.protocol === 'https:';
  } catch (_) {
    return false;
  }
}

function articleKey(value) {
  const match = String(value || '').match(/\/n\/([a-zA-Z0-9_-]+)/);
  return match ? match[1] : '';
}

function normalizeReplyTarget(value) {
  if (!value || typeof value !== 'object') return null;
  const key = String(value.key || '').replace(/[^a-zA-Z0-9_-]/g, '').slice(0, 160);
  const commentKey = String(value.commentKey || '').replace(/[^a-zA-Z0-9_-]/g, '').slice(0, 160);
  const rootKey = String(value.rootKey || key).replace(/[^a-zA-Z0-9_-]/g, '').slice(0, 160);
  const authorUrlname = String(value.authorUrlname || '').replace(/[^a-zA-Z0-9_-]/g, '').slice(0, 80);
  const authorName = String(value.authorName || '').replace(/\s+/g, ' ').trim().slice(0, 160);
  const body = String(value.body || '').replace(/\s+/g, ' ').trim().slice(0, 1000);
  const publishedAt = String(value.publishedAt || '').trim().slice(0, 80);
  const depth = Number(value.depth) ? 1 : 0;
  const rootAuthorUrlname = String(value.rootAuthorUrlname || '').replace(/[^a-zA-Z0-9_-]/g, '').slice(0, 80);
  const rootBody = String(value.rootBody || '').replace(/\s+/g, ' ').trim().slice(0, 1000);
  if (!authorUrlname || !body) return null;
  return { key, commentKey, rootKey, authorUrlname, authorName, body, publishedAt, depth, rootAuthorUrlname, rootBody, liked: value.liked === true };
}

function normalizeMagazineTarget(message) {
  const key = String(message && message.magazineKey || '').replace(/[^a-zA-Z0-9_-]/g, '').slice(0, 160);
  const name = String(message && message.magazineName || '').replace(/\s+/g, ' ').trim().slice(0, 160);
  const hasIndex = Boolean(message && Object.prototype.hasOwnProperty.call(message, 'magazineIndex'));
  const index = Math.max(0, Math.min(Number(message && message.magazineIndex) || 0, 2000));
  if (!key && !name && !hasIndex) return null;
  return { key, name, index };
}

function delay(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

async function fetchNoteJson(path, timeoutMs = 8000) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const response = await fetch(NOTE_API + path, {
      method: 'GET',
      credentials: 'include',
      cache: 'no-store',
      headers: { Accept: 'application/json' },
      signal: controller.signal
    });
    if (!response.ok) {
      const error = new Error('note API returned ' + response.status);
      error.status = response.status;
      throw error;
    }
    return await response.json();
  } finally {
    clearTimeout(timer);
  }
}

function noteMutationErrorMessage(payload, fallback) {
  const values = [
    payload && payload.message,
    payload && payload.error,
    payload && payload.errors,
    payload && payload.data && payload.data.message,
    payload && payload.data && payload.data.error,
    payload && payload.data && payload.data.errors
  ];
  const pending = [...values];
  while (pending.length) {
    const value = pending.shift();
    if (typeof value === 'string' && value.trim()) return value.trim();
    if (Array.isArray(value)) {
      pending.unshift(...value);
      continue;
    }
    if (value && typeof value === 'object') {
      for (const key of ['message', 'detail', 'reason', 'title', 'code']) {
        if (typeof value[key] === 'string' && value[key].trim()) return value[key].trim();
      }
    }
  }
  return fallback;
}

function isMagazineAlreadyError(status, message) {
  const text = String(message || '');
  return Number(status) === 409 || /already|duplicate|追加済|登録済|含まれて|(?:すでに|既に).*(?:追加|登録|入って)/i.test(text);
}

function isMagazineItemRejection(status, message) {
  const code = Number(status);
  return Boolean(String(message || '').trim()) && [400, 404, 410, 422].includes(code);
}

function responseRetryAfterMs(response, now = Date.now()) {
  if (!response || !response.headers || typeof response.headers.get !== 'function') return 0;
  const retryAfter = String(response.headers.get('Retry-After') || '').trim();
  if (/^\d+(?:\.\d+)?$/.test(retryAfter)) return Math.max(0, Math.round(Number(retryAfter) * 1000));
  const retryDate = Date.parse(retryAfter);
  if (Number.isFinite(retryDate)) return Math.max(0, retryDate - now);
  const reset = Number(response.headers.get('X-RateLimit-Reset') || response.headers.get('RateLimit-Reset') || 0);
  if (!Number.isFinite(reset) || reset <= 0) return 0;
  const resetAt = reset > 1000000000000 ? reset : reset * 1000;
  return Math.max(0, resetAt - now);
}

async function fetchNoteMutation(path, options = {}) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), Number(options.timeoutMs) || 10000);
  const headers = {
    Accept: 'application/json',
    'X-Requested-With': 'XMLHttpRequest',
    // The extension background has no page localStorage. This is the same
    // explicit fallback note uses when note-client-code storage is disabled.
    'X-LS-Disabled': 'true'
  };
  let body;
  if (options.body !== undefined) {
    headers['Content-Type'] = 'application/json';
    body = JSON.stringify(options.body);
  }
  try {
    const response = await fetch(NOTE_API + path, {
      method: options.method || 'POST',
      credentials: 'include',
      cache: 'no-store',
      headers,
      body,
      signal: controller.signal
    });
    let payload = null;
    try { payload = await response.json(); } catch (_) {}
    return { response, payload };
  } finally {
    clearTimeout(timer);
  }
}

function noteCommentAst(value) {
  return {
    type: 'root',
    children: [{
      type: 'element',
      // note's API client converts the frontend's camelCase AST to
      // snake_case before it sends the request. Direct requests must use the
      // wire-format key already.
      tag_name: 'p',
      children: [{ type: 'text', value: String(value || '').replace(/\r\n?/g, '\n') }]
    }]
  };
}

async function runDirectCommentMutation(articleUrl, comment, replyTarget) {
  const noteKey = articleKey(articleUrl);
  const body = {
    comment: noteCommentAst(comment),
    acknowledgement: false,
    caller_name: 'createNoteCommentV3'
  };
  if (replyTarget && replyTarget.key) body.parent_key = replyTarget.key;
  try {
    const { response, payload } = await fetchNoteMutation('/v3/notes/' + encodeURIComponent(noteKey) + '/note_comments', { body });
    if (response.ok && !(payload && payload.error)) {
      const data = payload && payload.data !== undefined ? payload.data : payload;
      const created = data && data.comment ? data.comment : data;
      return { ok: true, action: 'comment', verified: true, source: 'note_api_v3_extension', commentKey: String(created && created.key || '') };
    }
    if (response.status === 401 || response.status === 403) {
      return { ok: false, code: 'login_required', message: 'Firefoxでnoteへログインしてください。', status: response.status };
    }
    const error = payload && (payload.error || payload.data && payload.data.error);
    if (error && error.type === 'comment_acknowledgement') {
      return { ok: false, code: 'comment_acknowledgement', message: 'このコメントはnote側で確認操作が必要です。', status: response.status };
    }
    return {
      ok: false,
      code: 'comment_api_rejected',
      message: noteMutationErrorMessage(payload, 'noteがコメントを受け付けませんでした。'),
      status: response.status
    };
  } catch (error) {
    if (error && error.name === 'AbortError') {
      return { ok: false, code: 'comment_result_unknown', message: '10秒以内に送信結果を確認できませんでした。二重投稿を防ぐため自動再送はしていません。' };
    }
    const detail = [error && error.name, error && error.message].filter(Boolean).join(': ').slice(0, 180);
    return { ok: false, code: 'comment_api_unavailable', message: 'noteとの通信に失敗しました。' + (detail ? ' ' + detail : ''), detail };
  }
}

async function runDirectCommentLikeMutation(articleUrl, replyTarget) {
  const noteKey = articleKey(articleUrl);
  const commentKey = String(replyTarget && replyTarget.commentKey || '');
  if (!commentKey) return { ok: false, code: 'comment_target_missing', message: '対象コメントの識別情報を確認できませんでした。' };
  if (replyTarget && replyTarget.liked === true) {
    return { ok: true, action: 'comment_like', already: true, verified: true, source: 'note_api_v3_extension' };
  }
  try {
    const { response, payload } = await fetchNoteMutation(
      '/v3/notes/' + encodeURIComponent(noteKey) + '/note_comments/' + encodeURIComponent(commentKey) + '/likes'
    );
    if (response.ok && !(payload && payload.error)) {
      return { ok: true, action: 'comment_like', already: false, verified: true, source: 'note_api_v3_extension' };
    }
    if (response.status === 401 || response.status === 403) {
      return { ok: false, code: 'login_required', message: 'Firefoxでnoteへログインしてください。', status: response.status };
    }
    if (response.status === 404) {
      return { ok: false, code: 'comment_target_missing', message: '対象のコメントが見つかりませんでした。', status: response.status };
    }
    return {
      ok: false,
      code: 'comment_like_api_rejected',
      message: noteMutationErrorMessage(payload, 'noteがコメントへのスキを受け付けませんでした。'),
      status: response.status
    };
  } catch (error) {
    if (error && error.name === 'AbortError') {
      return { ok: false, code: 'comment_like_result_unknown', message: '10秒以内に結果を確認できませんでした。自動再送はしていません。' };
    }
    const detail = [error && error.name, error && error.message].filter(Boolean).join(': ').slice(0, 180);
    return { ok: false, code: 'comment_like_api_unavailable', message: 'noteとの通信に失敗しました。' + (detail ? ' ' + detail : ''), detail };
  }
}

async function runDirectArticleLikeMutation(articleUrl) {
  const noteKey = articleKey(articleUrl);
  const before = await runStatusApi(articleUrl, true);
  if (before && before.ok && before.liked === true) {
    return { ok: true, action: 'like', already: true, verified: true, source: 'note_api_v3_extension' };
  }
  try {
    const { response, payload } = await fetchNoteMutation('/v3/notes/' + encodeURIComponent(noteKey) + '/likes');
    if (response.status === 401 || response.status === 403) {
      return { ok: false, code: 'login_required', message: 'Firefoxでnoteへログインしてください。', status: response.status };
    }
    if (!response.ok && response.status !== 409) {
      return {
        ok: false,
        code: 'like_api_rejected',
        message: noteMutationErrorMessage(payload, 'noteがこの記事へのスキを受け付けませんでした。'),
        status: response.status
      };
    }
    for (let attempt = 0; attempt < 4; attempt += 1) {
      if (attempt) await delay(250 * attempt);
      const verified = await runStatusApi(articleUrl, true);
      if (verified && verified.ok && verified.liked === true) {
        return { ok: true, action: 'like', already: response.status === 409, verified: true, source: 'note_api_v3_extension' };
      }
    }
    return { ok: false, code: 'like_result_unknown', message: 'note側でスキ済みになったことを確認できませんでした。成功扱いにはしていません。' };
  } catch (error) {
    if (error && error.name === 'AbortError') {
      return { ok: false, code: 'like_result_unknown', message: '10秒以内にスキ結果を確認できませんでした。自動再送はしていません。' };
    }
    return { ok: false, code: 'like_api_unavailable', message: 'noteとの通信に失敗しました。Reader画面はそのままです。' };
  }
}

function commentAstText(node) {
  if (!node || typeof node !== 'object') return '';
  if (node.type === 'text') return String(node.value || '');
  const children = Array.isArray(node.children) ? node.children : [];
  const parts = children.map(commentAstText).filter(Boolean);
  if (node.type === 'root') return parts.join('\n\n').trim();
  return parts.join('').trim();
}

function normalizeApiComment(value, threadIndex, depth, rootKey, rootMeta) {
  const user = value && value.user && typeof value.user === 'object' ? value.user : {};
  return {
    key: String(value && value.key || ''),
    rootKey: String(rootKey || value && value.key || ''),
    authorUrlname: String(user.urlname || ''),
    authorName: String(user.nickname || user.name || user.urlname || ''),
    body: commentAstText(value && value.comment),
    publishedAt: String(value && value.created_at || ''),
    avatar: String(user.profile_image_url || ''),
    depth: depth ? 1 : 0,
    threadIndex,
    liked: Boolean(value && value.is_liked),
    viewerLiked: Boolean(value && value.is_liked),
    creatorLiked: Boolean(value && value.is_creator_liked),
    isFollowing: typeof user.is_following === 'boolean' ? user.is_following : null,
    isFollower: typeof user.is_follower === 'boolean' ? user.is_follower : null,
    rootAuthorUrlname: String(rootMeta && rootMeta.authorUrlname || user.urlname || ''),
    rootBody: String(rootMeta && rootMeta.body || commentAstText(value && value.comment))
  };
}

function likeRows(payload) {
  const data = payload && payload.data !== undefined ? payload.data : payload;
  if (Array.isArray(data)) return data;
  if (data && Array.isArray(data.likes)) return data.likes;
  if (data && data.likes && Array.isArray(data.likes.contents)) return data.likes.contents;
  if (data && Array.isArray(data.users)) return data.users;
  if (data && Array.isArray(data.contents)) return data.contents;
  return [];
}

function normalizeEngagementUser(value) {
  const row = value && value.user && typeof value.user === 'object' ? value.user : (value || {});
  const urlname = String(row.urlname || '').replace(/[^a-zA-Z0-9_-]/g, '').slice(0, 80);
  return {
    key: String(row.key || row.id || ''),
    urlname,
    nickname: String(row.nickname || row.name || urlname),
    userIcon: String(row.user_profile_image_url || row.userProfileImagePath || row.profileImageUrl || row.profile_image_url || ''),
    isFollowing: typeof row.is_following === 'boolean' ? row.is_following : null,
    isFollower: typeof row.is_follower === 'boolean' ? row.is_follower : null
  };
}

function normalizeApiLike(value) {
  const user = normalizeEngagementUser(value);
  return {
    ...user,
    createdAt: String(value && (value.created_at || value.createdAt || value.liked_at || value.likedAt) || '')
  };
}

async function fetchNoteLikes(noteKey, cutoffMs) {
  const likes = [];
  let start = 0;
  let previousMarker = '';
  let apiVersion = 'v3';
  for (let round = 0; round < 20; round += 1) {
    const params = new URLSearchParams({ size: '100', start: String(start) });
    let payload;
    try {
      payload = await fetchNoteJson('/' + apiVersion + '/notes/' + encodeURIComponent(noteKey) + '/likes?' + params.toString(), 10000);
    } catch (error) {
      if (round > 0) throw error;
      apiVersion = 'v2';
      payload = await fetchNoteJson('/v2/notes/' + encodeURIComponent(noteKey) + '/likes?' + params.toString(), 10000);
    }
    let rows = likeRows(payload);
    if (!rows.length) break;
    let normalized = rows.map(normalizeApiLike).filter((row) => row.urlname && row.createdAt);
    if (round === 0 && apiVersion === 'v3' && rows.length && !normalized.length) {
      apiVersion = 'v2';
      payload = await fetchNoteJson('/v2/notes/' + encodeURIComponent(noteKey) + '/likes?' + params.toString(), 10000);
      rows = likeRows(payload);
      normalized = rows.map(normalizeApiLike).filter((row) => row.urlname && row.createdAt);
    }
    const first = rows[0] || {};
    const firstUser = first.user && typeof first.user === 'object' ? first.user : first;
    const marker = String(first.created_at || first.createdAt || first.liked_at || first.likedAt || '') + ':' + String(firstUser.key || firstUser.id || firstUser.urlname || '');
    if (marker && marker === previousMarker) break;
    previousMarker = marker;
    likes.push(...normalized);
    const oldest = normalized.reduce((value, row) => Math.min(value, Date.parse(row.createdAt) || Infinity), Infinity);
    if (Number.isFinite(oldest) && oldest < cutoffMs) break;
    if (rows.length < 100) break;
    start += rows.length;
  }
  return likes;
}

async function runEngagementArticleApi(articleUrl, options = {}) {
  const includeLikes = options.includeLikes !== false;
  const includeComments = options.includeComments !== false;
  const cutoffMs = Math.max(0, Number(options.cutoffMs) || Date.now() - 7 * 24 * 60 * 60 * 1000);
  const result = {
    ok: true,
    action: 'engagement_article',
    articleUrl,
    likes: [],
    comments: [],
    likesOk: !includeLikes,
    commentsOk: !includeComments,
    verified: true,
    source: 'note_api_v3'
  };
  if (includeLikes) {
    try {
      result.likes = await fetchNoteLikes(articleKey(articleUrl), cutoffMs);
      result.likesOk = true;
    } catch (_) {
      result.likesOk = false;
    }
  }
  if (includeComments) {
    try {
      result.comments = await fetchNoteComments(articleKey(articleUrl), true);
      result.commentsOk = true;
    } catch (_) {
      result.commentsOk = false;
    }
  }
  result.ok = result.likesOk && result.commentsOk;
  if (!result.ok) {
    result.code = 'engagement_article_partial';
    result.message = 'この記事のスキまたはコメントをすべて確認できませんでした。';
  }
  return result;
}

async function runArticleReactorsApi(articleUrl) {
  try {
    const [likes, comments, account] = await Promise.all([
      fetchNoteLikes(articleKey(articleUrl), 0),
      fetchNoteComments(articleKey(articleUrl), false),
      getViewerAccount(true)
    ]);
    const owner = String(account && account.urlname || '');
    if (!owner) return { ok: false, code: 'login_required', message: 'Firefoxでnoteへログインしてください。' };
    const creators = new Map();
    function ensure(urlname, row) {
      const key = String(urlname || '').toLowerCase();
      if (!key || key === owner.toLowerCase()) return null;
      let creator = creators.get(key);
      if (!creator) {
        creator = {
          urlname: String(urlname),
          nickname: String(row && (row.nickname || row.authorName || row.name) || urlname),
          userIcon: String(row && (row.userIcon || row.avatar) || ''),
          liked: false,
          commented: false,
          likeCount: 0,
          commentCount: 0,
          lastActionAt: ''
        };
        creators.set(key, creator);
      }
      return creator;
    }
    function rememberTime(creator, value) {
      const next = Date.parse(String(value || '')) || 0;
      const current = Date.parse(String(creator.lastActionAt || '')) || 0;
      if (next > current) creator.lastActionAt = new Date(next).toISOString();
    }
    likes.forEach((row) => {
      const creator = ensure(row.urlname, row);
      if (!creator) return;
      creator.liked = true;
      creator.likeCount += 1;
      rememberTime(creator, row.createdAt);
    });
    comments.forEach((row) => {
      const creator = ensure(row.authorUrlname, row);
      if (!creator) return;
      creator.commented = true;
      creator.commentCount += 1;
      rememberTime(creator, row.publishedAt);
    });
    const ordered = Array.from(creators.values()).sort((left, right) => {
      if (left.commented !== right.commented) return left.commented ? -1 : 1;
      const time = Date.parse(right.lastActionAt || '') - Date.parse(left.lastActionAt || '');
      if (time) return time;
      return left.urlname.localeCompare(right.urlname);
    });
    return {
      ok: true,
      action: 'article_reactors',
      articleUrl,
      owner,
      creators: ordered,
      stats: {
        creatorCount: ordered.length,
        likeCount: likes.length,
        commentCount: comments.filter((row) => String(row.authorUrlname || '').toLowerCase() !== owner.toLowerCase()).length,
        commenterCount: ordered.filter((row) => row.commented).length
      },
      verified: true,
      source: 'note_api_v2_v3'
    };
  } catch (error) {
    return {
      ok: false,
      code: error && error.name === 'AbortError' ? 'article_reactors_timeout' : 'article_reactors_failed',
      message: 'この記事のスキ・コメント反応者を取得できませんでした。少し待ってからもう一度お試しください。'
    };
  }
}

async function fetchCommentCollection(noteKey, parentKey) {
  const rows=[],seen=new Set();let page=1;
  for(let round=0;round<10000;round++) {
    if(seen.has(page))throw new Error('Repeated comment page');
    seen.add(page);
    const params=new URLSearchParams({page:String(page),per_page:'100',order:parentKey?'oldest':'newest'});
    if(parentKey)params.set('parent_key',parentKey);
    const payload=await fetchNoteJson('/v3/notes/'+encodeURIComponent(noteKey)+'/note_comments?'+params.toString());
    if(!Array.isArray(payload?.data))throw new Error('Unexpected comment response');
    rows.push(...payload.data);
    const next=Number(payload.next_page);
    if(!next)return rows;
    page=next;
  }
  throw new Error('Comment pagination limit reached; not a complete scan');
}

async function fetchNoteComments(noteKey, summaryOnly) {
  const roots = await fetchCommentCollection(noteKey, '');
  // The root response only exposes a creator-reply summary. It does not prove
  // that the creator was the last person in the thread: a reader may have
  // replied again afterwards. Fetch every non-empty reply thread so the inbox
  // can determine the real last creator response without false positives.
  const replyGroups = new Array(roots.length).fill(null).map(() => []);
  let cursor = 0;
  async function worker() {
    while (cursor < roots.length) {
      const index = cursor;
      cursor += 1;
      const root = roots[index];
      const replyCount = Number(root && root.reply_count || 0);
      if (!replyCount) continue;
      const embedded = Array.isArray(root.replies) ? root.replies : [];
      if (embedded.length >= replyCount) {
        replyGroups[index] = embedded;
        continue;
      }
      replyGroups[index] = await fetchCommentCollection(noteKey, String(root.key || ''));
    }
  }
  await Promise.all(Array.from({ length: Math.min(3, roots.length) }, worker));
  const comments = [];
  roots.forEach((root, index) => {
    const rootComment = normalizeApiComment(root, index, 0, root.key);
    comments.push(rootComment);
    const rootMeta = { authorUrlname: rootComment.authorUrlname, body: rootComment.body };
    replyGroups[index].forEach((reply) => comments.push(normalizeApiComment(reply, index, 1, root.key, rootMeta)));
  });
  return comments.filter((comment) => comment.authorUrlname && comment.body);
}

async function runCommentsApi(articleUrl, summaryOnly) {
  try {
    const [comments, account] = await Promise.all([
      fetchNoteComments(articleKey(articleUrl), summaryOnly),
      getViewerAccount().catch(() => null)
    ]);
    const viewer = String(account && account.urlname || '');
    return {
      ok: true,
      action: 'comments',
      comments: comments.map((comment) => ({ ...comment, liked: comment.viewerLiked, viewerLikeKnown: true })),
      viewerUrlname: viewer,
      verified: true,
      source: 'note_api_v3'
    };
  } catch (error) {
    return {
      ok: false,
      code: error && error.name === 'AbortError' ? 'comments_timeout' : 'comments_api_failed',
      message: error && error.name === 'AbortError'
        ? 'noteのコメント取得が8秒でタイムアウトしました。'
        : 'noteのコメント取得に失敗しました。少し待ってからもう一度お試しください。'
    };
  }
}

function accountFromPayload(payload) {
  const data = payload && payload.data !== undefined ? payload.data : payload;
  return data && data.user ? data.user : data;
}

async function getViewerAccount(forceRefresh = false) {
  /* Always resolve the current member account. */
  const payload = await fetchNoteJson('/v2/current_user', 4000);
  const account = accountFromPayload(payload);
  if (!account || !account.urlname) return null;
  if (account.key) {
    viewerAccountCache = { value: account, expiresAt: Date.now() + ACCOUNT_CACHE_MS };
    return account;
  }
  try {
    const profile = accountFromPayload(await fetchNoteJson('/v2/creators/' + encodeURIComponent(account.urlname), 4000));
    const resolved = { ...account, key: profile && profile.key || '', followingCount: followingCountFrom(account) || followingCountFrom(profile) };
    viewerAccountCache = { value: resolved, expiresAt: Date.now() + ACCOUNT_CACHE_MS };
    return resolved;
  } catch (_) {
    viewerAccountCache = { value: account, expiresAt: Date.now() + ACCOUNT_CACHE_MS };
    return account;
  }
}

function followingCountFrom(value) {
  const row = value && typeof value === 'object' ? value : {};
  return Number(row.followingCount || row.following_count || row.followingsCount || row.followings_count || 0) || 0;
}

function magazineRows(payload) {
  const data = payload && payload.data !== undefined ? payload.data : payload;
  if (Array.isArray(data)) return data;
  if (!data || typeof data !== 'object') return [];
  for (const key of ['magazines', 'contents', 'items']) {
    if (Array.isArray(data[key])) return data[key];
    if (data[key] && typeof data[key] === 'object') {
      for (const nested of ['magazines', 'contents', 'items']) {
        if (Array.isArray(data[key][nested])) return data[key][nested];
      }
    }
  }
  return [];
}

function normalizeApiMagazine(value, index = 0) {
  const row = value && typeof value === 'object' ? value : {};
  const key = String(row.key || row.magazine_key || row.magazineKey || '').replace(/[^a-zA-Z0-9_-]/g, '').slice(0, 160);
  const name = String(row.name || row.title || '').replace(/\s+/g, ' ').trim().slice(0, 160);
  const price = Number(row.price || 0) || 0;
  const subscribe = Boolean(row.subscribe || row.is_subscribe || row.isSubscribe);
  return {
    key,
    name,
    index,
    kind: subscribe ? '定期購読' : (price > 0 ? '有料' : '無料'),
    available: !subscribe && price <= 0,
    reason: subscribe || price > 0 ? '他の人の記事は無料マガジンのみ追加できます' : ''
  };
}

async function fetchMyMagazines() {
  const payload = await fetchNoteJson('/v1/my/magazines', 6000);
  return magazineRows(payload).map(normalizeApiMagazine).filter((row) => row.key && row.name);
}

function noteNumericId(payload) {
  let data = payload && payload.data !== undefined ? payload.data : payload;
  if (data && data.note && typeof data.note === 'object') data = data.note;
  const id = Number(data && (data.id || data.note_id || data.noteId) || 0);
  return Number.isFinite(id) && id > 0 ? id : 0;
}

async function runDirectMagazineAddMutation(articleUrl, target, expectedAccount = '') {
  const expected = String(expectedAccount || '').replace(/[^a-zA-Z0-9_-]/g, '').slice(0, 80);
  try {
    const account = await getViewerAccount(true);
    const actual = String(account && account.urlname || '');
    if (!actual) return { ok: false, code: 'login_required', message: 'Firefoxでnoteへログインしてください。' };
    if (expected && actual !== expected) {
      return { ok: false, code: 'account_mismatch', message: '現在は @' + actual + ' でログイン中です。@' + expected + ' に切り替えてください。' };
    }
    const magazines = await fetchMyMagazines();
    let magazine = null;
    if (target && target.key) magazine = magazines.find((row) => row.key === target.key) || null;
    if (!magazine && target && target.name) {
      const exact = magazines.filter((row) => row.name === target.name);
      if (exact.length > 1) return { ok: false, code: 'magazine_ambiguous', message: '同名のマガジンが複数あります。重複を整理してからお試しください。' };
      magazine = exact[0] || null;
    }
    if (!magazine && target && !target.key && !target.name) magazine = magazines.find((row) => row.index === Number(target.index)) || null;
    if (!magazine) return { ok: false, code: 'magazine_missing', message: '「' + String(target && target.name || '指定したマガジン') + '」をログイン中のアカウントで確認できませんでした。' };
    if (!magazine.available) return { ok: false, code: 'magazine_unavailable', message: magazine.reason || 'このマガジンには記事を追加できません。' };

    const noteKey = articleKey(articleUrl);
    const notePayload = await fetchNoteJson('/v3/notes/' + encodeURIComponent(noteKey), 6000);
    const noteId = noteNumericId(notePayload);
    if (!noteId) return { ok: false, code: 'note_id_missing', message: '記事IDを確認できなかったため追加を止めました。' };
    const { response, payload } = await fetchNoteMutation('/v1/our/magazines/' + encodeURIComponent(magazine.key) + '/notes', {
      body: { note_id: noteId, note_key: noteKey },
      timeoutMs: 12000
    });
    const data = payload && payload.data !== undefined ? payload.data : payload;
    const apiMessage = noteMutationErrorMessage(payload, '');
    if (response.ok && !apiMessage && (!data || !data.status || data.status === 'success')) {
      return { ok: true, action: 'magazine_add', already: false, verified: true, magazine: { key: magazine.key, name: magazine.name }, source: 'note_api_v1_extension' };
    }
    if (response.status === 429) {
      return {
        ok: false,
        code: 'magazine_rate_limited',
        message: 'noteのマガジン追加制限を検知しました。待機後に自動で再開します。',
        status: response.status,
        retryAfterMs: responseRetryAfterMs(response)
      };
    }
    if (response.status === 401 || response.status === 403) {
      return { ok: false, code: 'login_required', message: 'Firefoxでnoteへログインしてください。', status: response.status };
    }
    const message = apiMessage || 'noteがマガジン追加を受け付けませんでした。';
    if (isMagazineAlreadyError(response.status, message)) {
      return { ok: true, action: 'magazine_add', already: true, verified: true, magazine: { key: magazine.key, name: magazine.name }, source: 'note_api_v1_extension' };
    }
    if (isMagazineItemRejection(response.status, apiMessage)) {
      return { ok: true, action: 'magazine_add', skipped: true, verified: true, code: 'magazine_item_rejected', message, status: response.status, magazine: { key: magazine.key, name: magazine.name }, source: 'note_api_v1_extension' };
    }
    return { ok: false, code: 'magazine_api_rejected', message, status: response.status };
  } catch (error) {
    if (error && error.name === 'AbortError') {
      return { ok: false, code: 'magazine_result_unknown', message: '12秒以内に追加結果を確認できませんでした。二重追加を避けるため自動処理を停止します。' };
    }
    return { ok: false, code: 'magazine_api_unavailable', message: 'noteとのマガジン通信に失敗しました。自動処理を停止します。' };
  }
}

async function runAccountApi() {
  try {
    const account = await getViewerAccount();
    if (!account || !account.urlname) {
      return { ok: false, code: 'login_required', message: 'Firefoxでnoteへログインするか、自分のnoteユーザー名を入力してください。' };
    }
    return { ok: true, action: 'account', urlname: String(account.urlname), nickname: String(account.nickname || account.name || account.urlname), key: String(account.key || ''), followingCount: followingCountFrom(account) };
  } catch (_) {
    return { ok: false, code: 'account_unavailable', message: 'ログイン中のnoteアカウントを確認できませんでした。ユーザー名を入力してください。' };
  }
}

function followingRows(payload) {
  const data = payload && payload.data !== undefined ? payload.data : payload;
  return data && Array.isArray(data.follows) ? data.follows : [];
}

function followingTotalFrom(payload) {
  const data = payload && payload.data !== undefined ? payload.data : payload;
  const row = data && typeof data === 'object' ? data : {};
  const pagination = row.pagination && typeof row.pagination === 'object' ? row.pagination : {};
  return Number(row.totalCount || row.total_count || row.count || pagination.totalCount || pagination.total_count || pagination.total || 0) || 0;
}

function normalizeFollowing(value) {
  const row = value || {};
  return {
    key: String(row.key || ''),
    urlname: String(row.urlname || '').replace(/[^a-zA-Z0-9_-]/g, '').slice(0, 80),
    nickname: String(row.nickname || row.name || row.urlname || ''),
    userIcon: String(row.userProfileImagePath || row.profileImageUrl || row.user_profile_image_url || row.profile_image_url || ''),
    hasPublishedNote: row.hasPublishedNote !== false,
    withdrawal: Boolean(row.withdrawal)
  };
}

function pickRandomPages(totalPages, count, random = Math.random) {
  const max = Math.max(1, Number(totalPages) || 1);
  const wanted = Math.max(1, Math.min(Number(count) || 1, max));
  const pages = [];
  while (pages.length < wanted) {
    const page = 1 + Math.floor(random() * max);
    if (!pages.includes(page)) pages.push(page);
  }
  return pages;
}

function shuffleRows(rows, random = Math.random) {
  const copy = rows.slice();
  for (let index = copy.length - 1; index > 0; index -= 1) {
    const swap = Math.floor(random() * (index + 1));
    [copy[index], copy[swap]] = [copy[swap], copy[index]];
  }
  return copy;
}

async function followingPageV3(creatorKey, page) {
  return fetchNoteJson('/v3/users/' + encodeURIComponent(creatorKey) + '/followings?page=' + page + '&per=20', 6000);
}

async function followingPageV2(urlname, page) {
  return fetchNoteJson('/v2/creators/' + encodeURIComponent(urlname) + '/followings?page=' + page, 6000);
}

async function sampleFollowingPages(firstPayload, pageLoader, totalCount, eligibleLimit, sampleSize, pageSize = 20) {
  const eligibleCount = Math.max(0, Math.min(Number(totalCount) || 0, eligibleLimit));
  const totalPages = Math.max(1, Math.ceil(eligibleCount / pageSize));
  // Choose enough random positions to supply ten candidates per position.
  // Page 1 is never forced into a draw, so recently followed users have no
  // special advantage over older follows.
  const positionCount = Math.max(1, Math.min(Math.ceil(sampleSize / 10), totalPages));
  const pages = pickRandomPages(totalPages, positionCount);
  const payloads = await Promise.all(pages.map((page) => page === 1 ? firstPayload : pageLoader(page)));
  const pageGroups = payloads.map((payload) => {
    const rows = followingRows(payload)
      .map(normalizeFollowing)
      .filter((row) => row.urlname && row.hasPublishedNote && !row.withdrawal);
    return [...new Map(rows.map((row) => [row.urlname, row])).values()];
  });
  const preferred = [];
  const overflow = [];
  const perPosition = pages.length === 1 ? sampleSize : 10;
  pageGroups.forEach((group) => {
    const mixed = shuffleRows(group);
    preferred.push(...mixed.slice(0, perPosition));
    overflow.push(...mixed.slice(perPosition));
  });
  const uniquePreferred = [...new Map(preferred.map((row) => [row.urlname, row])).values()];
  const seen = new Set(uniquePreferred.map((row) => row.urlname));
  const topUp = shuffleRows(overflow).filter((row) => {
    if (seen.has(row.urlname)) return false;
    seen.add(row.urlname);
    return true;
  });
  const candidatePool = uniquePreferred.slice();
  if (candidatePool.length < sampleSize) candidatePool.push(...topUp.slice(0, sampleSize - candidatePool.length));
  const creators = shuffleRows(candidatePool).slice(0, sampleSize);
  return { creators, eligibleCount, sampledPages: pages, sampledPositions: pages.map((page) => (page - 1) * pageSize + 1) };
}

async function runFollowingsApi(sampleSizeValue) {
  const sampleSize = Math.max(10, Math.min(Number(sampleSizeValue) || 20, 50));
  try {
    const account = await getViewerAccount();
    if (!account || !account.urlname) return { ok: false, code: 'login_required', message: 'Firefoxでnoteへログインしてください。' };
    const actualCount = followingCountFrom(account);
    if (account.key) {
      try {
        const first = await followingPageV3(account.key, 1);
        const totalCount = followingTotalFrom(first) || actualCount || followingRows(first).length;
        const sampled = await sampleFollowingPages(first, (page) => followingPageV3(account.key, page), totalCount, 5000, sampleSize);
        return { ok: true, action: 'followings', ...sampled, totalCount, capped: totalCount > 5000, source: 'note_api_v3' };
      } catch (_) {
        // Fall back to the older public list. It exposes at most 600 people.
      }
    }
    const first = await followingPageV2(account.urlname, 1);
    const exposedCount = Math.min(followingTotalFrom(first) || actualCount || followingRows(first).length, 600);
    const sampled = await sampleFollowingPages(first, (page) => followingPageV2(account.urlname, page), exposedCount, 600, sampleSize, 12);
    return { ok: true, action: 'followings', ...sampled, totalCount: actualCount || exposedCount, capped: (actualCount || exposedCount) > 600, legacyLimit: true, source: 'note_api_v2' };
  } catch (error) {
    return {
      ok: false,
      code: error && error.name === 'AbortError' ? 'followings_timeout' : 'followings_api_failed',
      message: error && error.name === 'AbortError'
        ? 'フォロー一覧の取得が8秒でタイムアウトしました。'
        : 'フォロー一覧を取得できませんでした。Firefoxでnoteへログインしてから、もう一度お試しください。'
    };
  }
}

async function runStatusApi(articleUrl, force = false) {
  const cached = statusCache.get(articleUrl);
  if (!force && cached && cached.expiresAt > Date.now()) return { ...cached.result, cached: true };
  try {
    const payload = await fetchNoteJson('/v3/notes/' + encodeURIComponent(articleKey(articleUrl)), 5000);
    const note = payload && payload.data;
    if (!note) throw new Error('missing note');
    const user = note.user && typeof note.user === 'object' ? note.user : {};
    const result = {
      ok: true,
      action: 'status',
      liked: Boolean(note.is_liked),
      creator: {
        id: String(user.id || ''),
        urlname: String(user.urlname || ''),
        nickname: String(user.nickname || user.name || user.urlname || ''),
        isFollowing: Boolean(user.is_following),
        isFollower: typeof user.is_follower === 'boolean' ? user.is_follower : null,
        isMe: Boolean(user.is_me)
      },
      verified: true,
      source: 'note_api_v3'
    };
    statusCache.set(articleUrl, { result, expiresAt: Date.now() + STATUS_CACHE_MS });
    return result;
  } catch (_) {
    return { ok: false, code: 'status_api_failed', message: 'スキ状態を確認できませんでした。' };
  }
}

async function runStatusBatchApi(urlValues) {
  const urls = [...new Set((Array.isArray(urlValues) ? urlValues : [])
    .map((value) => String(value || '').split('#')[0])
    .filter(isAllowedArticleUrl))].slice(0, 30);
  if (!urls.length) return { ok: false, code: 'invalid_status_batch', message: '未スキ確認対象がありません。' };
  const results = new Array(urls.length);
  let cursor = 0;
  async function worker() {
    while (cursor < urls.length) {
      const index = cursor++;
      const result = await runStatusApi(urls[index]);
      results[index] = { url: urls[index], ok: Boolean(result && result.ok), liked: Boolean(result && result.liked) };
    }
  }
  await Promise.all(Array.from({ length: Math.min(6, urls.length) }, worker));
  return { ok: true, action: 'status_batch', results };
}

function searchContentRows(payload) {
  const data = payload && payload.data !== undefined ? payload.data : payload;
  const candidates = [
    data,
    data && data.contents,
    data && data.notes,
    data && data.notes && data.notes.contents,
    data && data.items,
    data && data.results
  ];
  return candidates.find(Array.isArray) || [];
}

function normalizeSearchContent(value) {
  const row = value && value.note && typeof value.note === 'object' ? value.note : (value || {});
  const user = row.user || row.author || row.actor || {};
  const key = String(row.key || row.noteKey || row.note_key || row.id || '');
  const urlname = String(user.urlname || row.urlname || '');
  const url = String(row.noteUrl || row.note_url || row.url || (key && urlname ? 'https://note.com/' + urlname + '/n/' + key : ''));
  return {
    key,
    name: String(row.name || row.title || '無題の記事'),
    description: String(row.description || row.bodyText || row.body_text || row.summary || '').slice(0, 3000),
    eyecatch: String(row.eyecatch || row.eyecatchUrl || row.eyecatch_url || row.image || ''),
    publishAt: String(row.publishAt || row.publish_at || row.createdAt || row.created_at || ''),
    url,
    urlname,
    nickname: String(user.nickname || user.name || urlname),
    userIcon: String(user.userProfileImagePath || user.profileImageUrl || user.user_profile_image_url || user.profile_image_url || ''),
    likeCount: Number(row.likeCount || row.like_count || 0),
    commentCount: Number(row.commentCount || row.comment_count || 0)
  };
}

async function fetchCreatorContentsPage(urlname, page = 1) {
  const safe = String(urlname || '').replace(/[^a-zA-Z0-9_-]/g, '').slice(0, 80);
  if (!safe) return [];
  const payload = await fetchNoteJson('/v2/creators/' + encodeURIComponent(safe) + '/contents?kind=note&page=' + Math.max(1, Number(page) || 1), 8000);
  return searchContentRows(payload)
    .map(normalizeSearchContent)
    .filter((item) => item.key && item.urlname && isAllowedArticleUrl(item.url));
}

async function runCreatorArticlesApi(urlnameValue) {
  const urlname = String(urlnameValue || '').replace(/[^a-zA-Z0-9_-]/g, '').slice(0, 80);
  if (!urlname) return { ok: false, code: 'invalid_creator', message: 'noteユーザーを確認できませんでした。' };
  try {
    const items = [];
    const seen = new Set();
    for (let page = 1; page <= 1000; page += 1) {
      const rows = await fetchCreatorContentsPage(urlname, page);
      let added = 0;
      rows.forEach((item) => {
        if (seen.has(item.url)) return;
        seen.add(item.url);
        items.push(item);
        added += 1;
      });
      if (!rows.length || added === 0) break;
    }
    return { ok: true, action: 'creator_articles', urlname, items, verified: true, source: 'note_api_v2' };
  } catch (_) {
    return { ok: false, code: 'creator_articles_failed', message: '@' + urlname + ' の記事一覧を取得できませんでした。' };
  }
}

async function runCreatorLatestBatchApi(urlnameValues) {
  const creators = [...new Set((Array.isArray(urlnameValues) ? urlnameValues : [])
    .map((value) => String(value || '').replace(/[^a-zA-Z0-9_-]/g, '').slice(0, 80))
    .filter(Boolean))].slice(0, 200);
  if (!creators.length) return { ok: true, action: 'creator_latest_batch', items: [], failed: [] };
  const items = [];
  const failed = [];
  let cursor = 0;
  async function worker() {
    while (cursor < creators.length) {
      const index = cursor++;
      const urlname = creators[index];
      try {
        const rows = await fetchCreatorContentsPage(urlname, 1);
        const latest = rows.slice().sort((left, right) => (Date.parse(right.publishAt || '') || 0) - (Date.parse(left.publishAt || '') || 0))[0];
        if (latest) items[index] = latest;
        else failed.push(urlname);
      } catch (_) {
        failed.push(urlname);
      }
    }
  }
  await Promise.all(Array.from({ length: Math.min(4, creators.length) }, worker));
  return {
    ok: true,
    action: 'creator_latest_batch',
    items: items.filter(Boolean),
    failed,
    verified: true,
    source: 'note_api_v2'
  };
}

async function runSearchApi(queryValue, pageValue) {
  const query = String(queryValue || '').replace(/^#+/, '').trim().slice(0, 80);
  const page = Math.max(1, Math.min(Number(pageValue) || 1, 30));
  if (!query) return { ok: false, code: 'invalid_search', message: '検索語を入力してください。' };
  try {
    const params = new URLSearchParams({
      context: 'note',
      mode: 'search',
      q: query,
      size: '20',
      start: String((page - 1) * 20),
      sort: 'new'
    });
    const payload = await fetchNoteJson('/v3/searches?' + params.toString(), 8000);
    const items = searchContentRows(payload).map(normalizeSearchContent).filter((item) => item.key && item.urlname && isAllowedArticleUrl(item.url));
    return { ok: true, action: 'search', items, page, verified: true, source: 'note_api_v3' };
  } catch (error) {
    return {
      ok: false,
      code: error && error.name === 'AbortError' ? 'search_timeout' : 'search_api_failed',
      message: error && error.name === 'AbortError'
        ? 'note検索が8秒でタイムアウトしました。'
        : 'noteの検索結果を取得できませんでした。Firefoxでnoteへログインしてから、もう一度お試しください。'
    };
  }
}

async function waitForContentScript(tabId, operation) {
  const deadline = Date.now() + 25000;
  let lastError = null;
  while (Date.now() < deadline) {
    try {
      const tab = await browser.tabs.get(tabId);
      if (tab.status === 'complete') {
        return await browser.tabs.sendMessage(tabId, {
          type: 'NERO_NOTE_ACTION',
          operation
        });
      }
    } catch (error) {
      lastError = error;
    }
    await delay(150);
  }
  throw lastError || new Error('noteの記事を開けませんでした');
}

async function activateTab(tabId) {
  try {
    await browser.tabs.update(tabId, { active: true });
    return true;
  } catch (_) {
    // If activation is unavailable, the caller still receives a useful error.
    return false;
  }
}

async function closeTab(tabId) {
  try {
    await browser.tabs.remove(tabId);
  } catch (_) {
    // The user may have closed the temporary tab first.
  }
}

function shouldRetryCommentInActiveTab() {
  // UI automation is deliberately never started automatically. Direct API
  // failures stay in Reader so the user's screen cannot move unexpectedly.
  return false;
}

async function runNoteOperation(message, readerTabId) {
  const action = message.action;
  const articleUrl = ['account', 'search', 'followings', 'status_batch', 'creator_articles', 'creator_latest_batch'].includes(action) ? 'https://note.com/' : String(message.articleUrl || '').split('#')[0];
  const comment = String(message.comment || '').trim();
  const replyTarget = normalizeReplyTarget(message.replyTarget);
  const magazineTarget = normalizeMagazineTarget(message);
  const expectedAccount = String(message && message.expectedAccount || '').replace(/[^a-zA-Z0-9_-]/g, '').slice(0, 80);
  const isMutation = action === 'like' || action === 'comment' || action === 'comment_like' || action === 'reply_with_like' || action === 'follow' || action === 'magazine_add';
  const isReadOnly = action === 'status' || action === 'status_batch' || action === 'comments' || action === 'engagement_article' || action === 'article_reactors' || action === 'creator_articles' || action === 'creator_latest_batch' || action === 'account' || action === 'search' || action === 'followings' || action === 'magazines';

  if (!['account', 'status', 'status_batch', 'comments', 'engagement_article', 'article_reactors', 'creator_articles', 'creator_latest_batch', 'search', 'followings', 'magazines', 'magazine_add', 'like', 'comment', 'comment_like', 'reply_with_like', 'follow'].includes(action) || (!['account', 'search', 'followings', 'status_batch', 'creator_articles', 'creator_latest_batch'].includes(action) && !isAllowedArticleUrl(articleUrl))) {
    return { ok: false, code: 'invalid_request', message: '記事情報を確認できませんでした。' };
  }
  if ((action === 'comment' || action === 'reply_with_like') && (!comment || comment.length > 500)) {
    return { ok: false, code: 'invalid_comment', message: 'コメントは1〜500文字で入力してください。' };
  }
  if ((action === 'comment_like' || action === 'reply_with_like') && !replyTarget) {
    return { ok: false, code: 'invalid_comment_target', message: '対象のコメントを確認できませんでした。' };
  }
  if (action === 'magazine_add' && !magazineTarget) {
    return { ok: false, code: 'invalid_magazine_target', message: '追加先のマガジンを確認できませんでした。' };
  }

  // Read-only data comes from note's current JSON API. This avoids opening
  // hidden tabs, which is slow and unreliable on Firefox for Android.
  if (action === 'account') return runAccountApi();
  if (action === 'search') return runSearchApi(message.query, message.page);
  if (action === 'followings') return runFollowingsApi(message.sampleSize);
  if (action === 'status_batch') return runStatusBatchApi(message.urls);
  if (action === 'creator_articles') return runCreatorArticlesApi(message.urlname);
  if (action === 'creator_latest_batch') return runCreatorLatestBatchApi(message.creators);
  if (action === 'status') return runStatusApi(articleUrl);
  if (action === 'comments') return runCommentsApi(articleUrl, message.summaryOnly === true);
  if (action === 'article_reactors') return runArticleReactorsApi(articleUrl);
  if (action === 'engagement_article') return runEngagementArticleApi(articleUrl, {
    includeLikes: message.includeLikes !== false,
    includeComments: message.includeComments !== false,
    cutoffMs: Number(message.cutoffMs) || 0
  });

  if (isMutation && activeOperation) {
    return { ok: false, code: 'busy', message: '前の操作を処理しています。少し待ってからもう一度お試しください。' };
  }

  const targetKey = (action === 'comment_like' || action === 'reply_with_like') && replyTarget
    ? ':' + replyTarget.authorUrlname + ':' + replyTarget.publishedAt + ':' + replyTarget.body.slice(0, 80)
    : (action === 'magazine_add' && magazineTarget ? ':' + (magazineTarget.key || magazineTarget.name || magazineTarget.index) : '');
  const throttleKey = isMutation ? action + ':' + articleKey(articleUrl) + targetKey : '';
  if (isMutation) {
    const lastRun = recentOperations.get(throttleKey) || 0;
    if (Date.now() - lastRun < 8000) {
      return { ok: false, code: 'throttled', message: '同じ操作の連続送信を止めました。8秒後にお試しください。' };
    }
  }

  const operation = {
    id: crypto.randomUUID ? crypto.randomUUID() : String(Date.now()) + Math.random(),
    action,
    articleUrl,
    articleKey: articleKey(articleUrl),
    comment: action === 'comment' || action === 'reply_with_like' ? comment : '',
    replyTarget: action === 'comment' || action === 'comment_like' || action === 'reply_with_like' ? replyTarget : null,
    magazineTarget: action === 'magazine_add' ? magazineTarget : null,
    expectedAccount: action === 'magazine_add' ? expectedAccount : '',
    // Mutations use note's own authenticated request inside an inactive tab.
    // The tab is never activated automatically, even if the request fails.
    commentMode: action === 'comment' ? 'direct_only' : ''
  };
  if (isMutation) {
    activeOperation = operation.id;
    recentOperations.set(throttleKey, Date.now());
  }

  let tab = null;
  try {
    // Mutations with stable note endpoints run in the background process.
    // No page tab or DOM automation is involved, including paid article likes.
    if (action === 'like') {
      const result = await runDirectArticleLikeMutation(articleUrl);
      return result && result.ok ? result : { ...result, openedNote: false };
    }
    if (action === 'magazine_add') {
      const result = await runDirectMagazineAddMutation(articleUrl, magazineTarget, expectedAccount);
      return result && result.ok ? result : { ...result, openedNote: false };
    }
    if (action === 'comment') {
      const commentResult = await runDirectCommentMutation(articleUrl, comment, replyTarget);
      if (!commentResult || !commentResult.ok) return { ...commentResult, openedNote: false };
      return { ...commentResult, commentSent: true };
    }
    if (action === 'reply_with_like') {
      const reply = await runDirectCommentMutation(articleUrl, comment, replyTarget);
      if (!reply || !reply.ok) return { ...reply, openedNote: false };
      const like = await runDirectCommentLikeMutation(articleUrl, replyTarget);
      if (!like || !like.ok) {
        return {
          ok: false,
          partial: true,
          replySent: true,
          code: 'reply_sent_like_failed',
          message: '返信は送信済みですが、コメントへのスキを確認できませんでした。未対応一覧の「スキで対応」を押してください。',
          likeResult: like || null,
          openedNote: false
        };
      }
      return { ok: true, action: 'reply_with_like', replySent: true, liked: true, verified: true, replyResult: reply, likeResult: like };
    }
    if (action === 'comment_like') {
      const result = await runDirectCommentLikeMutation(articleUrl, replyTarget);
      return result && result.ok ? result : { ...result, openedNote: false };
    }

    tab = await browser.tabs.create({ url: articleUrl, active: false });
    const result = await waitForContentScript(tab.id, operation);
    if (result && result.ok) {
      await closeTab(tab.id);
      return result;
    }

    await closeTab(tab.id);
    return {
      ok: false,
      openedNote: false,
      code: result && result.code ? result.code : (isReadOnly ? 'read_unavailable' : 'note_action_failed'),
      message: result && result.message ? result.message : (isReadOnly ? 'noteの情報を確認できませんでした。' : 'noteへの操作を完了できませんでした。Reader画面はそのままです。')
    };
  } catch (error) {
    if (tab && tab.id) await closeTab(tab.id);
    return {
      ok: false,
      openedNote: false,
      code: isReadOnly ? 'read_unavailable' : 'bridge_failed',
      message: isReadOnly ? 'noteの情報を確認できませんでした。' : 'noteとの通信に失敗しました。Reader画面はそのままです。'
    };
  } finally {
    if (isMutation) activeOperation = null;
  }
}

browser.runtime.onMessage.addListener((message, sender) => {
  if (!message || typeof message !== 'object') return undefined;

  if (message.type === 'NERO_OPEN_READER') {
    return browser.tabs.create({ url: READER_URL, active: true }).then(() => ({ ok: true }));
  }

  if (message.type === 'NERO_OPEN_NERO_READER') {
    return browser.tabs.create({ url: READER_URL + 'nero-favorites', active: true }).then(() => ({ ok: true }));
  }

  if (message.type === 'NERO_OPEN_NOTE_LOGIN') {
    return browser.tabs.create({ url: 'https://note.com/login', active: true }).then(() => ({ ok: true }));
  }

  if (message.type === 'NERO_READER_ACTION') {
    let senderOrigin = '';
    try { senderOrigin = new URL(sender.url || '').origin; } catch (_) {}
    if (senderOrigin !== READER_ORIGIN) {
      return Promise.resolve({ ok: false, code: 'unauthorized', message: 'Reader以外からの操作を拒否しました。' });
    }
    return runNoteOperation(message, sender && sender.tab ? sender.tab.id : null);
  }

  return undefined;
});

function readerSenderOrigin(sender) {
  try { return new URL(sender && sender.url || '').origin; } catch (_) { return ''; }
}

function handleMutationPort(port) {
  if (!port || port.name !== 'NERO_MUTATION_V1') return;
  if (readerSenderOrigin(port.sender) !== READER_ORIGIN) {
    try { port.disconnect(); } catch (_) {}
    return;
  }
  let handled = false;
  port.onMessage.addListener((message) => {
    if (handled || !message || message.type !== 'NERO_READER_ACTION') return;
    handled = true;
    const requestId = String(message.requestId || '');
    runNoteOperation(message, port.sender && port.sender.tab ? port.sender.tab.id : null)
      .then((result) => {
        try { port.postMessage({ requestId, result }); } catch (_) {}
      })
      .catch(() => {
        try {
          port.postMessage({
            requestId,
            result: { ok: false, code: 'bridge_failed', message: 'noteとの操作通信を完了できませんでした。' }
          });
        } catch (_) {}
      });
  });
}

// A Port keeps Firefox for Android's event page alive only while a user action
// is running. This prevents long comment operations from losing their reply
// without keeping the extension resident all day.
if (browser.runtime.onConnect && browser.runtime.onConnect.addListener) {
  browser.runtime.onConnect.addListener(handleMutationPort);
}

globalThis.NeroBackgroundTest = {
  isAllowedArticleUrl,
  articleKey,
  normalizeReplyTarget,
  normalizeMagazineTarget,
  commentAstText,
  normalizeApiComment,
  fetchNoteComments,
  likeRows,
  normalizeEngagementUser,
  normalizeApiLike,
  fetchNoteLikes,
  runEngagementArticleApi,
  runArticleReactorsApi,
  fetchCreatorContentsPage,
  runCreatorArticlesApi,
  runCreatorLatestBatchApi,
  searchContentRows,
  normalizeSearchContent,
  accountFromPayload,
  followingCountFrom,
  followingRows,
  followingTotalFrom,
  normalizeFollowing,
  pickRandomPages,
  sampleFollowingPages,
  runStatusBatchApi,
  fetchNoteMutation,
  noteMutationErrorMessage,
  isMagazineAlreadyError,
  isMagazineItemRejection,
  responseRetryAfterMs,
  noteCommentAst,
  runDirectCommentMutation,
  runDirectCommentLikeMutation,
  runDirectArticleLikeMutation,
  runDirectMagazineAddMutation,
  magazineRows,
  normalizeApiMagazine,
  noteNumericId,
  shouldRetryCommentInActiveTab,
  readerSenderOrigin,
  handleMutationPort,
  runNoteOperation
};
