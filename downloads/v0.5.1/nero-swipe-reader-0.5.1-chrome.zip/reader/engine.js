(function(browser, fetch) {
"use strict";

// Source: background.js
'use strict';

const READER_URL = browser.runtime.getURL('reader/index.html');
const READER_ORIGIN = new URL(READER_URL).origin;
const NOTE_ARTICLE = /^https:\/\/(?:www\.)?note\.com\/[a-zA-Z0-9_-]+\/n\/[a-zA-Z0-9_-]+(?:[/?#].*)?$/;
const NOTE_API = 'https://note.com/api';
const recentOperations = new Map();
const statusCache = new Map();
const STATUS_CACHE_MS = 2 * 60 * 1000;
const ACCOUNT_CACHE_MS = 10 * 60 * 1000;
let viewerAccountCache = null;
let activeOperation = null;

function isAllowedArticleUrl(value) {
  try {
    const url = new URL(String(value || ''));
    return NOTE_ARTICLE.test(url.href) && url.protocol === 'https:';
  } catch (_) {
    return false;
  }
}

function articleKey(value) {
  const match = String(value || '').match(/\/n\/([a-zA-Z0-9_-]+)/);
  return match ? match[1] : '';
}

function normalizeReplyTarget(value) {
  if (!value || typeof value !== 'object') return null;
  const key = String(value.key || '').replace(/[^a-zA-Z0-9_-]/g, '').slice(0, 160);
  const commentKey = String(value.commentKey || '').replace(/[^a-zA-Z0-9_-]/g, '').slice(0, 160);
  const rootKey = String(value.rootKey || key).replace(/[^a-zA-Z0-9_-]/g, '').slice(0, 160);
  const authorUrlname = String(value.authorUrlname || '').replace(/[^a-zA-Z0-9_-]/g, '').slice(0, 80);
  const authorName = String(value.authorName || '').replace(/\s+/g, ' ').trim().slice(0, 160);
  const body = String(value.body || '').replace(/\s+/g, ' ').trim().slice(0, 1000);
  const publishedAt = String(value.publishedAt || '').trim().slice(0, 80);
  const depth = Number(value.depth) ? 1 : 0;
  const rootAuthorUrlname = String(value.rootAuthorUrlname || '').replace(/[^a-zA-Z0-9_-]/g, '').slice(0, 80);
  const rootBody = String(value.rootBody || '').replace(/\s+/g, ' ').trim().slice(0, 1000);
  if (!authorUrlname || !body) return null;
  return { key, commentKey, rootKey, authorUrlname, authorName, body, publishedAt, depth, rootAuthorUrlname, rootBody, liked: value.liked === true };
}

function normalizeMagazineTarget(message) {
  const key = String(message && message.magazineKey || '').replace(/[^a-zA-Z0-9_-]/g, '').slice(0, 160);
  const name = String(message && message.magazineName || '').replace(/\s+/g, ' ').trim().slice(0, 160);
  const hasIndex = Boolean(message && Object.prototype.hasOwnProperty.call(message, 'magazineIndex'));
  const index = Math.max(0, Math.min(Number(message && message.magazineIndex) || 0, 2000));
  if (!key && !name && !hasIndex) return null;
  return { key, name, index };
}

function delay(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

async function fetchNoteJson(path, timeoutMs = 8000) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const response = await fetch(NOTE_API + path, {
      method: 'GET',
      credentials: 'include',
      cache: 'no-store',
      headers: { Accept: 'application/json' },
      signal: controller.signal
    });
    if (!response.ok) {
      const error = new Error('note API returned ' + response.status);
      error.status = response.status;
      throw error;
    }
    return await response.json();
  } finally {
    clearTimeout(timer);
  }
}

function noteMutationErrorMessage(payload, fallback) {
  const values = [
    payload && payload.message,
    payload && payload.error,
    payload && payload.errors,
    payload && payload.data && payload.data.message,
    payload && payload.data && payload.data.error,
    payload && payload.data && payload.data.errors
  ];
  const pending = [...values];
  while (pending.length) {
    const value = pending.shift();
    if (typeof value === 'string' && value.trim()) return value.trim();
    if (Array.isArray(value)) {
      pending.unshift(...value);
      continue;
    }
    if (value && typeof value === 'object') {
      for (const key of ['message', 'detail', 'reason', 'title', 'code']) {
        if (typeof value[key] === 'string' && value[key].trim()) return value[key].trim();
      }
    }
  }
  return fallback;
}

function isMagazineAlreadyError(status, message) {
  const text = String(message || '');
  return Number(status) === 409 || /already|duplicate|追加済|登録済|含まれて|(?:すでに|既に).*(?:追加|登録|入って)/i.test(text);
}

function isMagazineItemRejection(status, message) {
  const code = Number(status);
  return Boolean(String(message || '').trim()) && [400, 404, 410, 422].includes(code);
}

function responseRetryAfterMs(response, now = Date.now()) {
  if (!response || !response.headers || typeof response.headers.get !== 'function') return 0;
  const retryAfter = String(response.headers.get('Retry-After') || '').trim();
  if (/^\d+(?:\.\d+)?$/.test(retryAfter)) return Math.max(0, Math.round(Number(retryAfter) * 1000));
  const retryDate = Date.parse(retryAfter);
  if (Number.isFinite(retryDate)) return Math.max(0, retryDate - now);
  const reset = Number(response.headers.get('X-RateLimit-Reset') || response.headers.get('RateLimit-Reset') || 0);
  if (!Number.isFinite(reset) || reset <= 0) return 0;
  const resetAt = reset > 1000000000000 ? reset : reset * 1000;
  return Math.max(0, resetAt - now);
}

async function fetchNoteMutation(path, options = {}) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), Number(options.timeoutMs) || 10000);
  const headers = {
    Accept: 'application/json',
    'X-Requested-With': 'XMLHttpRequest',
    // The extension background has no page localStorage. This is the same
    // explicit fallback note uses when note-client-code storage is disabled.
    'X-LS-Disabled': 'true'
  };
  let body;
  if (options.body !== undefined) {
    headers['Content-Type'] = 'application/json';
    body = JSON.stringify(options.body);
  }
  try {
    const response = await fetch(NOTE_API + path, {
      method: options.method || 'POST',
      credentials: 'include',
      cache: 'no-store',
      headers,
      body,
      signal: controller.signal
    });
    let payload = null;
    try { payload = await response.json(); } catch (_) {}
    return { response, payload };
  } finally {
    clearTimeout(timer);
  }
}

function noteCommentAst(value) {
  return {
    type: 'root',
    children: [{
      type: 'element',
      // note's API client converts the frontend's camelCase AST to
      // snake_case before it sends the request. Direct requests must use the
      // wire-format key already.
      tag_name: 'p',
      children: [{ type: 'text', value: String(value || '').replace(/\r\n?/g, '\n') }]
    }]
  };
}

async function runDirectCommentMutation(articleUrl, comment, replyTarget) {
  const noteKey = articleKey(articleUrl);
  const body = {
    comment: noteCommentAst(comment),
    acknowledgement: false,
    caller_name: 'createNoteCommentV3'
  };
  if (replyTarget && replyTarget.key) body.parent_key = replyTarget.key;
  try {
    const { response, payload } = await fetchNoteMutation('/v3/notes/' + encodeURIComponent(noteKey) + '/note_comments', { body });
    if (response.ok && !(payload && payload.error)) {
      const data = payload && payload.data !== undefined ? payload.data : payload;
      const created = data && data.comment ? data.comment : data;
      return { ok: true, action: 'comment', verified: true, source: 'note_api_v3_extension', commentKey: String(created && created.key || '') };
    }
    if (response.status === 401 || response.status === 403) {
      return { ok: false, code: 'login_required', message: 'Firefoxでnoteへログインしてください。', status: response.status };
    }
    const error = payload && (payload.error || payload.data && payload.data.error);
    if (error && error.type === 'comment_acknowledgement') {
      return { ok: false, code: 'comment_acknowledgement', message: 'このコメントはnote側で確認操作が必要です。', status: response.status };
    }
    return {
      ok: false,
      code: 'comment_api_rejected',
      message: noteMutationErrorMessage(payload, 'noteがコメントを受け付けませんでした。'),
      status: response.status
    };
  } catch (error) {
    if (error && error.name === 'AbortError') {
      return { ok: false, code: 'comment_result_unknown', message: '10秒以内に送信結果を確認できませんでした。二重投稿を防ぐため自動再送はしていません。' };
    }
    const detail = [error && error.name, error && error.message].filter(Boolean).join(': ').slice(0, 180);
    return { ok: false, code: 'comment_api_unavailable', message: 'noteとの通信に失敗しました。' + (detail ? ' ' + detail : ''), detail };
  }
}

async function runDirectCommentLikeMutation(articleUrl, replyTarget) {
  const noteKey = articleKey(articleUrl);
  const commentKey = String(replyTarget && replyTarget.commentKey || '');
  if (!commentKey) return { ok: false, code: 'comment_target_missing', message: '対象コメントの識別情報を確認できませんでした。' };
  if (replyTarget && replyTarget.liked === true) {
    return { ok: true, action: 'comment_like', already: true, verified: true, source: 'note_api_v3_extension' };
  }
  try {
    const { response, payload } = await fetchNoteMutation(
      '/v3/notes/' + encodeURIComponent(noteKey) + '/note_comments/' + encodeURIComponent(commentKey) + '/likes'
    );
    if (response.ok && !(payload && payload.error)) {
      return { ok: true, action: 'comment_like', already: false, verified: true, source: 'note_api_v3_extension' };
    }
    if (response.status === 401 || response.status === 403) {
      return { ok: false, code: 'login_required', message: 'Firefoxでnoteへログインしてください。', status: response.status };
    }
    if (response.status === 404) {
      return { ok: false, code: 'comment_target_missing', message: '対象のコメントが見つかりませんでした。', status: response.status };
    }
    return {
      ok: false,
      code: 'comment_like_api_rejected',
      message: noteMutationErrorMessage(payload, 'noteがコメントへのスキを受け付けませんでした。'),
      status: response.status
    };
  } catch (error) {
    if (error && error.name === 'AbortError') {
      return { ok: false, code: 'comment_like_result_unknown', message: '10秒以内に結果を確認できませんでした。自動再送はしていません。' };
    }
    const detail = [error && error.name, error && error.message].filter(Boolean).join(': ').slice(0, 180);
    return { ok: false, code: 'comment_like_api_unavailable', message: 'noteとの通信に失敗しました。' + (detail ? ' ' + detail : ''), detail };
  }
}

async function runDirectArticleLikeMutation(articleUrl) {
  const noteKey = articleKey(articleUrl);
  const before = await runStatusApi(articleUrl, true);
  if (before && before.ok && before.liked === true) {
    return { ok: true, action: 'like', already: true, verified: true, source: 'note_api_v3_extension' };
  }
  try {
    const { response, payload } = await fetchNoteMutation('/v3/notes/' + encodeURIComponent(noteKey) + '/likes');
    if (response.status === 401 || response.status === 403) {
      return { ok: false, code: 'login_required', message: 'Firefoxでnoteへログインしてください。', status: response.status };
    }
    if (!response.ok && response.status !== 409) {
      return {
        ok: false,
        code: 'like_api_rejected',
        message: noteMutationErrorMessage(payload, 'noteがこの記事へのスキを受け付けませんでした。'),
        status: response.status
      };
    }
    for (let attempt = 0; attempt < 4; attempt += 1) {
      if (attempt) await delay(250 * attempt);
      const verified = await runStatusApi(articleUrl, true);
      if (verified && verified.ok && verified.liked === true) {
        return { ok: true, action: 'like', already: response.status === 409, verified: true, source: 'note_api_v3_extension' };
      }
    }
    return { ok: false, code: 'like_result_unknown', message: 'note側でスキ済みになったことを確認できませんでした。成功扱いにはしていません。' };
  } catch (error) {
    if (error && error.name === 'AbortError') {
      return { ok: false, code: 'like_result_unknown', message: '10秒以内にスキ結果を確認できませんでした。自動再送はしていません。' };
    }
    return { ok: false, code: 'like_api_unavailable', message: 'noteとの通信に失敗しました。Reader画面はそのままです。' };
  }
}

function commentAstText(node) {
  if (!node || typeof node !== 'object') return '';
  if (node.type === 'text') return String(node.value || '');
  const children = Array.isArray(node.children) ? node.children : [];
  const parts = children.map(commentAstText).filter(Boolean);
  if (node.type === 'root') return parts.join('\n\n').trim();
  return parts.join('').trim();
}

function normalizeApiComment(value, threadIndex, depth, rootKey, rootMeta) {
  const user = value && value.user && typeof value.user === 'object' ? value.user : {};
  return {
    key: String(value && value.key || ''),
    rootKey: String(rootKey || value && value.key || ''),
    authorUrlname: String(user.urlname || ''),
    authorName: String(user.nickname || user.name || user.urlname || ''),
    body: commentAstText(value && value.comment),
    publishedAt: String(value && value.created_at || ''),
    avatar: String(user.profile_image_url || ''),
    depth: depth ? 1 : 0,
    threadIndex,
    liked: Boolean(value && value.is_liked),
    viewerLiked: Boolean(value && value.is_liked),
    creatorLiked: Boolean(value && value.is_creator_liked),
    isFollowing: typeof user.is_following === 'boolean' ? user.is_following : null,
    isFollower: typeof user.is_follower === 'boolean' ? user.is_follower : null,
    rootAuthorUrlname: String(rootMeta && rootMeta.authorUrlname || user.urlname || ''),
    rootBody: String(rootMeta && rootMeta.body || commentAstText(value && value.comment))
  };
}

function likeRows(payload) {
  const data = payload && payload.data !== undefined ? payload.data : payload;
  if (Array.isArray(data)) return data;
  if (data && Array.isArray(data.likes)) return data.likes;
  if (data && data.likes && Array.isArray(data.likes.contents)) return data.likes.contents;
  if (data && Array.isArray(data.users)) return data.users;
  if (data && Array.isArray(data.contents)) return data.contents;
  return [];
}

function normalizeEngagementUser(value) {
  const row = value && value.user && typeof value.user === 'object' ? value.user : (value || {});
  const urlname = String(row.urlname || '').replace(/[^a-zA-Z0-9_-]/g, '').slice(0, 80);
  return {
    key: String(row.key || row.id || ''),
    urlname,
    nickname: String(row.nickname || row.name || urlname),
    userIcon: String(row.user_profile_image_url || row.userProfileImagePath || row.profileImageUrl || row.profile_image_url || ''),
    isFollowing: typeof row.is_following === 'boolean' ? row.is_following : null,
    isFollower: typeof row.is_follower === 'boolean' ? row.is_follower : null
  };
}

function normalizeApiLike(value) {
  const user = normalizeEngagementUser(value);
  return {
    ...user,
    createdAt: String(value && (value.created_at || value.createdAt || value.liked_at || value.likedAt) || '')
  };
}

async function fetchNoteLikes(noteKey, cutoffMs) {
  const likes = [];
  let start = 0;
  let previousMarker = '';
  let apiVersion = 'v3';
  for (let round = 0; round < 20; round += 1) {
    const params = new URLSearchParams({ size: '100', start: String(start) });
    let payload;
    try {
      payload = await fetchNoteJson('/' + apiVersion + '/notes/' + encodeURIComponent(noteKey) + '/likes?' + params.toString(), 10000);
    } catch (error) {
      if (round > 0) throw error;
      apiVersion = 'v2';
      payload = await fetchNoteJson('/v2/notes/' + encodeURIComponent(noteKey) + '/likes?' + params.toString(), 10000);
    }
    let rows = likeRows(payload);
    if (!rows.length) break;
    let normalized = rows.map(normalizeApiLike).filter((row) => row.urlname && row.createdAt);
    if (round === 0 && apiVersion === 'v3' && rows.length && !normalized.length) {
      apiVersion = 'v2';
      payload = await fetchNoteJson('/v2/notes/' + encodeURIComponent(noteKey) + '/likes?' + params.toString(), 10000);
      rows = likeRows(payload);
      normalized = rows.map(normalizeApiLike).filter((row) => row.urlname && row.createdAt);
    }
    const first = rows[0] || {};
    const firstUser = first.user && typeof first.user === 'object' ? first.user : first;
    const marker = String(first.created_at || first.createdAt || first.liked_at || first.likedAt || '') + ':' + String(firstUser.key || firstUser.id || firstUser.urlname || '');
    if (marker && marker === previousMarker) break;
    previousMarker = marker;
    likes.push(...normalized);
    const oldest = normalized.reduce((value, row) => Math.min(value, Date.parse(row.createdAt) || Infinity), Infinity);
    if (Number.isFinite(oldest) && oldest < cutoffMs) break;
    if (rows.length < 100) break;
    start += rows.length;
  }
  return likes;
}

async function runEngagementArticleApi(articleUrl, options = {}) {
  const includeLikes = options.includeLikes !== false;
  const includeComments = options.includeComments !== false;
  const cutoffMs = Math.max(0, Number(options.cutoffMs) || Date.now() - 7 * 24 * 60 * 60 * 1000);
  const result = {
    ok: true,
    action: 'engagement_article',
    articleUrl,
    likes: [],
    comments: [],
    likesOk: !includeLikes,
    commentsOk: !includeComments,
    verified: true,
    source: 'note_api_v3'
  };
  if (includeLikes) {
    try {
      result.likes = await fetchNoteLikes(articleKey(articleUrl), cutoffMs);
      result.likesOk = true;
    } catch (_) {
      result.likesOk = false;
    }
  }
  if (includeComments) {
    try {
      result.comments = await fetchNoteComments(articleKey(articleUrl), true);
      result.commentsOk = true;
    } catch (_) {
      result.commentsOk = false;
    }
  }
  result.ok = result.likesOk && result.commentsOk;
  if (!result.ok) {
    result.code = 'engagement_article_partial';
    result.message = 'この記事のスキまたはコメントをすべて確認できませんでした。';
  }
  return result;
}

async function runArticleReactorsApi(articleUrl) {
  try {
    const [likes, comments, account] = await Promise.all([
      fetchNoteLikes(articleKey(articleUrl), 0),
      fetchNoteComments(articleKey(articleUrl), false),
      getViewerAccount(true)
    ]);
    const owner = String(account && account.urlname || '');
    if (!owner) return { ok: false, code: 'login_required', message: 'Firefoxでnoteへログインしてください。' };
    const creators = new Map();
    function ensure(urlname, row) {
      const key = String(urlname || '').toLowerCase();
      if (!key || key === owner.toLowerCase()) return null;
      let creator = creators.get(key);
      if (!creator) {
        creator = {
          urlname: String(urlname),
          nickname: String(row && (row.nickname || row.authorName || row.name) || urlname),
          userIcon: String(row && (row.userIcon || row.avatar) || ''),
          liked: false,
          commented: false,
          likeCount: 0,
          commentCount: 0,
          lastActionAt: ''
        };
        creators.set(key, creator);
      }
      return creator;
    }
    function rememberTime(creator, value) {
      const next = Date.parse(String(value || '')) || 0;
      const current = Date.parse(String(creator.lastActionAt || '')) || 0;
      if (next > current) creator.lastActionAt = new Date(next).toISOString();
    }
    likes.forEach((row) => {
      const creator = ensure(row.urlname, row);
      if (!creator) return;
      creator.liked = true;
      creator.likeCount += 1;
      rememberTime(creator, row.createdAt);
    });
    comments.forEach((row) => {
      const creator = ensure(row.authorUrlname, row);
      if (!creator) return;
      creator.commented = true;
      creator.commentCount += 1;
      rememberTime(creator, row.publishedAt);
    });
    const ordered = Array.from(creators.values()).sort((left, right) => {
      if (left.commented !== right.commented) return left.commented ? -1 : 1;
      const time = Date.parse(right.lastActionAt || '') - Date.parse(left.lastActionAt || '');
      if (time) return time;
      return left.urlname.localeCompare(right.urlname);
    });
    return {
      ok: true,
      action: 'article_reactors',
      articleUrl,
      owner,
      creators: ordered,
      stats: {
        creatorCount: ordered.length,
        likeCount: likes.length,
        commentCount: comments.filter((row) => String(row.authorUrlname || '').toLowerCase() !== owner.toLowerCase()).length,
        commenterCount: ordered.filter((row) => row.commented).length
      },
      verified: true,
      source: 'note_api_v2_v3'
    };
  } catch (error) {
    return {
      ok: false,
      code: error && error.name === 'AbortError' ? 'article_reactors_timeout' : 'article_reactors_failed',
      message: 'この記事のスキ・コメント反応者を取得できませんでした。少し待ってからもう一度お試しください。'
    };
  }
}

async function fetchCommentCollection(noteKey, parentKey) {
  const rows=[],seen=new Set();let page=1;
  for(let round=0;round<10000;round++) {
    if(seen.has(page))throw new Error('Repeated comment page');
    seen.add(page);
    const params=new URLSearchParams({page:String(page),per_page:'100',order:parentKey?'oldest':'newest'});
    if(parentKey)params.set('parent_key',parentKey);
    const payload=await fetchNoteJson('/v3/notes/'+encodeURIComponent(noteKey)+'/note_comments?'+params.toString());
    if(!Array.isArray(payload?.data))throw new Error('Unexpected comment response');
    rows.push(...payload.data);
    const next=Number(payload.next_page);
    if(!next)return rows;
    page=next;
  }
  throw new Error('Comment pagination limit reached; not a complete scan');
}

async function fetchNoteComments(noteKey, summaryOnly) {
  const roots = await fetchCommentCollection(noteKey, '');
  // The root response only exposes a creator-reply summary. It does not prove
  // that the creator was the last person in the thread: a reader may have
  // replied again afterwards. Fetch every non-empty reply thread so the inbox
  // can determine the real last creator response without false positives.
  const replyGroups = new Array(roots.length).fill(null).map(() => []);
  let cursor = 0;
  async function worker() {
    while (cursor < roots.length) {
      const index = cursor;
      cursor += 1;
      const root = roots[index];
      const replyCount = Number(root && root.reply_count || 0);
      if (!replyCount) continue;
      const embedded = Array.isArray(root.replies) ? root.replies : [];
      if (embedded.length >= replyCount) {
        replyGroups[index] = embedded;
        continue;
      }
      replyGroups[index] = await fetchCommentCollection(noteKey, String(root.key || ''));
    }
  }
  await Promise.all(Array.from({ length: Math.min(3, roots.length) }, worker));
  const comments = [];
  roots.forEach((root, index) => {
    const rootComment = normalizeApiComment(root, index, 0, root.key);
    comments.push(rootComment);
    const rootMeta = { authorUrlname: rootComment.authorUrlname, body: rootComment.body };
    replyGroups[index].forEach((reply) => comments.push(normalizeApiComment(reply, index, 1, root.key, rootMeta)));
  });
  return comments.filter((comment) => comment.authorUrlname && comment.body);
}

async function runCommentsApi(articleUrl, summaryOnly) {
  try {
    const [comments, account] = await Promise.all([
      fetchNoteComments(articleKey(articleUrl), summaryOnly),
      getViewerAccount().catch(() => null)
    ]);
    const viewer = String(account && account.urlname || '');
    return {
      ok: true,
      action: 'comments',
      comments: comments.map((comment) => ({ ...comment, liked: comment.viewerLiked, viewerLikeKnown: true })),
      viewerUrlname: viewer,
      verified: true,
      source: 'note_api_v3'
    };
  } catch (error) {
    return {
      ok: false,
      code: error && error.name === 'AbortError' ? 'comments_timeout' : 'comments_api_failed',
      message: error && error.name === 'AbortError'
        ? 'noteのコメント取得が8秒でタイムアウトしました。'
        : 'noteのコメント取得に失敗しました。少し待ってからもう一度お試しください。'
    };
  }
}

function accountFromPayload(payload) {
  const data = payload && payload.data !== undefined ? payload.data : payload;
  return data && data.user ? data.user : data;
}

async function getViewerAccount(forceRefresh = false) {
  /* Always resolve the current member account. */
  const payload = await fetchNoteJson('/v2/current_user', 12000);
  const account = accountFromPayload(payload);
  if (!account || !account.urlname) return null;
  if (account.key) {
    viewerAccountCache = { value: account, expiresAt: Date.now() + ACCOUNT_CACHE_MS };
    return account;
  }
  try {
    const profile = accountFromPayload(await fetchNoteJson('/v2/creators/' + encodeURIComponent(account.urlname), 4000));
    const resolved = { ...account, key: profile && profile.key || '', followingCount: followingCountFrom(account) || followingCountFrom(profile) };
    viewerAccountCache = { value: resolved, expiresAt: Date.now() + ACCOUNT_CACHE_MS };
    return resolved;
  } catch (_) {
    viewerAccountCache = { value: account, expiresAt: Date.now() + ACCOUNT_CACHE_MS };
    return account;
  }
}

function followingCountFrom(value) {
  const row = value && typeof value === 'object' ? value : {};
  return Number(row.followingCount || row.following_count || row.followingsCount || row.followings_count || 0) || 0;
}

function magazineRows(payload) {
  const data = payload && payload.data !== undefined ? payload.data : payload;
  if (Array.isArray(data)) return data;
  if (!data || typeof data !== 'object') return [];
  for (const key of ['magazines', 'contents', 'items']) {
    if (Array.isArray(data[key])) return data[key];
    if (data[key] && typeof data[key] === 'object') {
      for (const nested of ['magazines', 'contents', 'items']) {
        if (Array.isArray(data[key][nested])) return data[key][nested];
      }
    }
  }
  return [];
}

function normalizeApiMagazine(value, index = 0) {
  const row = value && typeof value === 'object' ? value : {};
  const key = String(row.key || row.magazine_key || row.magazineKey || '').replace(/[^a-zA-Z0-9_-]/g, '').slice(0, 160);
  const name = String(row.name || row.title || '').replace(/\s+/g, ' ').trim().slice(0, 160);
  const price = Number(row.price || 0) || 0;
  const subscribe = Boolean(row.subscribe || row.is_subscribe || row.isSubscribe);
  return {
    key,
    name,
    index,
    kind: subscribe ? '定期購読' : (price > 0 ? '有料' : '無料'),
    available: !subscribe && price <= 0,
    reason: subscribe || price > 0 ? '他の人の記事は無料マガジンのみ追加できます' : ''
  };
}

async function fetchMyMagazines() {
  const payload = await fetchNoteJson('/v1/my/magazines', 6000);
  return magazineRows(payload).map(normalizeApiMagazine).filter((row) => row.key && row.name);
}

function noteNumericId(payload) {
  let data = payload && payload.data !== undefined ? payload.data : payload;
  if (data && data.note && typeof data.note === 'object') data = data.note;
  const id = Number(data && (data.id || data.note_id || data.noteId) || 0);
  return Number.isFinite(id) && id > 0 ? id : 0;
}

async function runDirectMagazineAddMutation(articleUrl, target, expectedAccount = '') {
  const expected = String(expectedAccount || '').replace(/[^a-zA-Z0-9_-]/g, '').slice(0, 80);
  try {
    const account = await getViewerAccount(true);
    const actual = String(account && account.urlname || '');
    if (!actual) return { ok: false, code: 'login_required', message: 'Firefoxでnoteへログインしてください。' };
    if (expected && actual !== expected) {
      return { ok: false, code: 'account_mismatch', message: '現在は @' + actual + ' でログイン中です。@' + expected + ' に切り替えてください。' };
    }
    const magazines = await fetchMyMagazines();
    let magazine = null;
    if (target && target.key) magazine = magazines.find((row) => row.key === target.key) || null;
    if (!magazine && target && target.name) {
      const exact = magazines.filter((row) => row.name === target.name);
      if (exact.length > 1) return { ok: false, code: 'magazine_ambiguous', message: '同名のマガジンが複数あります。重複を整理してからお試しください。' };
      magazine = exact[0] || null;
    }
    if (!magazine && target && !target.key && !target.name) magazine = magazines.find((row) => row.index === Number(target.index)) || null;
    if (!magazine) return { ok: false, code: 'magazine_missing', message: '「' + String(target && target.name || '指定したマガジン') + '」をログイン中のアカウントで確認できませんでした。' };
    if (!magazine.available) return { ok: false, code: 'magazine_unavailable', message: magazine.reason || 'このマガジンには記事を追加できません。' };

    const noteKey = articleKey(articleUrl);
    const notePayload = await fetchNoteJson('/v3/notes/' + encodeURIComponent(noteKey), 6000);
    const noteId = noteNumericId(notePayload);
    if (!noteId) return { ok: false, code: 'note_id_missing', message: '記事IDを確認できなかったため追加を止めました。' };
    const { response, payload } = await fetchNoteMutation('/v1/our/magazines/' + encodeURIComponent(magazine.key) + '/notes', {
      body: { note_id: noteId, note_key: noteKey },
      timeoutMs: 12000
    });
    const data = payload && payload.data !== undefined ? payload.data : payload;
    const apiMessage = noteMutationErrorMessage(payload, '');
    if (response.ok && !apiMessage && (!data || !data.status || data.status === 'success')) {
      return { ok: true, action: 'magazine_add', already: false, verified: true, magazine: { key: magazine.key, name: magazine.name }, source: 'note_api_v1_extension' };
    }
    if (response.status === 429) {
      return {
        ok: false,
        code: 'magazine_rate_limited',
        message: 'noteのマガジン追加制限を検知しました。待機後に自動で再開します。',
        status: response.status,
        retryAfterMs: responseRetryAfterMs(response)
      };
    }
    if (response.status === 401 || response.status === 403) {
      return { ok: false, code: 'login_required', message: 'Firefoxでnoteへログインしてください。', status: response.status };
    }
    const message = apiMessage || 'noteがマガジン追加を受け付けませんでした。';
    if (isMagazineAlreadyError(response.status, message)) {
      return { ok: true, action: 'magazine_add', already: true, verified: true, magazine: { key: magazine.key, name: magazine.name }, source: 'note_api_v1_extension' };
    }
    if (isMagazineItemRejection(response.status, apiMessage)) {
      return { ok: true, action: 'magazine_add', skipped: true, verified: true, code: 'magazine_item_rejected', message, status: response.status, magazine: { key: magazine.key, name: magazine.name }, source: 'note_api_v1_extension' };
    }
    return { ok: false, code: 'magazine_api_rejected', message, status: response.status };
  } catch (error) {
    if (error && error.name === 'AbortError') {
      return { ok: false, code: 'magazine_result_unknown', message: '12秒以内に追加結果を確認できませんでした。二重追加を避けるため自動処理を停止します。' };
    }
    return { ok: false, code: 'magazine_api_unavailable', message: 'noteとのマガジン通信に失敗しました。自動処理を停止します。' };
  }
}

async function runAccountApi() {
  try {
    const account = await getViewerAccount();
    if (!account || !account.urlname) {
      return { ok: false, code: 'login_required', message: 'Firefoxでnoteへログインするか、自分のnoteユーザー名を入力してください。' };
    }
    return { ok: true, action: 'account', urlname: String(account.urlname), nickname: String(account.nickname || account.name || account.urlname), key: String(account.key || ''), followingCount: followingCountFrom(account) };
  } catch (_) {
    return { ok: false, code: 'account_unavailable', message: 'ログイン中のnoteアカウントを確認できませんでした。ユーザー名を入力してください。' };
  }
}

function followingRows(payload) {
  const data = payload && payload.data !== undefined ? payload.data : payload;
  return data && Array.isArray(data.follows) ? data.follows : [];
}

function followingTotalFrom(payload) {
  const data = payload && payload.data !== undefined ? payload.data : payload;
  const row = data && typeof data === 'object' ? data : {};
  const pagination = row.pagination && typeof row.pagination === 'object' ? row.pagination : {};
  return Number(row.totalCount || row.total_count || row.count || pagination.totalCount || pagination.total_count || pagination.total || 0) || 0;
}

function normalizeFollowing(value) {
  const row = value || {};
  return {
    key: String(row.key || ''),
    urlname: String(row.urlname || '').replace(/[^a-zA-Z0-9_-]/g, '').slice(0, 80),
    nickname: String(row.nickname || row.name || row.urlname || ''),
    userIcon: String(row.userProfileImagePath || row.profileImageUrl || row.user_profile_image_url || row.profile_image_url || ''),
    hasPublishedNote: row.hasPublishedNote !== false,
    withdrawal: Boolean(row.withdrawal)
  };
}

function pickRandomPages(totalPages, count, random = Math.random) {
  const max = Math.max(1, Number(totalPages) || 1);
  const wanted = Math.max(1, Math.min(Number(count) || 1, max));
  const pages = [];
  while (pages.length < wanted) {
    const page = 1 + Math.floor(random() * max);
    if (!pages.includes(page)) pages.push(page);
  }
  return pages;
}

function shuffleRows(rows, random = Math.random) {
  const copy = rows.slice();
  for (let index = copy.length - 1; index > 0; index -= 1) {
    const swap = Math.floor(random() * (index + 1));
    [copy[index], copy[swap]] = [copy[swap], copy[index]];
  }
  return copy;
}

async function followingPageV3(creatorKey, page) {
  return fetchNoteJson('/v3/users/' + encodeURIComponent(creatorKey) + '/followings?page=' + page + '&per=20', 6000);
}

async function followingPageV2(urlname, page) {
  return fetchNoteJson('/v2/creators/' + encodeURIComponent(urlname) + '/followings?page=' + page, 6000);
}

async function sampleFollowingPages(firstPayload, pageLoader, totalCount, eligibleLimit, sampleSize, pageSize = 20) {
  const eligibleCount = Math.max(0, Math.min(Number(totalCount) || 0, eligibleLimit));
  const totalPages = Math.max(1, Math.ceil(eligibleCount / pageSize));
  // Choose enough random positions to supply ten candidates per position.
  // Page 1 is never forced into a draw, so recently followed users have no
  // special advantage over older follows.
  const positionCount = Math.max(1, Math.min(Math.ceil(sampleSize / 10), totalPages));
  const pages = pickRandomPages(totalPages, positionCount);
  const payloads = await Promise.all(pages.map((page) => page === 1 ? firstPayload : pageLoader(page)));
  const pageGroups = payloads.map((payload) => {
    const rows = followingRows(payload)
      .map(normalizeFollowing)
      .filter((row) => row.urlname && row.hasPublishedNote && !row.withdrawal);
    return [...new Map(rows.map((row) => [row.urlname, row])).values()];
  });
  const preferred = [];
  const overflow = [];
  const perPosition = pages.length === 1 ? sampleSize : 10;
  pageGroups.forEach((group) => {
    const mixed = shuffleRows(group);
    preferred.push(...mixed.slice(0, perPosition));
    overflow.push(...mixed.slice(perPosition));
  });
  const uniquePreferred = [...new Map(preferred.map((row) => [row.urlname, row])).values()];
  const seen = new Set(uniquePreferred.map((row) => row.urlname));
  const topUp = shuffleRows(overflow).filter((row) => {
    if (seen.has(row.urlname)) return false;
    seen.add(row.urlname);
    return true;
  });
  const candidatePool = uniquePreferred.slice();
  if (candidatePool.length < sampleSize) candidatePool.push(...topUp.slice(0, sampleSize - candidatePool.length));
  const creators = shuffleRows(candidatePool).slice(0, sampleSize);
  return { creators, eligibleCount, sampledPages: pages, sampledPositions: pages.map((page) => (page - 1) * pageSize + 1) };
}

async function runFollowingsApi(sampleSizeValue) {
  const sampleSize = Math.max(10, Math.min(Number(sampleSizeValue) || 20, 50));
  try {
    const account = await getViewerAccount();
    if (!account || !account.urlname) return { ok: false, code: 'login_required', message: 'Firefoxでnoteへログインしてください。' };
    const actualCount = followingCountFrom(account);
    if (account.key) {
      try {
        const first = await followingPageV3(account.key, 1);
        const totalCount = followingTotalFrom(first) || actualCount || followingRows(first).length;
        const sampled = await sampleFollowingPages(first, (page) => followingPageV3(account.key, page), totalCount, 5000, sampleSize);
        return { ok: true, action: 'followings', ...sampled, totalCount, capped: totalCount > 5000, source: 'note_api_v3' };
      } catch (_) {
        // Fall back to the older public list. It exposes at most 600 people.
      }
    }
    const first = await followingPageV2(account.urlname, 1);
    const exposedCount = Math.min(followingTotalFrom(first) || actualCount || followingRows(first).length, 600);
    const sampled = await sampleFollowingPages(first, (page) => followingPageV2(account.urlname, page), exposedCount, 600, sampleSize, 12);
    return { ok: true, action: 'followings', ...sampled, totalCount: actualCount || exposedCount, capped: (actualCount || exposedCount) > 600, legacyLimit: true, source: 'note_api_v2' };
  } catch (error) {
    return {
      ok: false,
      code: error && error.name === 'AbortError' ? 'followings_timeout' : 'followings_api_failed',
      message: error && error.name === 'AbortError'
        ? 'フォロー一覧の取得が8秒でタイムアウトしました。'
        : 'フォロー一覧を取得できませんでした。Firefoxでnoteへログインしてから、もう一度お試しください。'
    };
  }
}

async function runStatusApi(articleUrl, force = false) {
  const cached = statusCache.get(articleUrl);
  if (!force && cached && cached.expiresAt > Date.now()) return { ...cached.result, cached: true };
  try {
    const payload = await fetchNoteJson('/v3/notes/' + encodeURIComponent(articleKey(articleUrl)), 5000);
    const note = payload && payload.data;
    if (!note || typeof note.is_liked !== 'boolean') throw new Error('unknown like status');
    const user = note.user && typeof note.user === 'object' ? note.user : {};
    const result = {
      ok: true,
      action: 'status',
      liked: Boolean(note.is_liked),
      creator: {
        id: String(user.id || ''),
        urlname: String(user.urlname || ''),
        nickname: String(user.nickname || user.name || user.urlname || ''),
        isFollowing: Boolean(user.is_following),
        isFollower: typeof user.is_follower === 'boolean' ? user.is_follower : null,
        isMe: Boolean(user.is_me)
      },
      verified: true,
      source: 'note_api_v3'
    };
    statusCache.set(articleUrl, { result, expiresAt: Date.now() + STATUS_CACHE_MS });
    return result;
  } catch (_) {
    return { ok: false, code: 'status_api_failed', message: 'スキ状態を確認できませんでした。' };
  }
}

async function runStatusBatchApi(urlValues) {
  const urls = [...new Set((Array.isArray(urlValues) ? urlValues : [])
    .map((value) => String(value || '').split('#')[0])
    .filter(isAllowedArticleUrl))].slice(0, 30);
  if (!urls.length) return { ok: false, code: 'invalid_status_batch', message: '未スキ確認対象がありません。' };
  const results = new Array(urls.length);
  let cursor = 0;
  async function worker() {
    while (cursor < urls.length) {
      const index = cursor++;
      const result = await runStatusApi(urls[index]);
      results[index] = { url: urls[index], ok: Boolean(result && result.ok), liked: Boolean(result && result.liked) };
    }
  }
  await Promise.all(Array.from({ length: Math.min(6, urls.length) }, worker));
  return { ok: true, action: 'status_batch', results };
}

function searchContentRows(payload) {
  const data = payload && payload.data !== undefined ? payload.data : payload;
  const candidates = [
    data,
    data && data.contents,
    data && data.notes,
    data && data.notes && data.notes.contents,
    data && data.items,
    data && data.results
  ];
  return candidates.find(Array.isArray) || [];
}

function normalizeSearchContent(value) {
  const row = value && value.note && typeof value.note === 'object' ? value.note : (value || {});
  const user = row.user || row.author || row.actor || {};
  const key = String(row.key || row.noteKey || row.note_key || row.id || '');
  const urlname = String(user.urlname || row.urlname || '');
  const url = String(row.noteUrl || row.note_url || row.url || (key && urlname ? 'https://note.com/' + urlname + '/n/' + key : ''));
  return {
    key,
    name: String(row.name || row.title || '無題の記事'),
    description: String(row.description || row.bodyText || row.body_text || row.summary || '').slice(0, 3000),
    eyecatch: String(row.eyecatch || row.eyecatchUrl || row.eyecatch_url || row.image || ''),
    publishAt: String(row.publishAt || row.publish_at || row.createdAt || row.created_at || ''),
    url,
    urlname,
    nickname: String(user.nickname || user.name || urlname),
    userIcon: String(user.userProfileImagePath || user.profileImageUrl || user.user_profile_image_url || user.profile_image_url || ''),
    likeCount: Number(row.likeCount || row.like_count || 0),
    commentCount: Number(row.commentCount || row.comment_count || 0)
  };
}

async function fetchCreatorContentsPage(urlname, page = 1) {
  const safe = String(urlname || '').replace(/[^a-zA-Z0-9_-]/g, '').slice(0, 80);
  if (!safe) return [];
  const payload = await fetchNoteJson('/v2/creators/' + encodeURIComponent(safe) + '/contents?kind=note&page=' + Math.max(1, Number(page) || 1), 8000);
  return searchContentRows(payload)
    .map(normalizeSearchContent)
    .filter((item) => item.key && item.urlname && isAllowedArticleUrl(item.url));
}

async function runCreatorArticlesApi(urlnameValue) {
  const urlname = String(urlnameValue || '').replace(/[^a-zA-Z0-9_-]/g, '').slice(0, 80);
  if (!urlname) return { ok: false, code: 'invalid_creator', message: 'noteユーザーを確認できませんでした。' };
  try {
    const items = [];
    const seen = new Set();
    for (let page = 1; page <= 1000; page += 1) {
      const rows = await fetchCreatorContentsPage(urlname, page);
      let added = 0;
      rows.forEach((item) => {
        if (seen.has(item.url)) return;
        seen.add(item.url);
        items.push(item);
        added += 1;
      });
      if (!rows.length || added === 0) break;
    }
    return { ok: true, action: 'creator_articles', urlname, items, verified: true, source: 'note_api_v2' };
  } catch (_) {
    return { ok: false, code: 'creator_articles_failed', message: '@' + urlname + ' の記事一覧を取得できませんでした。' };
  }
}

async function runCreatorLatestBatchApi(urlnameValues) {
  const creators = [...new Set((Array.isArray(urlnameValues) ? urlnameValues : [])
    .map((value) => String(value || '').replace(/[^a-zA-Z0-9_-]/g, '').slice(0, 80))
    .filter(Boolean))].slice(0, 200);
  if (!creators.length) return { ok: true, action: 'creator_latest_batch', items: [], failed: [] };
  const items = [];
  const failed = [];
  let cursor = 0;
  async function worker() {
    while (cursor < creators.length) {
      const index = cursor++;
      const urlname = creators[index];
      try {
        const rows = await fetchCreatorContentsPage(urlname, 1);
        const latest = rows.slice().sort((left, right) => (Date.parse(right.publishAt || '') || 0) - (Date.parse(left.publishAt || '') || 0))[0];
        if (latest) items[index] = latest;
        else failed.push(urlname);
      } catch (_) {
        failed.push(urlname);
      }
    }
  }
  await Promise.all(Array.from({ length: Math.min(4, creators.length) }, worker));
  return {
    ok: true,
    action: 'creator_latest_batch',
    items: items.filter(Boolean),
    failed,
    verified: true,
    source: 'note_api_v2'
  };
}

async function runSearchApi(queryValue, pageValue) {
  const query = String(queryValue || '').replace(/^#+/, '').trim().slice(0, 80);
  const page = Math.max(1, Math.min(Number(pageValue) || 1, 30));
  if (!query) return { ok: false, code: 'invalid_search', message: '検索語を入力してください。' };
  try {
    const params = new URLSearchParams({
      context: 'note',
      mode: 'search',
      q: query,
      size: '20',
      start: String((page - 1) * 20),
      sort: 'new'
    });
    const payload = await fetchNoteJson('/v3/searches?' + params.toString(), 8000);
    const items = searchContentRows(payload).map(normalizeSearchContent).filter((item) => item.key && item.urlname && isAllowedArticleUrl(item.url));
    return { ok: true, action: 'search', items, page, verified: true, source: 'note_api_v3' };
  } catch (error) {
    return {
      ok: false,
      code: error && error.name === 'AbortError' ? 'search_timeout' : 'search_api_failed',
      message: error && error.name === 'AbortError'
        ? 'note検索が8秒でタイムアウトしました。'
        : 'noteの検索結果を取得できませんでした。Firefoxでnoteへログインしてから、もう一度お試しください。'
    };
  }
}

async function waitForContentScript(tabId, operation) {
  const deadline = Date.now() + 25000;
  let lastError = null;
  while (Date.now() < deadline) {
    try {
      const tab = await browser.tabs.get(tabId);
      if (tab.status === 'complete') {
        return await browser.tabs.sendMessage(tabId, {
          type: 'NERO_NOTE_ACTION',
          operation
        });
      }
    } catch (error) {
      lastError = error;
    }
    await delay(150);
  }
  throw lastError || new Error('noteの記事を開けませんでした');
}

async function activateTab(tabId) {
  try {
    await browser.tabs.update(tabId, { active: true });
    return true;
  } catch (_) {
    // If activation is unavailable, the caller still receives a useful error.
    return false;
  }
}

async function closeTab(tabId) {
  try {
    await browser.tabs.remove(tabId);
  } catch (_) {
    // The user may have closed the temporary tab first.
  }
}

function shouldRetryCommentInActiveTab() {
  // UI automation is deliberately never started automatically. Direct API
  // failures stay in Reader so the user's screen cannot move unexpectedly.
  return false;
}

async function runNoteOperation(message, readerTabId) {
  const action = message.action;
  const articleUrl = ['account', 'search', 'followings', 'status_batch', 'creator_articles', 'creator_latest_batch'].includes(action) ? 'https://note.com/' : String(message.articleUrl || '').split('#')[0];
  const comment = String(message.comment || '').trim();
  const replyTarget = normalizeReplyTarget(message.replyTarget);
  const magazineTarget = normalizeMagazineTarget(message);
  const expectedAccount = String(message && message.expectedAccount || '').replace(/[^a-zA-Z0-9_-]/g, '').slice(0, 80);
  const isMutation = action === 'like' || action === 'comment' || action === 'comment_like' || action === 'reply_with_like' || action === 'follow' || action === 'magazine_add';
  const isReadOnly = action === 'status' || action === 'status_batch' || action === 'comments' || action === 'engagement_article' || action === 'article_reactors' || action === 'creator_articles' || action === 'creator_latest_batch' || action === 'account' || action === 'search' || action === 'followings' || action === 'magazines';

  if (!['account', 'status', 'status_batch', 'comments', 'engagement_article', 'article_reactors', 'creator_articles', 'creator_latest_batch', 'search', 'followings', 'magazines', 'magazine_add', 'like', 'comment', 'comment_like', 'reply_with_like', 'follow'].includes(action) || (!['account', 'search', 'followings', 'status_batch', 'creator_articles', 'creator_latest_batch'].includes(action) && !isAllowedArticleUrl(articleUrl))) {
    return { ok: false, code: 'invalid_request', message: '記事情報を確認できませんでした。' };
  }
  if ((action === 'comment' || action === 'reply_with_like') && (!comment || comment.length > 500)) {
    return { ok: false, code: 'invalid_comment', message: 'コメントは1〜500文字で入力してください。' };
  }
  if ((action === 'comment_like' || action === 'reply_with_like') && !replyTarget) {
    return { ok: false, code: 'invalid_comment_target', message: '対象のコメントを確認できませんでした。' };
  }
  if (action === 'magazine_add' && !magazineTarget) {
    return { ok: false, code: 'invalid_magazine_target', message: '追加先のマガジンを確認できませんでした。' };
  }

  // Read-only data comes from note's current JSON API. This avoids opening
  // hidden tabs, which is slow and unreliable on Firefox for Android.
  if (action === 'account') return runAccountApi();
  if (action === 'search') return runSearchApi(message.query, message.page);
  if (action === 'followings') return runFollowingsApi(message.sampleSize);
  if (action === 'status_batch') return runStatusBatchApi(message.urls);
  if (action === 'creator_articles') return runCreatorArticlesApi(message.urlname);
  if (action === 'creator_latest_batch') return runCreatorLatestBatchApi(message.creators);
  if (action === 'status') return runStatusApi(articleUrl, message.force === true);
  if (action === 'comments') return runCommentsApi(articleUrl, message.summaryOnly === true);
  if (action === 'article_reactors') return runArticleReactorsApi(articleUrl);
  if (action === 'engagement_article') return runEngagementArticleApi(articleUrl, {
    includeLikes: message.includeLikes !== false,
    includeComments: message.includeComments !== false,
    cutoffMs: Number(message.cutoffMs) || 0
  });

  if (isMutation && activeOperation) {
    return { ok: false, code: 'busy', message: '前の操作を処理しています。少し待ってからもう一度お試しください。' };
  }

  const targetKey = (action === 'comment_like' || action === 'reply_with_like') && replyTarget
    ? ':' + replyTarget.authorUrlname + ':' + replyTarget.publishedAt + ':' + replyTarget.body.slice(0, 80)
    : (action === 'magazine_add' && magazineTarget ? ':' + (magazineTarget.key || magazineTarget.name || magazineTarget.index) : '');
  const throttleKey = isMutation ? action + ':' + articleKey(articleUrl) + targetKey : '';
  if (isMutation) {
    const lastRun = recentOperations.get(throttleKey) || 0;
    if (Date.now() - lastRun < 8000) {
      return { ok: false, code: 'throttled', message: '同じ操作の連続送信を止めました。8秒後にお試しください。' };
    }
  }

  const operation = {
    id: crypto.randomUUID ? crypto.randomUUID() : String(Date.now()) + Math.random(),
    action,
    articleUrl,
    articleKey: articleKey(articleUrl),
    comment: action === 'comment' || action === 'reply_with_like' ? comment : '',
    replyTarget: action === 'comment' || action === 'comment_like' || action === 'reply_with_like' ? replyTarget : null,
    magazineTarget: action === 'magazine_add' ? magazineTarget : null,
    expectedAccount: action === 'magazine_add' ? expectedAccount : '',
    // Mutations use note's own authenticated request inside an inactive tab.
    // The tab is never activated automatically, even if the request fails.
    commentMode: action === 'comment' ? 'direct_only' : ''
  };
  if (isMutation) {
    activeOperation = operation.id;
    recentOperations.set(throttleKey, Date.now());
  }

  let tab = null;
  try {
    // Mutations with stable note endpoints run in the background process.
    // No page tab or DOM automation is involved, including paid article likes.
    if (action === 'like') {
      const result = await runDirectArticleLikeMutation(articleUrl);
      return result && result.ok ? result : { ...result, openedNote: false };
    }
    if (action === 'magazine_add') {
      const result = await runDirectMagazineAddMutation(articleUrl, magazineTarget, expectedAccount);
      return result && result.ok ? result : { ...result, openedNote: false };
    }
    if (action === 'comment') {
      const commentResult = await runDirectCommentMutation(articleUrl, comment, replyTarget);
      if (!commentResult || !commentResult.ok) return { ...commentResult, openedNote: false };
      return { ...commentResult, commentSent: true };
    }
    if (action === 'reply_with_like') {
      const reply = await runDirectCommentMutation(articleUrl, comment, replyTarget);
      if (!reply || !reply.ok) return { ...reply, openedNote: false };
      const like = await runDirectCommentLikeMutation(articleUrl, replyTarget);
      if (!like || !like.ok) {
        return {
          ok: false,
          partial: true,
          replySent: true,
          code: 'reply_sent_like_failed',
          message: '返信は送信済みですが、コメントへのスキを確認できませんでした。未対応一覧の「スキで対応」を押してください。',
          likeResult: like || null,
          openedNote: false
        };
      }
      return { ok: true, action: 'reply_with_like', replySent: true, liked: true, verified: true, replyResult: reply, likeResult: like };
    }
    if (action === 'comment_like') {
      const result = await runDirectCommentLikeMutation(articleUrl, replyTarget);
      return result && result.ok ? result : { ...result, openedNote: false };
    }

    tab = await browser.tabs.create({ url: articleUrl, active: false });
    const result = await waitForContentScript(tab.id, operation);
    if (result && result.ok) {
      await closeTab(tab.id);
      return result;
    }

    await closeTab(tab.id);
    return {
      ok: false,
      openedNote: false,
      code: result && result.code ? result.code : (isReadOnly ? 'read_unavailable' : 'note_action_failed'),
      message: result && result.message ? result.message : (isReadOnly ? 'noteの情報を確認できませんでした。' : 'noteへの操作を完了できませんでした。Reader画面はそのままです。')
    };
  } catch (error) {
    if (tab && tab.id) await closeTab(tab.id);
    return {
      ok: false,
      openedNote: false,
      code: isReadOnly ? 'read_unavailable' : 'bridge_failed',
      message: isReadOnly ? 'noteの情報を確認できませんでした。' : 'noteとの通信に失敗しました。Reader画面はそのままです。'
    };
  } finally {
    if (isMutation) activeOperation = null;
  }
}

browser.runtime.onMessage.addListener((message, sender) => {
  if (!message || typeof message !== 'object') return undefined;

  if (message.type === 'NERO_OPEN_READER') {
    return browser.tabs.create({ url: READER_URL, active: true }).then(() => ({ ok: true }));
  }

  if (message.type === 'NERO_OPEN_NERO_READER') {
    return browser.tabs.create({ url: READER_URL + 'nero-favorites', active: true }).then(() => ({ ok: true }));
  }

  if (message.type === 'NERO_OPEN_NOTE_LOGIN') {
    return browser.tabs.create({ url: 'https://note.com/login', active: true }).then(() => ({ ok: true }));
  }

  if (message.type === 'NERO_READER_ACTION') {
    let senderOrigin = '';
    try { senderOrigin = new URL(sender.url || '').origin; } catch (_) {}
    if (senderOrigin !== READER_ORIGIN) {
      return Promise.resolve({ ok: false, code: 'unauthorized', message: 'Reader以外からの操作を拒否しました。' });
    }
    return runNoteOperation(message, sender && sender.tab ? sender.tab.id : null);
  }

  return undefined;
});

function readerSenderOrigin(sender) {
  try { return new URL(sender && sender.url || '').origin; } catch (_) { return ''; }
}

function handleMutationPort(port) {
  if (!port || port.name !== 'NERO_MUTATION_V1') return;
  if (readerSenderOrigin(port.sender) !== READER_ORIGIN) {
    try { port.disconnect(); } catch (_) {}
    return;
  }
  let handled = false;
  port.onMessage.addListener((message) => {
    if (handled || !message || message.type !== 'NERO_READER_ACTION') return;
    handled = true;
    const requestId = String(message.requestId || '');
    runNoteOperation(message, port.sender && port.sender.tab ? port.sender.tab.id : null)
      .then((result) => {
        try { port.postMessage({ requestId, result }); } catch (_) {}
      })
      .catch(() => {
        try {
          port.postMessage({
            requestId,
            result: { ok: false, code: 'bridge_failed', message: 'noteとの操作通信を完了できませんでした。' }
          });
        } catch (_) {}
      });
  });
}

// A Port keeps Firefox for Android's event page alive only while a user action
// is running. This prevents long comment operations from losing their reply
// without keeping the extension resident all day.
if (browser.runtime.onConnect && browser.runtime.onConnect.addListener) {
  browser.runtime.onConnect.addListener(handleMutationPort);
}

globalThis.NeroBackgroundTest = {
  isAllowedArticleUrl,
  articleKey,
  normalizeReplyTarget,
  normalizeMagazineTarget,
  commentAstText,
  normalizeApiComment,
  fetchNoteComments,
  likeRows,
  normalizeEngagementUser,
  normalizeApiLike,
  fetchNoteLikes,
  runEngagementArticleApi,
  runArticleReactorsApi,
  fetchCreatorContentsPage,
  runCreatorArticlesApi,
  runCreatorLatestBatchApi,
  searchContentRows,
  normalizeSearchContent,
  accountFromPayload,
  followingCountFrom,
  followingRows,
  followingTotalFrom,
  normalizeFollowing,
  pickRandomPages,
  sampleFollowingPages,
  runStatusBatchApi,
  fetchNoteMutation,
  noteMutationErrorMessage,
  isMagazineAlreadyError,
  isMagazineItemRejection,
  responseRetryAfterMs,
  noteCommentAst,
  runDirectCommentMutation,
  runDirectCommentLikeMutation,
  runDirectArticleLikeMutation,
  runDirectMagazineAddMutation,
  magazineRows,
  normalizeApiMagazine,
  noteNumericId,
  shouldRetryCommentInActiveTab,
  readerSenderOrigin,
  handleMutationPort,
  runNoteOperation
};

;

// Source: app-api-core.js
'use strict';
(function(){
  const C={VERSION:'0.1.44',PORT_NAME:'NERO_APP_V2',READER_ORIGIN:'https://cosmos-invest.github.io',READER_PATH_PREFIX:'/nero-swipe-reader/',INBOX_PREFIX:'nero.app.inbox.v4.',PRIORITY_PREFIX:'nero.app.priority.v2.',ARTICLE_LIST_TTL_MS:5*60*1000,ARTICLE_REFRESH_MS:7*24*60*60*1000,PRIORITY_WINDOW_MS:30*24*60*60*1000,TARGET_MAGAZINE:'ネロのお気に入り🌙'};
  const articleListCache=new Map(),activeJobs=new Map();
  function safeOwner(v){return String(v||'').trim().replace(/[^a-zA-Z0-9_-]/g,'').slice(0,80).toLowerCase();}
  function safeArticleUrl(v){try{const u=new URL(String(v||''));if(u.protocol!=='https:'||u.hostname!=='note.com'||!/^\/[^/]+\/n\/[^/]+/.test(u.pathname))return'';return u.origin+u.pathname;}catch(_){return'';}}
  function isReaderPort(port){try{const u=new URL(port&&port.sender&&port.sender.url||'');return u.origin===C.READER_ORIGIN&&u.pathname.startsWith(C.READER_PATH_PREFIX);}catch(_){return false;}}
  function bg(){const a=globalThis.NeroBackgroundTest;if(!a||typeof a.runNoteOperation!=='function')throw new Error('background_api_unavailable');return a;}
  async function noteAction(action,args={}){return bg().runNoteOperation({action,...args},null);}
  function cacheKey(prefix,owner){return prefix+safeOwner(owner);}
  async function getStored(key,fallback){try{const r=await browser.storage.local.get(key),v=r&&r[key];return v&&typeof v==='object'?v:fallback;}catch(_){return fallback;}}
  async function setStored(key,value){await browser.storage.local.set({[key]:value});}
  async function currentAccount(){const r=await noteAction('account'),owner=r&&r.ok?safeOwner(r.urlname):'';return{ok:Boolean(owner),owner,raw:r||null};}
  async function creatorArticles(owner,force=false){const k=safeOwner(owner),c=articleListCache.get(k);if(!force&&c&&c.expiresAt>Date.now())return c.items;const r=await noteAction('creator_articles',{urlname:k});if(!r||!r.ok)throw new Error(r&&r.message||'記事一覧を取得できませんでした。');const items=Array.isArray(r.items)?r.items:[];articleListCache.set(k,{items,expiresAt:Date.now()+C.ARTICLE_LIST_TTL_MS});return items;}
  function compactComment(x){return{key:String(x&&x.key||''),rootKey:String(x&&x.rootKey||''),threadIndex:Number(x&&x.threadIndex||0),depth:Number(x&&x.depth||0),authorUrlname:safeOwner(x&&x.authorUrlname),authorName:String(x&&x.authorName||''),avatar:String(x&&x.avatar||''),body:String(x&&x.body||''),publishedAt:String(x&&x.publishedAt||''),rootAuthorUrlname:safeOwner(x&&x.rootAuthorUrlname),rootBody:String(x&&x.rootBody||''),creatorLiked:Boolean(x&&x.creatorLiked),viewerLiked:Boolean(x&&x.viewerLiked)};}
  function progress(port,id,p){try{port.postMessage({type:'progress',requestId:id,progress:p});}catch(_){}}
  function jobToken(kind){const old=activeJobs.get(kind);if(old)old.cancelled=true;const t={kind,cancelled:false,startedAt:Date.now()};activeJobs.set(kind,t);return t;}
  function finishJob(kind,t){if(activeJobs.get(kind)===t)activeJobs.delete(kind);}
  function cancelJob(kind){const t=activeJobs.get(String(kind||''));if(t)t.cancelled=true;return{ok:true,cancelled:Boolean(t)};}
  async function fetchArticle(args={}){const key=String(args.key||'').trim();if(!/^n[a-zA-Z0-9_-]+$/.test(key))return{ok:false,code:'invalid_article_key',message:'記事IDを確認できませんでした。'};const ctl=new AbortController(),timer=setTimeout(()=>ctl.abort(),12000);try{const res=await fetch('https://note.com/api/v3/notes/'+encodeURIComponent(key),{credentials:'include',cache:'no-store',headers:{Accept:'application/json'},signal:ctl.signal});if(!res.ok)return{ok:false,code:'article_fetch_'+res.status,message:'記事本文を取得できませんでした。'};let row=await res.json();row=row&&row.data&&typeof row.data==='object'?row.data:row;row=row&&row.note&&typeof row.note==='object'?row.note:row;row=row&&typeof row==='object'?row:{};const pick=(...ns)=>ns.map(n=>row[n]).find(v=>typeof v==='string'&&v.trim())||'';return{ok:true,key,title:pick('name','title'),body:pick('body','bodyText','body_text','contentText'),description:pick('description'),imageUrl:pick('eyecatch','eyecatchUrl','eyecatch_url','thumbnail_url','image_url'),likeCount:Number(row.like_count||row.likeCount||0)};}catch(e){return{ok:false,code:e&&e.name==='AbortError'?'article_timeout':'article_failed',message:'記事本文を取得できませんでした。'};}finally{clearTimeout(timer);}}
  async function favoriteAdd(args={}){const articleUrl=safeArticleUrl(args.articleUrl);if(!articleUrl)return{ok:false,code:'invalid_article',message:'記事を確認できませんでした。'};const m=await noteAction('magazines',{articleUrl});if(!m||!m.ok)return m||{ok:false,message:'マガジン一覧を取得できませんでした。'};const rows=Array.isArray(m.magazines)?m.magazines:[],i=rows.findIndex(r=>String(r.name||'')===C.TARGET_MAGAZINE);if(i<0)return{ok:false,code:'target_magazine_missing',message:`「${C.TARGET_MAGAZINE}」が見つかりませんでした。`};const t=rows[i];return noteAction('magazine_add',{articleUrl,magazineKey:String(t.key||''),magazineName:C.TARGET_MAGAZINE,magazineIndex:i,expectedAccount:String(args.expectedAccount||'')});}
  function automationApi(){const a=globalThis.NeroLocalAutoTest;if(!a||typeof a.status!=='function')throw new Error('automation_api_unavailable');return a;}
  globalThis.NeroAppApiCore={C,safeOwner,safeArticleUrl,isReaderPort,bg,noteAction,cacheKey,getStored,setStored,currentAccount,creatorArticles,compactComment,progress,jobToken,finishJob,cancelJob,fetchArticle,favoriteAdd,automationApi,activeJobs};
})();

;

// Source: member-api.js
"use strict";
(() => {
  const A = globalThis.NeroAppApiCore;
  A.C.VERSION = "0.5.1";
  A.C.EXCLUDE_LIKED_COMMENTS = true;
  A.isReaderPort = (port) =>
    port?.sender?.id === browser.runtime.id &&
    port.sender.url === browser.runtime.getURL("reader/index.html");
  const original = A.noteAction;
  let commentBusy = false;
  A.noteAction = async (action, args = {}) => {
    if (
      ![
        "account",
        "search",
        "status",
        "comments",
        "creator_articles",
        "creator_latest_batch",
        "like",
        "comment",
        "comment_like",
      ].includes(action)
    )
      return { ok: false, message: "対応していない操作です。" };
    if (["like", "comment", "comment_like"].includes(action)) {
      const acc = await original("account");
      if (
        !acc?.ok ||
        !args.expectedAccount ||
        acc.urlname.toLowerCase() !== String(args.expectedAccount).toLowerCase()
      )
        return {
          ok: false,
          code: "account_changed",
          message:
            "ログイン中のアカウントが変わりました。接続を確認してください。",
        };
    }
    if (action === "comment_like") {
      // Ignore cached flags: a like must target the specific original comment.
      const result = await original(action, {
        ...args,
        replyTarget: { ...args.replyTarget, liked: false },
      });
      if (result?.ok) return result;
      if (
        result?.status === 409 ||
        [
          "comment_like_result_unknown",
          "comment_like_api_unavailable",
        ].includes(result?.code)
      ) {
        // A lost response or duplicate rejection is not proof of success.
        // Confirm the current viewer's flag with a fresh read, never repost.
        const comments = await original("comments", {
          articleUrl: args.articleUrl,
          summaryOnly: false,
        });
        const account = await original("account");
        const expected = String(args.expectedAccount || "").toLowerCase();
        if (
          account?.ok &&
          account.urlname?.toLowerCase() === expected &&
          comments?.ok &&
          String(comments.viewerUrlname || "").toLowerCase() === expected &&
          comments.comments?.some(
            (c) =>
              String(c.key) === String(args.replyTarget?.commentKey) &&
              c.viewerLiked === true,
          )
        )
          return {
            ok: true,
            action: "comment_like",
            liked: true,
            already: true,
            verified: true,
            source: "note_comments_verified",
          };
      }
      return result;
    }
    if (action !== "comment") return original(action, args);
    if (commentBusy)
      return {
        ok: false,
        code: "busy",
        message: "前のコメントを送信しています。",
      };
    const text = String(args.comment || "").trim();
    if (!text || text.length > 500 || !A.safeArticleUrl(args.articleUrl))
      return {
        ok: false,
        code: "invalid_comment",
        message: "記事と1〜500文字の本文を確認してください。",
      };
    commentBusy = true;
    try {
      const fingerprint = JSON.stringify([
        String(args.expectedAccount).toLowerCase(),
        args.articleUrl,
        args.replyTarget?.key || "",
        text,
      ]);
      const hash = await crypto.subtle.digest(
        "SHA-256",
        new TextEncoder().encode(fingerprint),
      );
      const id =
        "nero.members.sent." +
        A.safeOwner(args.expectedAccount) +
        "." +
        Array.from(new Uint8Array(hash), (x) =>
          x.toString(16).padStart(2, "0"),
        ).join("");
      const markers = await browser.storage.local.get(null);
      const expired = Object.keys(markers).filter(
        (k) =>
          k.startsWith("nero.members.sent.") &&
          Date.now() - Number(markers[k]?.at || 0) >= 86400000,
      );
      if (expired.length) await browser.storage.local.remove(expired);
      const previous = (await browser.storage.local.get(id))[id];
      if (previous && Date.now() - previous.at < 86400000)
        return previous.sent
          ? { ok: true, commentSent: true, already: true }
          : {
              ok: false,
              code: "comment_result_unknown",
              message:
                "同じコメントの送信結果が未確認です。noteで確認してください。24時間は重複送信を防止します。",
            };
      await browser.storage.local.set({
        [id]: { at: Date.now(), sent: false },
      });
      // The server result may be unknown after a network failure. Keep the
      // durable marker across tabs and background restarts in that case.
      const result = await original(action, args);
      if (result?.ok) {
        try {
          await browser.storage.local.set({
            [id]: { at: Date.now(), sent: true },
          });
        } catch {
          // The server confirmed the comment. A local receipt failure must
          // never turn that success into an invitation to post it again.
          return { ...result, commentSent: true, receiptSaved: false };
        }
      } else if (
        [
          "login_required",
          "invalid_comment",
          "busy",
          "throttled",
          "comment_api_rejected",
          "comment_acknowledgement",
        ].includes(result?.code)
      )
        await browser.storage.local.remove(id);
      return result;
    } finally {
      commentBusy = false;
    }
  };
  browser.browserAction.onClicked.addListener(() =>
    browser.tabs.create({ url: browser.runtime.getURL("reader/index.html") }),
  );
})();

;

// Source: chrome/account.js
"use strict";
(() => {
  const A = globalThis.NeroAppApiCore;
  const noteTabMessage =
    "同じChromeでnoteのタブを開き、ログイン後に「再確認」を押してください。";
  const accessMessage =
    "Chromeの拡張機能を再読み込みし、NERO Swipe Readerのサイトへのアクセスでnote.comを許可してから「再確認」を押してください。";
  const invalidMessage =
    "noteの応答を確認できませんでした。noteのタブでログイン状態を確認し、「再確認」を押してください。";

  const record = (value) =>
    value !== null && typeof value === "object" && !Array.isArray(value);
  const text = (value, fallback = "") =>
    typeof value === "string" ? value : fallback;

  function failure(code, message, status) {
    return {
      ok: false,
      owner: "",
      raw: {
        ok: false,
        code,
        ...(Number.isInteger(status) && status >= 100 && status <= 599
          ? { status }
          : {}),
        message,
      },
    };
  }

  function httpFailure(status) {
    const label =
      Number.isInteger(status) && status >= 100 && status <= 599
        ? `（HTTP ${status}）`
        : "";
    if (status === 401)
      return failure("login_required", noteTabMessage + label, status);
    if (status === 403)
      return failure(
        "account_forbidden",
        "noteが接続を拒否しました。noteのタブを開き、ページやアカウントへアクセスできることを確認してから「再確認」を押してください。" +
          label,
        status,
      );
    if (status === 429)
      return failure(
        "account_rate_limited",
        "noteへの確認が多すぎるため、少し待ってから「再確認」を押してください。" +
          label,
        status,
      );
    if (status >= 500)
      return failure(
        "account_server_error",
        "note側でエラーが発生しています。少し待ってから「再確認」を押してください。" +
          label,
        status,
      );
    return failure(
      "account_http_error",
      "noteのログイン状態を確認できませんでした。noteのタブを開いて接続を確認し、もう一度「再確認」を押してください。" +
        label,
      status,
    );
  }

  function transportFailure(error, signal) {
    const code = typeof error?.code === "string" ? error.code : "";
    if (
      signal.aborted ||
      error?.name === "AbortError" ||
      code === "note_request_aborted"
    )
      return failure(
        "account_timeout",
        "noteとの接続がタイムアウトしました。通信状態とnoteのタブを確認してから「再確認」を押してください。",
      );
    if (code === "note_tab_required") return failure(code, noteTabMessage);
    if (
      [
        "note_site_access",
        "note_transport_unavailable",
        "note_page_unavailable",
        "note_request_blocked",
      ].includes(code)
    )
      return failure(code, accessMessage);
    if (code === "note_tab_changed")
      return failure(
        code,
        "noteのタブが閉じられたか、別のページに切り替わりました。noteのタブを開き直して「再確認」を押してください。",
      );
    if (["note_response_too_large", "note_invalid_response"].includes(code))
      return failure(code, invalidMessage);
    return failure(
      "account_network_error",
      "noteとの通信に失敗しました。noteのタブを開いて通信状態を確認し、「再確認」を押してください。",
    );
  }

  function accountRow(payload) {
    // Never combine an outer identity with metadata from another nested user.
    // An explicitly present but invalid wrapper fails closed.
    let row = payload;
    if (!record(row)) return null;
    if (Object.hasOwn(row, "data")) row = row.data;
    if (!record(row)) return null;
    if (Object.hasOwn(row, "user")) row = row.user;
    return record(row) ? row : null;
  }

  A.currentAccount = async () => {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 12000);
    try {
      // `fetch` is the lexical note-tab transport supplied to the generated
      // Chrome engine. This module never changes the page's native globals.
      const response = await fetch("https://note.com/api/v2/current_user", {
        method: "GET",
        credentials: "include",
        cache: "no-store",
        headers: { Accept: "application/json" },
        signal: controller.signal,
      });
      if (!response || typeof response.ok !== "boolean")
        return failure("account_invalid_response", invalidMessage);
      if (!response.ok) return httpFailure(response.status);
      let payload;
      try {
        const contentType = response.headers?.get?.("content-type");
        if (
          typeof contentType === "string" &&
          contentType.trim() &&
          !/^application\/(?:[a-z0-9!#$&^_.+-]+\+)?json(?:\s*;|\s*$)/i.test(
            contentType.trim(),
          )
        )
          return failure(
            "account_invalid_response",
            invalidMessage,
            response.status,
          );
        payload = await response.json();
      } catch (error) {
        if (controller.signal.aborted || error?.name === "AbortError")
          throw error;
        return failure(
          "account_invalid_response",
          invalidMessage,
          response.status,
        );
      }
      const row = accountRow(payload);
      if (
        typeof row?.urlname !== "string" ||
        row.urlname !== row.urlname.trim() ||
        !/^[a-zA-Z0-9_-]{1,80}$/.test(row.urlname)
      )
        return failure(
          "account_invalid_response",
          invalidMessage,
          response.status,
        );
      const owner = row.urlname.toLowerCase();
      const followingCount = Number(
        row.followingCount ?? row.following_count ?? 0,
      );
      return {
        ok: true,
        owner,
        raw: {
          ok: true,
          action: "account",
          urlname: owner,
          nickname: text(row.nickname, text(row.name, owner)).slice(0, 200),
          key: text(row.key).slice(0, 200),
          followingCount:
            Number.isFinite(followingCount) && followingCount >= 0
              ? Math.floor(followingCount)
              : 0,
        },
      };
    } catch (error) {
      return transportFailure(error, controller.signal);
    } finally {
      clearTimeout(timer);
    }
  };
})();

;

// Source: member-article.js
"use strict";
(() => {
  const A = globalThis.NeroAppApiCore;
  const record = (value) =>
    value !== null && typeof value === "object" && !Array.isArray(value);
  const firstString = (value, names) =>
    names
      .map((name) => value?.[name])
      .find((item) => typeof item === "string" && item.trim()) || "";
  const creatorName = (value) =>
    typeof value === "string" && /^[a-zA-Z0-9_-]{1,80}$/.test(value.trim())
      ? value.trim().toLowerCase()
      : "";

  function imageUrl(value) {
    if (typeof value !== "string") return "";
    try {
      const url = new URL(value);
      return url.protocol === "https:" && !url.username && !url.password
        ? url.href
        : "";
    } catch {
      return "";
    }
  }

  function articleIdentity(value, key) {
    if (typeof value !== "string") return null;
    try {
      const url = new URL(value);
      const match = url.pathname.match(
        /^\/([a-zA-Z0-9_-]{1,80})\/n\/(n[a-zA-Z0-9_-]+)\/?$/,
      );
      if (
        url.protocol !== "https:" ||
        url.hostname !== "note.com" ||
        url.port ||
        url.username ||
        url.password ||
        !match ||
        match[2] !== key
      )
        return null;
      const urlname = match[1].toLowerCase();
      return { urlname, url: `https://note.com/${urlname}/n/${key}` };
    } catch {
      return null;
    }
  }

  function failure(code) {
    return {
      ok: false,
      code,
      message: "記事本文を取得できませんでした。",
    };
  }

  A.fetchArticle = async (args = {}) => {
    const key = typeof args?.key === "string" ? args.key.trim() : "";
    if (!/^n[a-zA-Z0-9_-]+$/.test(key))
      return {
        ok: false,
        code: "invalid_article_key",
        message: "記事IDを確認できませんでした。",
      };
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 12000);
    try {
      const response = await fetch(
        "https://note.com/api/v3/notes/" + encodeURIComponent(key),
        {
          credentials: "include",
          cache: "no-store",
          headers: { Accept: "application/json" },
          signal: controller.signal,
        },
      );
      if (!response.ok) return failure("article_fetch_" + response.status);
      let row = await response.json();
      if (record(row) && Object.hasOwn(row, "data")) row = row.data;
      if (record(row) && Object.hasOwn(row, "note")) row = row.note;
      if (!record(row)) return failure("article_invalid_response");
      if (typeof row.key === "string" && row.key && row.key !== key)
        return failure("article_key_mismatch");
      // A successful HTTP response can still be an error envelope. Keep an
      // empty paid/restricted body empty, but do not call an error object an
      // article merely because the request itself returned 200.
      if (
        ![
          "key",
          "name",
          "title",
          "body",
          "bodyText",
          "body_text",
          "contentText",
          "description",
        ].some((name) => typeof row[name] === "string")
      )
        return failure("article_invalid_response");

      const user = record(row.user)
        ? row.user
        : record(row.author)
          ? row.author
          : {};
      const creator = creatorName(user.urlname) || creatorName(row.urlname);
      let identity = null;
      for (const name of ["noteUrl", "note_url", "url"]) {
        const candidate = articleIdentity(row[name], key);
        if (candidate && (!creator || candidate.urlname === creator)) {
          identity = candidate;
          break;
        }
      }
      if (!identity && creator)
        identity = {
          urlname: creator,
          url: `https://note.com/${creator}/n/${key}`,
        };
      const count = Number(row.like_count ?? row.likeCount ?? 0);
      return {
        ok: true,
        key,
        title: firstString(row, ["name", "title"]),
        body: firstString(row, [
          "body",
          "bodyText",
          "body_text",
          "contentText",
        ]),
        description: firstString(row, ["description"]),
        imageUrl: imageUrl(
          firstString(row, [
            "eyecatch",
            "eyecatchUrl",
            "eyecatch_url",
            "thumbnail_url",
            "image_url",
          ]),
        ),
        likeCount: Number.isFinite(count) && count >= 0 ? Math.floor(count) : 0,
        url: identity?.url || "",
        urlname: identity?.urlname || "",
        nickname:
          firstString(user, ["nickname", "name"]) ||
          firstString(row, ["nickname"]) ||
          identity?.urlname ||
          "",
        publishAt: firstString(row, [
          "publishAt",
          "publish_at",
          "publishedAt",
          "published_at",
          "createdAt",
          "created_at",
        ]),
        userIcon: imageUrl(
          firstString(user, [
            "userProfileImagePath",
            "profileImageUrl",
            "user_profile_image_url",
            "profile_image_url",
          ]),
        ),
      };
    } catch (error) {
      return failure(
        error?.name === "AbortError" ? "article_timeout" : "article_failed",
      );
    } finally {
      clearTimeout(timer);
    }
  };
})();

;

// Source: app-api-inbox.js
'use strict';
(function(){
  const A=globalThis.NeroAppApiCore,C=A.C;
  function inboxKey(url,c){return[url,String(c&&(c.key||c.commentKey)||''),String(c&&c.authorUrlname||''),String(c&&c.publishedAt||''),String(c&&c.body||'')].join('|');}
  function replyTarget(c){return{key:String(c&&(c.rootKey||c.key)||''),commentKey:String(c&&c.key||''),rootKey:String(c&&(c.rootKey||c.key)||''),authorUrlname:String(c&&c.authorUrlname||''),authorName:String(c&&c.authorName||''),body:String(c&&c.body||''),publishedAt:String(c&&c.publishedAt||''),depth:Number(c&&c.depth||0)?1:0,rootAuthorUrlname:String(c&&(c.rootAuthorUrlname||(!c.depth?c.authorUrlname:''))||''),rootBody:String(c&&(c.rootBody||(!c.depth?c.body:''))||'')};}
  // Member readers treat a comment liked by the signed-in article owner as handled.
  // Keep the legacy Pages inbox behavior unless the member policy is enabled.
  function excludedByLike(c){return C.EXCLUDE_LIKED_COMMENTS===true&&Boolean(c&&(c.creatorLiked||c.viewerLiked||c.liked));}
  function unresolvedReplyComments(comments,ownerValue){const owner=A.safeOwner(ownerValue),groups=new Map();(Array.isArray(comments)?comments:[]).forEach((c,i)=>{const t=Number.isFinite(Number(c&&c.threadIndex))?Number(c.threadIndex):i;if(!groups.has(t))groups.set(t,[]);groups.get(t).push(c);});const out=[];groups.forEach(thread=>{let last=-1;thread.forEach((c,i)=>{if(A.safeOwner(c&&c.authorUrlname)===owner)last=i;});thread.forEach((c,i)=>{if(i>last&&A.safeOwner(c&&c.authorUrlname)&&A.safeOwner(c.authorUrlname)!==owner&&!excludedByLike(c))out.push({...c,replyTarget:replyTarget(c)});});});return out;}
  function flatten(cache){const rows=[];Object.values(cache&&cache.articles||{}).forEach(e=>(Array.isArray(e.unresolved)?e.unresolved:[]).filter(c=>!excludedByLike(c)).forEach(c=>rows.push({key:inboxKey(e.articleUrl,c),articleUrl:e.articleUrl,articleTitle:e.articleTitle||'',comment:{...c,replyTarget:replyTarget(c)}})));rows.sort((a,b)=>(Date.parse(b.comment.publishedAt||'')||0)-(Date.parse(a.comment.publishedAt||'')||0));return rows;}
  async function status(ownerValue){let owner=A.safeOwner(ownerValue);if(!owner)owner=(await A.currentAccount()).owner;if(!owner)return{ok:false,code:'login_required',message:'Firefoxでnoteへログインしてください。'};const key=A.cacheKey(C.INBOX_PREFIX,owner),cache=await A.getStored(key,{version:4,owner,articles:{},updatedAt:0,completedAt:0,totalArticles:0,failed:0});return{ok:true,owner,items:flatten(cache),updatedAt:Number(cache.updatedAt||0),completedAt:Number(cache.completedAt||0),totalArticles:Number(cache.totalArticles||0),failed:Number(cache.failed||0)};}
  async function scan(port,id,args={}){const token=A.jobToken('inbox');try{const acc=await A.currentAccount();if(!acc.ok)return{ok:false,code:'login_required',message:'Firefoxでnoteへログインしてください。'};const owner=acc.owner,key=A.cacheKey(C.INBOX_PREFIX,owner),cache=await A.getStored(key,{version:4,owner,articles:{},updatedAt:0,completedAt:0,totalArticles:0,failed:0});cache.version=4;cache.owner=owner;cache.articles=cache.articles||{};A.progress(port,id,{phase:'articles',message:'記事一覧を確認しています…',completed:0,total:0,found:flatten(cache).length});const articles=await A.creatorArticles(owner,true);cache.totalArticles=articles.length;const seen=new Set(),now=Date.now(),todo=[];articles.forEach(item=>{const url=A.safeArticleUrl(item.url);if(!url)return;seen.add(url);const count=Number(item.commentCount||0),old=cache.articles[url];if(!count){cache.articles[url]={articleUrl:url,articleTitle:item.name||'',commentCount:0,unresolved:[],checkedAt:now};return;}const pending=old&&Array.isArray(old.unresolved)&&old.unresolved.length>0,stale=!old||now-Number(old.checkedAt||0)>=C.ARTICLE_REFRESH_MS,changed=!old||Number(old.commentCount||0)!==count;if(args.force===true||pending||stale||changed)todo.push({...item,url});});Object.keys(cache.articles).forEach(url=>{if(!seen.has(url))delete cache.articles[url];});await A.setStored(key,{...cache,updatedAt:Date.now()});let cursor=0,completed=0,failed=0;A.progress(port,id,{phase:'comments',message:`確認が必要な${todo.length}記事を調べます`,completed,total:todo.length,found:flatten(cache).length});async function worker(){while(cursor<todo.length&&!token.cancelled){const item=todo[cursor++];try{const r=await A.noteAction('comments',{articleUrl:item.url,summaryOnly:true});if(!r||!r.ok)throw new Error();if(A.safeOwner(r.viewerUrlname)!==owner)throw new Error();const comments=(Array.isArray(r.comments)?r.comments:[]).map(A.compactComment);cache.articles[item.url]={articleUrl:item.url,articleTitle:String(item.name||''),commentCount:Number(item.commentCount||0),unresolved:unresolvedReplyComments(comments,owner).map(A.compactComment),checkedAt:Date.now()};}catch(_){failed++;}completed++;cache.updatedAt=Date.now();if(completed%3===0||completed===todo.length)await A.setStored(key,cache);A.progress(port,id,{phase:'comments',message:`コメント確認中 ${completed} / ${todo.length}`,completed,total:todo.length,found:flatten(cache).length,failed});}}await Promise.all(Array.from({length:Math.min(2,todo.length)},worker));cache.updatedAt=Date.now();cache.failed=failed;if(!token.cancelled)cache.completedAt=Date.now();await A.setStored(key,cache);return{ok:true,owner,cancelled:token.cancelled,items:flatten(cache),updatedAt:cache.updatedAt,completedAt:cache.completedAt,totalArticles:articles.length,checkedArticles:completed,failed};}finally{A.finishJob('inbox',token);}}
  async function remove(ownerValue,keyValue){const owner=A.safeOwner(ownerValue),target=String(keyValue||'');if(!owner||!target)return;const k=A.cacheKey(C.INBOX_PREFIX,owner),cache=await A.getStored(k,{version:4,owner,articles:{}});Object.values(cache.articles||{}).forEach(e=>{e.unresolved=(Array.isArray(e.unresolved)?e.unresolved:[]).filter(c=>inboxKey(e.articleUrl,c)!==target);});cache.updatedAt=Date.now();await A.setStored(k,cache);}
  let activeReply=false;
  async function reply(args={}){if(activeReply)return{ok:false,code:'busy',message:'前の返信を送信しています。'};const url=A.safeArticleUrl(args.articleUrl),text=String(args.comment||'').trim().slice(0,500),target=args.replyTarget&&typeof args.replyTarget==='object'?args.replyTarget:null;if(!url||!text||!target)return{ok:false,code:'invalid_reply',message:'返信内容を確認できませんでした。'};activeReply=true;try{const r=await A.bg().runDirectCommentMutation(url,text,target);if(r&&r.ok)await remove(args.owner,args.inboxKey);return r&&r.ok?{...r,ok:true,replySent:true}:r||{ok:false,message:'返信できませんでした。'};}finally{activeReply=false;}}
  globalThis.NeroAppInbox={inboxKey,replyTarget,unresolvedReplyComments,flatten,status,scan,remove,reply};
})();

;

// Source: member-inbox.js
"use strict";
(() => {
  const A = globalThis.NeroAppApiCore;
  const I = globalThis.NeroAppInbox;
  const scanInbox = I.scan;
  const QUEUE_PREFIX = "nero.members.commentLikes.v1.";
  const MAX_PENDING = 500;
  let scanRunning = false;
  let mutationRunning = false;

  I.scan = async (...args) => {
    if (scanRunning)
      return {
        ok: false,
        code: "busy",
        message: "コメントを取得中です。完了または中断を待ってください。",
      };
    scanRunning = true;
    try {
      return await scanInbox(...args);
    } finally {
      scanRunning = false;
    }
  };

  function ownerName(value) {
    const name = String(value || "").trim();
    return /^[a-zA-Z0-9_-]{1,80}$/.test(name) ? name.toLowerCase() : "";
  }
  function identifier(value) {
    return typeof value === "string" && /^[a-zA-Z0-9_-]{1,160}$/.test(value)
      ? value
      : "";
  }
  function articleUrl(value) {
    try {
      const url = new URL(String(value || ""));
      return url.protocol === "https:" &&
        url.hostname === "note.com" &&
        /^\/[a-zA-Z0-9_-]+\/n\/n[a-zA-Z0-9_-]+\/?$/.test(url.pathname)
        ? url.origin + url.pathname.replace(/\/$/, "")
        : "";
    } catch {
      return "";
    }
  }
  function targetFrom(value, needsCommentKey) {
    if (!value || typeof value !== "object") return null;
    const key = identifier(value.key || value.rootKey);
    const commentKey = identifier(value.commentKey);
    const authorUrlname = ownerName(value.authorUrlname);
    const body = String(value.body || "").trim();
    if (!key || !authorUrlname || !body || (needsCommentKey && !commentKey))
      return null;
    return {
      key,
      rootKey: identifier(value.rootKey) || key,
      commentKey,
      authorUrlname,
      authorName: String(value.authorName || "").slice(0, 160),
      body: body.slice(0, 1000),
      publishedAt: String(value.publishedAt || "").slice(0, 80),
      depth: value.depth ? 1 : 0,
      rootAuthorUrlname: ownerName(value.rootAuthorUrlname),
      rootBody: String(value.rootBody || "").slice(0, 1000),
      // Do not let a stale cached flag short-circuit a requested note mutation.
      liked: false,
    };
  }
  function accountError() {
    return {
      ok: false,
      code: "account_changed",
      message: "ログイン中のアカウントが変わりました。接続を確認してください。",
    };
  }
  async function accountMatches(owner) {
    try {
      const account = await A.currentAccount();
      return account?.ok === true && ownerName(account.owner) === owner;
    } catch {
      return false;
    }
  }
  function invalidTarget() {
    return {
      ok: false,
      code: "invalid_comment_target",
      message: "対象コメントを選び直してください。",
    };
  }
  function queueKey(owner) {
    return QUEUE_PREFIX + owner;
  }
  async function loadQueue(owner) {
    const stored = await browser.storage.local.get(queueKey(owner));
    const value = stored[queueKey(owner)];
    if (
      !value ||
      value.owner !== owner ||
      !value.items ||
      typeof value.items !== "object" ||
      Array.isArray(value.items)
    )
      return { version: 1, owner, items: {} };
    // The comment sender saves its durable receipt before returning success.
    // Recover a combined operation even if the tab/event page closed in the
    // tiny interval before its queue record advanced to like_pending.
    const recoverable = Object.values(value.items).filter(
      (item) =>
        item &&
        item.stage !== "like_pending" &&
        typeof item.receiptKey === "string" &&
        item.receiptKey.startsWith("nero.members.sent." + owner + ".") &&
        /^[a-f0-9]{64}$/.test(item.receiptKey.split(".").pop()),
    );
    if (recoverable.length) {
      const receipts = await browser.storage.local.get(
        recoverable.map((item) => item.receiptKey),
      );
      let changed = false;
      for (const item of recoverable) {
        if (receipts[item.receiptKey]?.sent === true) {
          item.stage = "like_pending";
          item.replySent = true;
          changed = true;
        }
      }
      if (changed) await saveQueue(owner, value);
    }
    return value;
  }
  async function saveQueue(owner, value) {
    await browser.storage.local.set({ [queueKey(owner)]: value });
  }
  function pendingId(url, target) {
    return url + "|" + target.commentKey;
  }
  async function receiptKey(owner, url, target, comment) {
    const fingerprint = JSON.stringify([owner, url, target.key, comment]);
    const hash = await crypto.subtle.digest(
      "SHA-256",
      new TextEncoder().encode(fingerprint),
    );
    return (
      "nero.members.sent." +
      owner +
      "." +
      Array.from(new Uint8Array(hash), (x) =>
        x.toString(16).padStart(2, "0"),
      ).join("")
    );
  }
  async function putPending(owner, url, target, args, stage, replySent) {
    const queue = await loadQueue(owner),
      id = pendingId(url, target);
    if (!queue.items[id] && Object.keys(queue.items).length >= MAX_PENDING)
      throw new Error(
        "スキ未完了の保存件数が上限です。先に未完了のスキを確認してください。",
      );
    const previous = queue.items[id];
    const item = {
      id,
      articleUrl: url,
      articleTitle: String(
        args.articleTitle || previous?.articleTitle || "",
      ).slice(0, 300),
      replyTarget: target,
      inboxKey: String(args.inboxKey || previous?.inboxKey || "").slice(
        0,
        2500,
      ),
      createdAt: Number(previous?.createdAt) || Date.now(),
      stage,
      replySent: replySent === true || previous?.replySent === true,
      reason: String(args.reason || "").slice(0, 500),
      receiptKey: String(args.receiptKey || previous?.receiptKey || ""),
    };
    queue.items[id] = item;
    await saveQueue(owner, queue);
    return item;
  }
  async function clearPending(owner, id) {
    const queue = await loadQueue(owner);
    delete queue.items[id];
    await saveQueue(owner, queue);
  }
  async function removeHandled(owner, inboxKey) {
    try {
      await I.remove(owner, inboxKey);
      return true;
    } catch {
      return false;
    }
  }
  function partialReply(result, pending, likeResult, saved = true) {
    return {
      ok: true,
      replySent: true,
      commentSent: true,
      liked: false,
      likeRequested: true,
      partial: true,
      likePending: true,
      pendingId: pending?.id || "",
      pendingSaved: saved,
      commentResult: result,
      likeResult,
      message:
        "返信は送信済みですが、コメントへのスキを完了できませんでした。返信は再送せず「スキのみ再試行」を使ってください。" +
        (saved ? "" : " 未完了情報を端末に保存できませんでした。"),
    };
  }
  async function sendLike(owner, url, target) {
    if (!(await accountMatches(owner))) return accountError();
    try {
      return await A.noteAction("comment_like", {
        articleUrl: url,
        replyTarget: target,
        expectedAccount: owner,
      });
    } catch {
      return {
        ok: false,
        code: "comment_like_result_unknown",
        message:
          "コメントへのスキの結果を確認できませんでした。スキのみ再試行できます。",
      };
    }
  }
  async function settleLike(owner, pending, result) {
    const cacheSaved = await removeHandled(owner, pending.inboxKey);
    let pendingSaved = true;
    try {
      await clearPending(owner, pending.id);
    } catch {
      pendingSaved = false;
    }
    return {
      ...result,
      ok: true,
      liked: true,
      likePending: false,
      cacheSaved,
      pendingSaved,
    };
  }

  I.pendingLikes = async (ownerValue) => {
    // Reading may promote a receipt-backed placeholder and save the queue.
    // Serialize this recovery with mutations across every reader tab.
    if (mutationRunning)
      return {
        ok: false,
        code: "busy",
        message: "コメント操作中です。完了後にスキ未完了を再確認してください。",
      };
    const owner = ownerName(ownerValue);
    if (!owner) return accountError();
    mutationRunning = true;
    try {
      if (!(await accountMatches(owner))) return accountError();
      const queue = await loadQueue(owner);
      const values = Object.values(queue.items);
      return {
        ok: true,
        owner,
        items: values
          .filter(
            (item) =>
              item?.stage === "like_pending" &&
              articleUrl(item.articleUrl) &&
              targetFrom(item.replyTarget, true),
          )
          .sort((a, b) => Number(b.createdAt) - Number(a.createdAt)),
        unknownReplyCount: values.filter(
          (item) =>
            item?.stage === "reply_pending" || item?.stage === "reply_unknown",
        ).length,
      };
    } catch {
      return {
        ok: false,
        code: "pending_likes_storage_failed",
        message: "スキ未完了の保存情報を読み込めませんでした。",
      };
    } finally {
      mutationRunning = false;
    }
  };

  I.like = async (args = {}) => {
    if (mutationRunning)
      return {
        ok: false,
        code: "busy",
        message: "前のコメント操作を処理しています。",
      };
    const owner = ownerName(args.owner);
    if (!owner) return accountError();
    mutationRunning = true;
    try {
      if (!(await accountMatches(owner))) return accountError();
      let source = args;
      if (args.pendingId) {
        const stored = (await loadQueue(owner)).items[String(args.pendingId)];
        if (!stored || stored.stage !== "like_pending") return invalidTarget();
        source = {
          ...stored,
          ...args,
          articleUrl: stored.articleUrl,
          replyTarget: stored.replyTarget,
          inboxKey: stored.inboxKey,
        };
      }
      const url = articleUrl(source.articleUrl),
        target = targetFrom(source.replyTarget, true);
      if (!url || !target) return invalidTarget();
      const pending = await putPending(
        owner,
        url,
        target,
        source,
        "like_pending",
        source.replySent,
      );
      const result = await sendLike(owner, url, target);
      if (!result?.ok) {
        try {
          await putPending(
            owner,
            url,
            target,
            { ...source, reason: result?.message || "スキ未完了" },
            "like_pending",
            pending.replySent,
          );
        } catch {}
        return {
          ...(result || { ok: false }),
          liked: false,
          likePending: true,
          pendingId: pending.id,
        };
      }
      return await settleLike(owner, pending, result);
    } catch (error) {
      return {
        ok: false,
        code: "pending_likes_storage_failed",
        message: String(
          error?.message || "スキ未完了の情報を保存できませんでした。",
        ),
      };
    } finally {
      mutationRunning = false;
    }
  };
  I.retryLike = I.like;

  I.reply = async (args = {}) => {
    if (mutationRunning)
      return {
        ok: false,
        code: "busy",
        message: "前のコメント操作を処理しています。",
      };
    const owner = ownerName(args.owner),
      url = articleUrl(args.articleUrl);
    const withLike = args.likeComment !== false;
    const target = targetFrom(args.replyTarget, withLike);
    const comment = String(args.comment || "").trim();
    if (!owner || !url || !target) return invalidTarget();
    if (!comment || comment.length > 500)
      return {
        ok: false,
        code: "invalid_comment",
        message: "返信は1〜500文字で入力してください。",
      };
    mutationRunning = true;
    let pending = null;
    let replied = null;
    let previousPending = null;
    try {
      if (!(await accountMatches(owner))) return accountError();
      // A durable placeholder is saved BEFORE posting, so a tab closure cannot
      // erase all evidence of an in-flight combined operation. Only confirmed
      // replies advance to like_pending and become eligible for like-only retry.
      if (withLike) {
        args = {
          ...args,
          receiptKey: await receiptKey(owner, url, target, comment),
        };
        previousPending =
          (await loadQueue(owner)).items[pendingId(url, target)] || null;
        pending =
          previousPending ||
          (await putPending(owner, url, target, args, "reply_pending", false));
      }
      try {
        replied = await A.noteAction("comment", {
          articleUrl: url,
          comment,
          replyTarget: target,
          expectedAccount: owner,
        });
      } catch {
        replied = {
          ok: false,
          code: "comment_result_unknown",
          message:
            "返信の送信結果を確認できませんでした。自動再送はしていません。noteで確認してください。",
        };
      }
      const sent =
        replied?.ok === true ||
        replied?.replySent === true ||
        replied?.commentSent === true;
      if (!sent) {
        if (pending && !previousPending) {
          const uncertain = [
            "comment_result_unknown",
            "comment_api_unavailable",
          ].includes(replied?.code);
          try {
            if (uncertain)
              await putPending(
                owner,
                url,
                target,
                { ...args, reason: replied.message },
                "reply_unknown",
                false,
              );
            else await clearPending(owner, pending.id);
          } catch {}
        }
        return (
          replied || {
            ok: false,
            code: "comment_result_unknown",
            message: "返信結果を確認できませんでした。",
          }
        );
      }
      const cacheSaved = await removeHandled(owner, args.inboxKey);
      if (!withLike)
        return {
          ...replied,
          ok: true,
          replySent: true,
          commentSent: true,
          liked: false,
          likeRequested: false,
          cacheSaved,
        };
      try {
        pending = await putPending(
          owner,
          url,
          target,
          args,
          "like_pending",
          true,
        );
      } catch {
        // Never misreport a successfully posted reply as unsent, even if the
        // local queue becomes unavailable between the two network operations.
        return partialReply(
          replied,
          pending,
          { ok: false, code: "pending_likes_storage_failed" },
          false,
        );
      }
      const liked = await sendLike(owner, url, target);
      if (!liked?.ok) {
        try {
          await putPending(
            owner,
            url,
            target,
            { ...args, reason: liked?.message || "スキ未完了" },
            "like_pending",
            true,
          );
        } catch {}
        return partialReply(replied, pending, liked);
      }
      const settled = await settleLike(owner, pending, liked);
      return {
        ...replied,
        ok: true,
        replySent: true,
        commentSent: true,
        liked: true,
        likeRequested: true,
        likePending: false,
        pendingSaved: settled.pendingSaved,
        cacheSaved: cacheSaved && settled.cacheSaved,
        likeResult: liked,
      };
    } catch (error) {
      if (replied?.ok || replied?.replySent || replied?.commentSent)
        return partialReply(
          replied,
          pending,
          { ok: false, code: "pending_likes_storage_failed" },
          false,
        );
      return {
        ok: false,
        code: "pending_likes_storage_failed",
        message: String(
          error?.message ||
            "送信前の保存に失敗しました。返信は送っていません。",
        ),
      };
    } finally {
      mutationRunning = false;
    }
  };
})();

;

// Source: member-feed.js
"use strict";
(() => {
  const A = globalThis.NeroAppApiCore;
  const MAX_PAGES = 1000;
  let running = false;

  function creatorName(value) {
    const name = String(value || "").trim();
    return /^[a-zA-Z0-9_-]{1,80}$/.test(name) ? name.toLowerCase() : "";
  }

  function articleUrl(value) {
    try {
      const url = new URL(String(value || ""));
      if (
        url.protocol !== "https:" ||
        url.hostname !== "note.com" ||
        !/^\/[a-zA-Z0-9_-]+\/n\/n[a-zA-Z0-9_-]+\/?$/.test(url.pathname)
      )
        return "";
      return url.origin + url.pathname.replace(/\/$/, "");
    } catch {
      return "";
    }
  }

  function newestFirst(left, right) {
    return (
      (Date.parse(right.publishAt || "") || 0) -
      (Date.parse(left.publishAt || "") || 0)
    );
  }

  function randomUnit() {
    const values = new Uint32Array(1);
    crypto.getRandomValues(values);
    return values[0] / 4294967296;
  }

  // Shuffle the complete pool after all creators finish. Neither registration
  // order nor network response order gives a creator the first positions.
  function shuffle(items, random = randomUnit) {
    const result = items.slice();
    for (let i = result.length - 1; i > 0; i--) {
      const j = Math.floor(random() * (i + 1));
      [result[i], result[j]] = [result[j], result[i]];
    }
    return result;
  }

  async function accountMatches(expected) {
    try {
      const result = await A.currentAccount();
      return result?.ok === true && creatorName(result.owner) === expected;
    } catch {
      return false;
    }
  }

  function accountError() {
    return {
      ok: false,
      code: "account_changed",
      message:
        "ログイン中のアカウントを確認できませんでした。接続を再確認してから記事を取得してください。",
    };
  }

  async function fetchFeed(port, requestId, args = {}) {
    const expected = creatorName(args.expectedAccount);
    if (!expected) return accountError();
    const mode = args.mode === "deep" ? "deep" : "watch";
    const includeLiked = args.includeLiked === true;
    const target = mode === "deep" ? 50 : 3;
    const deepCreator = creatorName(args.creator);
    if (mode === "deep" && !deepCreator) {
      return {
        ok: false,
        code: "invalid_creator",
        message: "深掘りするnoteユーザーIDを指定してください。",
      };
    }
    const rawCreators = Array.isArray(args.creators) ? args.creators : [];
    const creators =
      mode === "deep"
        ? [deepCreator]
        : [...new Set(rawCreators.map(creatorName).filter(Boolean))];
    if (creators.length > 200) {
      return {
        ok: false,
        code: "watchlist_limit",
        message: "1つのウォッチリストには200人まで登録できます。",
      };
    }
    if (running) {
      return {
        ok: false,
        code: "busy",
        message: "記事を取得中です。完了または中断を待ってください。",
      };
    }
    running = true;
    const token = A.jobToken("watch_feed");
    try {
      if (!(await accountMatches(expected))) return accountError();
      let accountChanged = false;
      const groups = new Array(creators.length);
      const outcomes = new Array(creators.length);
      let cursor = 0,
        checkedCreators = 0,
        candidateCount = 0,
        checkedArticles = 0,
        likedCount = 0,
        statusFailedCount = 0;

      const stopped = () => token.cancelled || accountChanged;
      async function verifyAccount() {
        if (!(await accountMatches(expected))) accountChanged = true;
        return !accountChanged;
      }
      function report(phase, creator) {
        A.progress(port, requestId, {
          phase,
          creator,
          completed: phase === "likes" ? checkedArticles : checkedCreators,
          total: phase === "likes" ? candidateCount : creators.length,
          found: groups.reduce((sum, items) => sum + (items?.length || 0), 0),
          candidateCount,
          checkedArticles,
          liked: likedCount,
          failed: statusFailedCount,
          message: includeLiked
            ? `新しい記事を取得中 ${checkedCreators} / ${creators.length}人`
            : `未スキの記事を確認中 ${checkedArticles}記事・${checkedCreators} / ${creators.length}人`,
        });
      }
      report("creators");

      async function scanCreator(creator, position) {
        const eligible = [];
        groups[position] = eligible;
        const seen = new Set();
        let consecutiveStatusFailures = 0;
        let statusBlocked = false;
        let reason = "limit";
        for (let pageNumber = 1; pageNumber <= MAX_PAGES; pageNumber++) {
          if (stopped()) {
            reason = "cancelled";
            break;
          }
          let page;
          try {
            page = await A.bg().fetchCreatorContentsPage(creator, pageNumber);
            if (!Array.isArray(page))
              throw new Error("invalid_creator_response");
          } catch {
            reason = "failed";
            break;
          }
          // A page is a separate fetch phase. Never use another account's
          // status response to decide which articles belong in this result.
          if (!(await verifyAccount())) break;
          if (stopped()) {
            reason = "cancelled";
            break;
          }
          const fresh = [];
          for (const item of page) {
            const url = articleUrl(item?.url);
            if (
              !url ||
              creatorName(new URL(url).pathname.split("/")[1]) !== creator ||
              seen.has(url)
            )
              continue;
            seen.add(url);
            fresh.push({ ...item, url });
          }
          fresh.sort(newestFirst);
          if (!fresh.length) {
            reason = "exhausted";
            break;
          }

          // At most two status requests per creator and two active creators
          // keeps the whole job at four concurrent status requests.
          for (
            let index = 0;
            index < fresh.length && eligible.length < target;
          ) {
            if (stopped()) break;
            const batch = fresh.slice(
              index,
              index + Math.min(2, target - eligible.length),
            );
            index += batch.length;
            if (includeLiked) {
              candidateCount += batch.length;
              for (const item of batch) {
                // Creator listings may lack viewer-specific metadata. An
                // unknown state must stay unknown when all posts are allowed.
                if (typeof item.liked !== "boolean") delete item.liked;
                eligible.push(item);
              }
              report("creators", creator);
              continue;
            }
            report("likes", creator);
            if (stopped()) break;
            candidateCount += batch.length;
            await Promise.all(
              batch.map(async (item) => {
                try {
                  const status = await A.noteAction("status", {
                    articleUrl: item.url,
                    force: true,
                  });
                  if (!status?.ok || typeof status.liked !== "boolean")
                    throw new Error("unknown_like_status");
                  consecutiveStatusFailures = 0;
                  if (status.liked) likedCount++;
                  else eligible.push({ ...item, liked: false });
                } catch {
                  // A failed/unknown status is omitted and older posts may
                  // still fill the remaining places.
                  statusFailedCount++;
                  consecutiveStatusFailures++;
                  if (consecutiveStatusFailures >= 10) statusBlocked = true;
                }
                checkedArticles++;
                report("likes", creator);
              }),
            );
            if (statusBlocked) break;
          }
          if (eligible.length >= target) {
            reason = "complete";
            break;
          }
          if (stopped()) {
            reason = "cancelled";
            break;
          }
          if (statusBlocked) {
            reason = "status_failed";
            break;
          }
          // A short page is not a terminal marker. Continue until an empty
          // page, a repeated page (zero new URLs), or the explicit safety cap.
        }
        eligible.sort(newestFirst);
        outcomes[position] = {
          creator,
          reason,
          found: eligible.length,
          target,
        };
        checkedCreators++;
        report("creators", creator);
      }

      async function creatorWorker() {
        while (cursor < creators.length && !stopped()) {
          const position = cursor++;
          await scanCreator(creators[position], position);
        }
      }
      await Promise.all(
        Array.from({ length: Math.min(2, creators.length) }, creatorWorker),
      );
      if (!(await verifyAccount())) return accountError();
      if (accountChanged) return accountError();
      const items = groups.flat().filter(Boolean);
      const failedCreators = outcomes
        .filter((outcome) =>
          ["failed", "status_failed"].includes(outcome?.reason),
        )
        .map((outcome) => outcome.creator);
      const limitReachedCreators = outcomes
        .filter((outcome) => outcome?.reason === "limit")
        .map((outcome) => outcome.creator);
      const shortfallCreators = creators.flatMap((creator, position) => {
        const outcome = outcomes[position];
        if (outcome?.found >= target) return [];
        return [outcome || { creator, reason: "cancelled", found: 0, target }];
      });
      const emptyCreators = outcomes
        .filter((outcome) => outcome?.reason === "exhausted" && !outcome.found)
        .map((outcome) => outcome.creator);
      return {
        ok: true,
        owner: expected,
        mode,
        includeLiked,
        items: shuffle(items),
        cancelled: Boolean(token.cancelled),
        partial: Boolean(
          token.cancelled ||
          failedCreators.length ||
          limitReachedCreators.length ||
          statusFailedCount,
        ),
        totalCreators: creators.length,
        checkedCreators,
        candidateCount,
        checkedArticles,
        likedCount,
        statusFailedCount,
        failedCreators,
        emptyCreators,
        limitReachedCreators,
        shortfallCreators,
        failed: failedCreators,
      };
    } finally {
      A.finishJob("watch_feed", token);
      running = false;
    }
  }

  globalThis.NeroMemberFeed = {
    fetch: fetchFeed,
    shuffle,
    creatorName,
    articleUrl,
  };
})();

;

// Source: app-api-priority.js
'use strict';
(function(){
  const A=globalThis.NeroAppApiCore,C=A.C;
  function aggregate(cache,cutoff){const m=new Map();Object.values(cache&&cache.articles||{}).forEach(e=>(Array.isArray(e.comments)?e.comments:[]).forEach(c=>{const at=Date.parse(c.publishedAt||'')||0;if(!at||at<cutoff)return;const k=A.safeOwner(c.authorUrlname);if(!k||k===A.safeOwner(cache.owner))return;let r=m.get(k);if(!r){r={urlname:k,nickname:c.authorName||k,userIcon:c.avatar||'',commentCount:0,lastCommentAt:''};m.set(k,r);}r.commentCount++;if(at>(Date.parse(r.lastCommentAt||'')||0))r.lastCommentAt=new Date(at).toISOString();}));return Array.from(m.values()).sort((a,b)=>(Date.parse(b.lastCommentAt||'')||0)-(Date.parse(a.lastCommentAt||'')||0));}
  async function status(ownerValue){let owner=A.safeOwner(ownerValue);if(!owner)owner=(await A.currentAccount()).owner;if(!owner)return{ok:false,code:'login_required',message:'Firefoxでnoteへログインしてください。'};const k=A.cacheKey(C.PRIORITY_PREFIX,owner),cache=await A.getStored(k,{version:2,owner,articles:{},rows:[],updatedAt:0,completedAt:0,failed:0});return{ok:true,owner,rows:Array.isArray(cache.rows)?cache.rows:[],updatedAt:Number(cache.updatedAt||0),completedAt:Number(cache.completedAt||0),failed:Number(cache.failed||0)};}
  async function scan(port,id,args={}){const token=A.jobToken('priority');try{const acc=await A.currentAccount();if(!acc.ok)return{ok:false,code:'login_required',message:'Firefoxでnoteへログインしてください。'};const owner=acc.owner,k=A.cacheKey(C.PRIORITY_PREFIX,owner),cache=await A.getStored(k,{version:2,owner,articles:{},rows:[],updatedAt:0,completedAt:0,failed:0});cache.version=2;cache.owner=owner;cache.articles=cache.articles||{};const cutoff=Date.now()-C.PRIORITY_WINDOW_MS;A.progress(port,id,{phase:'articles',message:'コメント履歴のある記事を確認しています…',completed:0,total:0,found:(cache.rows||[]).length});const articles=await A.creatorArticles(owner,true),seen=new Set(),now=Date.now(),todo=[];articles.forEach(item=>{const url=A.safeArticleUrl(item.url);if(!url)return;seen.add(url);const count=Number(item.commentCount||0),old=cache.articles[url];if(!count){cache.articles[url]={articleUrl:url,articleTitle:item.name||'',commentCount:0,comments:[],checkedAt:now};return;}const stale=!old||now-Number(old.checkedAt||0)>=C.ARTICLE_REFRESH_MS,changed=!old||Number(old.commentCount||0)!==count;if(args.force===true||stale||changed)todo.push({...item,url});});Object.keys(cache.articles).forEach(url=>{if(!seen.has(url))delete cache.articles[url];});let cursor=0,completed=0,failed=0;A.progress(port,id,{phase:'comments',message:`差分${todo.length}記事を確認します`,completed,total:todo.length,found:aggregate(cache,cutoff).length});async function worker(){while(cursor<todo.length&&!token.cancelled){const item=todo[cursor++];try{const r=await A.noteAction('comments',{articleUrl:item.url,summaryOnly:true});if(!r||!r.ok)throw new Error();const comments=(Array.isArray(r.comments)?r.comments:[]).map(A.compactComment).filter(c=>A.safeOwner(c.authorUrlname)!==owner&&(Date.parse(c.publishedAt||'')||0)>=cutoff);cache.articles[item.url]={articleUrl:item.url,articleTitle:item.name||'',commentCount:Number(item.commentCount||0),comments,checkedAt:Date.now()};}catch(_){failed++;}completed++;cache.updatedAt=Date.now();if(completed%3===0||completed===todo.length)await A.setStored(k,cache);A.progress(port,id,{phase:'comments',message:`コメント履歴を確認中 ${completed} / ${todo.length}`,completed,total:todo.length,found:aggregate(cache,cutoff).length,failed});}}await Promise.all(Array.from({length:Math.min(2,todo.length)},worker));const creators=aggregate(cache,cutoff).slice(0,200);A.progress(port,id,{phase:'latest',message:`${creators.length}人の最新記事を取得しています…`,completed:0,total:creators.length,found:creators.length});let latest={ok:true,items:[]};if(creators.length&&!token.cancelled)latest=await A.noteAction('creator_latest_batch',{creators:creators.map(r=>r.urlname)});const by=new Map((Array.isArray(latest.items)?latest.items:[]).map(x=>[A.safeOwner(x.urlname),x]));cache.rows=creators.map(c=>{const x=by.get(c.urlname);return x?{...x,nickname:c.nickname||x.nickname||c.urlname,commentCount:c.commentCount,lastCommentAt:c.lastCommentAt}:null;}).filter(Boolean);cache.updatedAt=Date.now();cache.failed=failed;if(!token.cancelled)cache.completedAt=Date.now();await A.setStored(k,cache);return{ok:true,owner,cancelled:token.cancelled,rows:cache.rows,updatedAt:cache.updatedAt,completedAt:cache.completedAt,checkedArticles:completed,totalArticles:articles.length,failed};}finally{A.finishJob('priority',token);}}
  globalThis.NeroAppPriority={aggregate,status,scan};
})();

;

// Source: app-api-router.js
'use strict';
(function(){
  const A=globalThis.NeroAppApiCore,C=A.C;
  async function returnStatus(){const s=await A.automationApi().status(),state=s&&s.state||{};let t={targets:[],returnIntervalMinutes:1};try{if(globalThis.NeroReturnLikesV141Test&&typeof globalThis.NeroReturnLikesV141Test.readTargets==='function')t=await globalThis.NeroReturnLikesV141Test.readTargets();}catch(_){}return{ok:true,state,returnLikes:state.returnLikes||{},targets:Array.isArray(t.targets)?t.targets:[],returnIntervalMinutes:Number(t.returnIntervalMinutes||1)};}
  async function returnControl(c){const a=A.automationApi();if(c==='scan'){const r=await a.scanReturnLikes();return{...r,state:a.publicState(await a.loadState())};}if(c==='start'||c==='resume'){const r=await a.startReturnLikes();return{...r,state:a.publicState(await a.loadState())};}if(c==='pause'){const r=await a.pauseReturnLikes();return{...r,state:a.publicState(await a.loadState())};}return{ok:false,code:'invalid_control',message:'操作を確認できませんでした。'};}
  async function autoControl(c){const a=A.automationApi();if(c==='enable')return a.enableAutomation();if(c==='disable')return a.disableAutomation();if(c==='resume')return a.resumeAutomation();if(c==='run'){const summary=await a.runOnce('manual');return{ok:true,summary,state:a.publicState(await a.loadState())};}return{ok:false,code:'invalid_control',message:'操作を確認できませんでした。'};}
  async function backfillControl(c){const a=A.automationApi();if(c==='status'){const s=await a.loadState();return{ok:true,backfill:a.publicBackfill(s.backfill),state:a.publicState(s)};}if(c==='scan'){const r=await a.scanBackfill();return{...r,state:a.publicState(await a.loadState())};}if(c==='start'||c==='resume'){const r=await a.startBackfill();return{...r,state:a.publicState(await a.loadState())};}if(c==='pause'){const r=await a.pauseBackfill();return{...r,state:a.publicState(await a.loadState())};}if(c==='cancel')return a.cancelBackfill();return{ok:false,code:'invalid_control',message:'操作を確認できませんでした。'};}
  async function dispatch(port,id,action,args={}){if(action==='health'){const acc=await A.currentAccount().catch(()=>({ok:false,owner:'',raw:null}));return{ok:true,version:C.VERSION,bridge:true,noteOk:Boolean(acc.ok),owner:acc.owner,noteError:acc.ok?'':String(acc.raw&&acc.raw.message||'noteのログイン状態を確認できませんでした。')};}if(action==='watch_feed')return globalThis.NeroMemberFeed.fetch(port,id,args);if(action==='comment_like')return globalThis.NeroAppInbox.like(args);if(action==='pending_comment_likes')return globalThis.NeroAppInbox.pendingLikes(args.owner);if(action==='article')return A.fetchArticle(args);if(action==='search')return A.noteAction('search',{query:String(args.query||''),page:Number(args.page||1)});if(action==='note_action')return A.noteAction(String(args.noteAction||''),args);if(action==='favorite_add')return A.favoriteAdd(args);if(action==='reply_comment')return globalThis.NeroAppInbox.reply(args);if(action==='inbox_status')return globalThis.NeroAppInbox.status(args.owner);if(action==='inbox_scan')return globalThis.NeroAppInbox.scan(port,id,args);if(action==='priority_status')return globalThis.NeroAppPriority.status(args.owner);if(action==='priority_scan')return globalThis.NeroAppPriority.scan(port,id,args);if(action==='cancel_job')return A.cancelJob(args.kind);if(action==='return_status')return returnStatus();if(action==='return_control')return returnControl(String(args.control||''));if(action==='auto_status')return A.automationApi().status();if(action==='auto_control')return autoControl(String(args.control||''));if(action==='backfill_control')return backfillControl(String(args.control||'status'));return{ok:false,code:'unknown_action',message:'この操作には対応していません。'};}
  function handlePort(port){if(!port||port.name!==C.PORT_NAME)return;if(!A.isReaderPort(port)){try{port.disconnect();}catch(_){}return;}try{port.postMessage({type:'hello',version:C.VERSION});}catch(_){}port.onMessage.addListener(m=>{if(!m||typeof m!=='object'||m.type!=='request')return;const id=String(m.requestId||''),action=String(m.action||'');if(!id||!action)return;Promise.resolve(dispatch(port,id,action,m.args||{})).then(r=>{try{port.postMessage({type:'response',requestId:id,result:r||{ok:false,message:'空の応答でした。'}});}catch(_){}}).catch(e=>{try{port.postMessage({type:'response',requestId:id,result:{ok:false,code:'app_api_failed',message:String(e&&e.message||'処理に失敗しました。')}});}catch(_){}});});}
  if(browser.runtime.onConnect&&browser.runtime.onConnect.addListener)browser.runtime.onConnect.addListener(handlePort);
  globalThis.NeroAppApiTest={...A,unresolvedReplyComments:globalThis.NeroAppInbox.unresolvedReplyComments,priorityRowsFromCache:globalThis.NeroAppPriority.aggregate,constants:C};
})();

;

// Source: reader/app.js
"use strict";
(() => {
  const $ = (id) => document.getElementById(id),
    M = globalThis.NeroMemberModel,
    B = globalThis.NeroArticleBody;
  let port,
    seq = 0,
    owner = "",
    data = M.normalizeData(null, ""),
    rows = [],
    index = 0,
    articleSeq = 0,
    linkedArticle = null,
    articleHistory = [],
    cardObserver = null,
    inbox = [],
    pendingCommentLikes = [],
    pendingLikeVisible = 30,
    unknownReplyCount = 0,
    visible = 30,
    composer = null,
    sending = false,
    scanning = false,
    feeding = false,
    feedSeq = 0,
    feedRequestPosted = false,
    feedCancelled = false;
  const pending = new Map(),
    cardMetadataCache = new Map();
  function notice(text) {
    $("notice").textContent = text;
    $("notice").hidden = !text;
  }
  function connectPort() {
    port = browser.runtime.connect({ name: "NERO_APP_V2" });
    port.onMessage.addListener((m) => {
      const p = pending.get(m.requestId);
      if (!p) return;
      if (m.type === "progress") {
        p.progress?.(m.progress);
        return;
      }
      if (m.type !== "response") return;
      clearTimeout(p.timer);
      pending.delete(m.requestId);
      m.result?.ok
        ? p.resolve(m.result)
        : p.reject(
            Object.assign(
              new Error(m.result?.message || "処理に失敗しました。"),
              { result: m.result },
            ),
          );
    });
    port.onDisconnect.addListener(() => {
      port = null;
      for (const p of pending.values()) {
        clearTimeout(p.timer);
        p.reject(
          new Error(
            "拡張との接続が切れました。送信中だった場合はnoteで結果を確認してください。",
          ),
        );
      }
      pending.clear();
      notice("接続が切れました。「再確認」で接続できます。");
    });
  }
  function rpc(action, args = {}, progress, timeout = 30000) {
    if (!port) connectPort();
    return new Promise((resolve, reject) => {
      const id = String(++seq),
        timer = setTimeout(() => {
          pending.delete(id);
          reject(
            new Error(
              "通信がタイムアウトしました。送信は再試行せずnoteで結果を確認してください。",
            ),
          );
        }, timeout);
      pending.set(id, { resolve, reject, timer, progress });
      try {
        port.postMessage({ type: "request", requestId: id, action, args });
      } catch (e) {
        clearTimeout(timer);
        pending.delete(id);
        reject(e);
      }
    });
  }
  async function save() {
    if (owner) await browser.storage.local.set({ [M.storageKey(owner)]: data });
  }
  async function health() {
    if (sending || scanning) return;
    $("connect").disabled = true;
    try {
      const h = await rpc("health");
      const noteError = globalThis.NeroChromePlatform ? h.noteError : "";
      // A diagnosis started earlier must not replace the account mid-send.
      if (sending || scanning) return;
      const next = h.noteOk ? h.owner : "";
      if (next !== owner) {
        owner = next;
        data = M.normalizeData(null, owner, null);
        restoreFeedOptions();
        resetFeed();
        inbox = [];
        pendingCommentLikes = [];
        unknownReplyCount = 0;
        renderPendingLikes();
        composer = null;
        $("composer").hidden = true;
        renderArticle();
        if (owner) {
          const stored = (await browser.storage.local.get(M.storageKey(owner)))[
            M.storageKey(owner)
          ];
          data = M.normalizeData(stored, owner);
          restoreFeedOptions();
          await save();
        }
        renderWatch();
        renderInbox();
      }
      $("account").textContent = owner
        ? "接続中 @" + owner
        : noteError
          ? "noteとの接続を確認できません"
          : "noteにログインしてください";
      if (owner) {
        const r = await rpc("inbox_status", { owner });
        inbox = r.items || [];
        renderInbox();
        await refreshPendingLikes();
        notice("");
      } else
        notice(
          noteError ||
            "このブラウザーでnoteにログインしてから「再確認」を押してください。",
        );
    } catch (e) {
      notice(e.message);
    } finally {
      $("connect").disabled = false;
    }
  }
  function requireOwner() {
    if (owner) return true;
    notice("先にnoteにログインして接続を確認してください。");
    return false;
  }
  function button(text, fn) {
    const b = document.createElement("button");
    b.type = "button";
    b.textContent = text;
    b.addEventListener("click", fn);
    return b;
  }
  function resetFeed() {
    feedSeq++;
    if (feeding) {
      feedCancelled = true;
      if (feedRequestPosted)
        rpc("cancel_job", { kind: "watch_feed" }).catch(() => {});
    }
    rows = [];
    index = 0;
    resetArticleNavigation();
    renderArticle();
    $("feedStatus").textContent =
      "スキ済みを飛ばして1人最大3本を集め、ランダムに表示します。";
  }
  function renderWatch() {
    const list = M.activeList(data);
    $("watchSelect").replaceChildren();
    for (const item of data.lists) {
      const option = document.createElement("option");
      option.value = item.id;
      option.textContent = item.name + "（" + item.users.length + "人）";
      option.selected = item.id === list.id;
      $("watchSelect").append(option);
    }
    $("watchCount").textContent = String(list.users.length);
    $("readerListName").textContent = list.name + " / RANDOM";
    $("listStatus").textContent =
      `登録 ${list.users.length}人` +
      (list.pending.length ? `・ID未照合 ${list.pending.length}人` : "") +
      " / 全11リスト";
    $("watchList").replaceChildren();
    list.users.forEach((name) => {
      const li = document.createElement("li"),
        label = document.createElement("span");
      label.textContent = "@" + name;
      const remove = button("×", async () => {
        list.users = list.users.filter((x) => x !== name);
        resetFeed();
        await save();
        renderWatch();
      });
      remove.setAttribute("aria-label", name + "を削除");
      li.append(label, remove);
      $("watchList").append(li);
    });
    $("pendingMembers").replaceChildren();
    list.pending.forEach((member, at) => {
      const li = document.createElement("li"),
        label = document.createElement("span");
      label.textContent = member.name + "（ID未照合） ";
      li.append(
        label,
        button("IDを登録", async () => {
          if (!requireOwner()) return;
          const input = prompt(member.name + "さんのnoteユーザーIDまたはURL");
          if (input === null) return;
          const name = M.watchName(input);
          if (!name) {
            notice("noteのユーザーIDまたはURLを確認してください。");
            return;
          }
          if (
            !list.users.includes(name) &&
            list.users.length >= M.MAX_CREATORS
          ) {
            notice("1リストは200人までです。");
            return;
          }
          if (!list.users.includes(name)) list.users.push(name);
          list.pending.splice(at, 1);
          resetFeed();
          await save();
          renderWatch();
        }),
      );
      $("pendingMembers").append(li);
    });
  }
  $("watchSelect").onchange = async () => {
    if (!requireOwner()) return;
    data.activeListId = $("watchSelect").value;
    resetFeed();
    await save();
    renderWatch();
  };
  $("renameList").onclick = async () => {
    if (!requireOwner()) return;
    const list = M.activeList(data),
      name = prompt("リスト名（40文字以内）", list.name);
    if (name === null) return;
    if (!name.trim() || name.trim().length > M.MAX_NAME_LENGTH) {
      notice("リスト名は1〜40文字で入力してください。");
      return;
    }
    list.name = name.trim();
    await save();
    renderWatch();
  };
  $("importList").onclick = () => {
    if (requireOwner()) $("watchFile").click();
  };
  $("watchFile").onchange = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const account = owner;
    try {
      if (!requireOwner()) return;
      if (file.size > 128 * 1024)
        throw new Error("リストファイルは128KB以下にしてください。");
      const input = JSON.parse(await file.text());
      if (owner !== account) return;
      const requested = input?.list?.id;
      const targetId = data.lists.some((l) => l.id === requested)
        ? requested
        : data.activeListId;
      data = M.importList(data, input, { targetId, merge: true });
      resetFeed();
      await save();
      renderWatch();
      notice(M.activeList(data).name + "を読み込みました。");
    } catch (e) {
      notice(e.message || "ファイルを読み込めませんでした。");
    } finally {
      e.target.value = "";
    }
  };
  $("exportList").onclick = () => {
    if (!requireOwner()) return;
    const list = M.activeList(data),
      blob = new Blob(
        [
          JSON.stringify(
            { format: "nero-watchlist", version: 1, owner, list },
            null,
            2,
          ),
        ],
        { type: "application/json" },
      );
    const url = URL.createObjectURL(blob),
      a = document.createElement("a");
    a.href = url;
    a.download = "nero-watchlist-" + list.id + ".json";
    document.body.append(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  };
  $("watchForm").addEventListener("submit", async (e) => {
    e.preventDefault();
    if (!requireOwner()) return;
    const list = M.activeList(data),
      name = M.watchName($("watchInput").value);
    if (!name) {
      notice(
        "noteのユーザー名か、https://note.com/ から始まるURLを入力してください。",
      );
      return;
    }
    if (!list.users.includes(name) && list.users.length >= M.MAX_CREATORS) {
      notice("ウォッチリストは200人まで登録できます。");
      return;
    }
    if (!list.users.includes(name)) list.users.push(name);
    resetFeed();
    await save();
    $("watchInput").value = "";
    renderWatch();
  });
  function restoreFeedOptions() {
    $("feedIncludeLiked").checked = data.feedOptions.includeLiked;
    $("deepIncludeLiked").checked = data.feedOptions.deepIncludeLiked;
    $("deepCreator").value = data.feedOptions.deepCreator;
  }
  $("feedIncludeLiked").onchange = async () => {
    if (!requireOwner()) return;
    data.feedOptions.includeLiked = $("feedIncludeLiked").checked;
    resetFeed();
    await save();
  };
  $("deepIncludeLiked").onchange = async () => {
    if (!requireOwner()) return;
    data.feedOptions.deepIncludeLiked = $("deepIncludeLiked").checked;
    resetFeed();
    await save();
  };
  $("deepCreator").oninput = () => {
    resetFeed();
  };
  $("deepCreator").onchange = async () => {
    resetFeed();
    if (!owner) return;
    data.feedOptions.deepCreator = M.watchName($("deepCreator").value);
    await save();
  };
  async function fetchArticles(mode) {
    if (!requireOwner() || feeding) return;
    const list = M.activeList(data),
      creator = mode === "deep" ? M.watchName($("deepCreator").value) : "";
    if (mode === "deep" && !creator) {
      notice(
        "深掘りする人のnoteユーザー名かプロフィールURLを入力してください。",
      );
      return;
    }
    if (mode === "watch" && !list.users.length) {
      notice("ユーザーを追加するか、リストファイルを読み込んでください。");
      return;
    }
    const account = owner,
      listId = list.id,
      token = ++feedSeq;
    const includeLiked =
      mode === "deep"
        ? $("deepIncludeLiked").checked
        : $("feedIncludeLiked").checked;
    data.feedOptions.includeLiked = $("feedIncludeLiked").checked;
    data.feedOptions.deepIncludeLiked = $("deepIncludeLiked").checked;
    if (mode === "deep") data.feedOptions.deepCreator = creator;
    const args =
      mode === "deep"
        ? { mode: "deep", creator, expectedAccount: account, includeLiked }
        : {
            mode: "watch",
            creators: [...list.users],
            expectedAccount: account,
            includeLiked,
          };
    feeding = true;
    feedRequestPosted = false;
    feedCancelled = false;
    $("refreshFeed").disabled = true;
    $("deepFetch").disabled = true;
    $("cancelFeed").hidden = false;
    $("feedProgress").hidden = false;
    rows = [];
    index = 0;
    resetArticleNavigation();
    renderArticle();
    $("readerListName").textContent =
      (mode === "deep" ? "深掘り：@" + creator : list.name) + " / RANDOM";
    $("feedStatus").textContent =
      mode === "deep" ? "最大50本を探しています…" : "1人最大3本を探しています…";
    try {
      await save();
      if (owner !== account || token !== feedSeq || feedCancelled) return;
      feedRequestPosted = true;
      const r = await rpc(
        "watch_feed",
        args,
        (p) => {
          if (token !== feedSeq) return;
          $("feedStatus").textContent = p.message;
          $("feedProgress").max = Math.max(1, p.total || 1);
          $("feedProgress").value = p.completed || 0;
        },
        3600000,
      );
      if (
        owner !== account ||
        data.activeListId !== listId ||
        token !== feedSeq
      )
        return;
      rows = (r.items || []).filter(
        (row) => M.articleUrl(row.url) && (includeLiked || row.liked === false),
      );
      index = 0;
      renderArticle();
      $("feedStatus").textContent =
        `${r.cancelled ? "中断：" : ""}${rows.length}件をランダム表示 / ${includeLiked ? "スキ済みを含む" : "未スキのみ"}` +
        (!includeLiked ? ` / スキ済み ${r.likedCount || 0}件をスキップ` : "") +
        (r.statusFailedCount
          ? ` / スキ状態不明 ${r.statusFailedCount}件を除外`
          : "") +
        (r.failedCreators?.length
          ? ` / 取得失敗 ${r.failedCreators.length}人`
          : "") +
        (r.emptyCreators?.length
          ? ` / 記事なし ${r.emptyCreators.length}人`
          : "") +
        (r.shortfallCreators?.length
          ? ` / 目標本数に満たない人 ${r.shortfallCreators.length}人`
          : "") +
        (r.limitReachedCreators?.length
          ? ` / 探索上限 ${r.limitReachedCreators.length}人（途中結果）`
          : "");
    } catch (e) {
      if (token === feedSeq) $("feedStatus").textContent = e.message;
    } finally {
      feeding = false;
      feedRequestPosted = false;
      $("refreshFeed").disabled = false;
      $("deepFetch").disabled = false;
      $("cancelFeed").hidden = true;
      $("feedProgress").hidden = true;
    }
  }
  $("refreshFeed").onclick = () => fetchArticles("watch");
  $("deepFetch").onclick = () => fetchArticles("deep");
  $("cancelFeed").onclick = () => {
    if (!feeding) return;
    feedCancelled = true;
    if (!feedRequestPosted) {
      $("feedStatus").textContent = "記事の取得を中断しました。";
      return;
    }
    return rpc("cancel_job", { kind: "watch_feed" }).catch((e) =>
      notice(e.message),
    );
  };
  function safeLink(value) {
    return B.safeUrl(value, "https://note.com/");
  }
  function canonicalArticleUrl(value, key) {
    try {
      const u = new URL(value);
      if (
        u.username ||
        u.password ||
        u.port ||
        u.protocol !== "https:" ||
        u.hostname !== "note.com"
      )
        return "";
      const match = u.pathname.match(
        /^\/([a-zA-Z0-9_-]+)\/n\/(n[a-zA-Z0-9_-]+)\/?$/,
      );
      return match && (!key || match[2] === key)
        ? u.origin + u.pathname.replace(/\/$/, "")
        : "";
    } catch {
      return "";
    }
  }
  function currentArticle() {
    return linkedArticle || rows[index];
  }
  function resetArticleNavigation() {
    linkedArticle = null;
    articleHistory = [];
  }
  function openLinkedArticle(target) {
    const previous = currentArticle();
    const key = String(target?.key || "");
    if (!previous || !requireOwner() || !/^n[a-zA-Z0-9_-]+$/.test(key)) return;
    if (previous.key === key) {
      if (target.hash) scrollToArticleAnchor(target.hash);
      return;
    }
    articleHistory.push({
      linked: linkedArticle,
      scrollTop: $("articleScroll").scrollTop,
    });
    linkedArticle = {
      key,
      url: canonicalArticleUrl(target.url, key),
      urlname: M.watchName(target.urlname),
      name: "リンク先の記事",
    };
    renderArticle({ anchor: target.hash || "" });
  }
  $("articleBack").onclick = () => {
    const previous = articleHistory.pop();
    if (!previous) return;
    linkedArticle = previous.linked;
    renderArticle({ scrollTop: previous.scrollTop });
  };
  function scrollToArticleAnchor(hash) {
    if (!hash) return false;
    const el = document.getElementById(B.anchorId(hash));
    if (!el) return false;
    el.scrollIntoView({ block: "start" });
    return true;
  }
  function applyArticleMetadata(row, result) {
    const canonical = canonicalArticleUrl(result.url, row.key);
    if (canonical) row.url = canonical;
    if (result.title) row.name = result.title;
    if (result.urlname) row.urlname = M.watchName(result.urlname);
    if (result.nickname) row.nickname = result.nickname;
    if (result.publishAt) row.publishAt = result.publishAt;
  }
  function updateArticleHeader(row) {
    $("title").textContent = row.name || "無題の記事";
    $("author").textContent =
      (row.nickname || row.urlname || "") +
      (row.publishAt
        ? " · " + new Date(row.publishAt).toLocaleDateString("ja-JP")
        : "");
    const url = canonicalArticleUrl(row.url, row.key);
    $("original").hidden = !url;
    if (url) $("original").href = url;
    else $("original").removeAttribute("href");
    $("articleComment").disabled = !url || !owner;
  }
  function updateArticleStatus(row, token) {
    if (!canonicalArticleUrl(row.url, row.key)) return;
    rpc("note_action", {
      noteAction: "status",
      articleUrl: row.url,
      force: true,
    })
      .then((r) => {
        if (token !== articleSeq) return;
        row.liked = r.liked === true;
        $("like").textContent = row.liked ? "♥ スキ済み" : "♡ スキ";
        $("like").disabled = row.liked;
      })
      .catch(() => {
        if (token === articleSeq) $("like").disabled = false;
      });
  }
  function cardMetadata(key, account) {
    const cacheKey = account + ":" + key;
    const cached = cardMetadataCache.get(cacheKey);
    if (cached && Date.now() - cached.at < 60000) return cached.promise;
    const promise = rpc("article", { key })
      .then((r) => ({
        title: r.title,
        description: r.description,
        imageUrl: r.imageUrl,
        url: canonicalArticleUrl(r.url, key),
        nickname: r.nickname,
        urlname: r.urlname,
      }))
      .catch((error) => {
        cardMetadataCache.delete(cacheKey);
        throw error;
      });
    cardMetadataCache.set(cacheKey, { at: Date.now(), promise });
    while (cardMetadataCache.size > 80)
      cardMetadataCache.delete(cardMetadataCache.keys().next().value);
    return promise;
  }
  function hydrateArticleCards(cards, token) {
    const account = owner,
      queued = [];
    let active = 0;
    async function drain() {
      while (active < 2 && queued.length && token === articleSeq) {
        const card = queued.shift();
        active++;
        (async () => {
          try {
            const r = await cardMetadata(card.key, account);
            if (token !== articleSeq || owner !== account) return;
            if (r.title) card.title.textContent = r.title;
            if (r.description) {
              card.description.textContent = r.description;
              card.description.hidden = false;
            }
            card.meta.textContent =
              (r.nickname || r.urlname || "note") + " · リーダーで読む →";
            if (r.url) card.link.href = r.url;
            const image = safeLink(r.imageUrl);
            if (image.startsWith("https://")) {
              card.image.src = image;
              card.image.hidden = false;
              card.image.addEventListener(
                "error",
                () => {
                  card.image.hidden = true;
                },
                { once: true },
              );
            }
          } catch {
            /* The visible URL remains usable if metadata fails. */
          } finally {
            active--;
            drain();
          }
        })();
      }
    }
    if (typeof IntersectionObserver === "function") {
      const byElement = new Map(cards.map((card) => [card.element, card]));
      const observer = new IntersectionObserver(
        (entries) => {
          for (const entry of entries) {
            if (!entry.isIntersecting || token !== articleSeq) continue;
            observer.unobserve(entry.target);
            queued.push(byElement.get(entry.target));
          }
          drain();
        },
        { root: $("articleScroll"), rootMargin: "240px" },
      );
      cardObserver = observer;
      cards.forEach((card) => observer.observe(card.element));
    } else {
      queued.push(...cards);
      drain();
    }
  }
  async function renderArticle({ scrollTop = 0, anchor = "" } = {}) {
    const row = currentArticle(),
      token = ++articleSeq;
    cardObserver?.disconnect();
    cardObserver = null;
    $("empty").hidden = !!row;
    $("article").hidden = !row;
    $("articleBack").hidden = !articleHistory.length;
    $("position").textContent = rows.length
      ? `${linkedArticle ? "リンク先 · " : ""}${index + 1} / ${rows.length}`
      : "0 / 0";
    $("like").disabled = true;
    $("articleComment").disabled = true;
    $("prev").disabled = !!linkedArticle || !rows.length || index === 0;
    $("next").disabled =
      !!linkedArticle || !rows.length || index === rows.length - 1;
    $("articleHint").textContent = linkedArticle
      ? "リンク先の記事を表示中 / 「リンク元へ戻る」で読んでいた場所へ"
      : "上・下にスワイプ / ↑ ↓ キーで切り替え";
    if (!row) return;
    if (!row.key) row.key = canonicalArticleUrl(row.url).split("/n/")[1] || "";
    updateArticleHeader(row);
    $("body").textContent = "本文を読み込んでいます…";
    $("cover").hidden = true;
    $("articleScroll").scrollTop = 0;
    $("like").textContent = "♡ スキ";
    const initialUrl = canonicalArticleUrl(row.url, row.key);
    if (initialUrl) updateArticleStatus(row, token);
    try {
      const r = await rpc("article", {
        key: row.key || row.url.split("/n/")[1],
      });
      if (token !== articleSeq) return;
      applyArticleMetadata(row, r);
      updateArticleHeader(row);
      if (!initialUrl || initialUrl !== row.url)
        updateArticleStatus(row, token);
      const cards = [];
      $("body").replaceChildren(
        B.render(
          r.body ||
            r.description ||
            row.description ||
            "本文はnoteで確認してください。",
          {
            baseUrl: row.url || "https://note.com/n/" + row.key,
            onArticleLink: (target) => {
              if (token === articleSeq) openLinkedArticle(target);
            },
            onCard: (card) => {
              if (card.key) cards.push(card);
            },
          },
        ),
      );
      const cover = safeLink(r.imageUrl || row.eyecatch);
      if (cover.startsWith("https://")) {
        $("cover").src = cover;
        $("cover").referrerPolicy = "no-referrer";
        $("cover").hidden = false;
      }
      $("articleScroll").scrollTop = scrollTop;
      if (anchor) scrollToArticleAnchor(anchor);
      if (cards.length) hydrateArticleCards(cards, token);
    } catch (e) {
      if (token === articleSeq) {
        $("body").textContent = e.message + " noteで記事を確認してください。";
        $("articleScroll").scrollTop = scrollTop;
      }
    }
  }
  function move(d) {
    if (linkedArticle) return;
    const next = Math.max(0, Math.min(rows.length - 1, index + d));
    if (next === index) return;
    index = next;
    renderArticle();
  }
  $("prev").onclick = () => move(-1);
  $("next").onclick = () => move(1);
  document.addEventListener("keydown", (e) => {
    if (
      /INPUT|TEXTAREA|SELECT|BUTTON/.test(e.target.tagName) ||
      e.ctrlKey ||
      e.metaKey ||
      e.altKey
    )
      return;
    const el = $("articleScroll");
    if (
      e.key === "ArrowDown" &&
      el.scrollTop + el.clientHeight >= el.scrollHeight - 4
    ) {
      e.preventDefault();
      move(1);
    }
    if (e.key === "ArrowUp" && el.scrollTop <= 4) {
      e.preventDefault();
      move(-1);
    }
  });
  let touch = null;
  $("articleScroll").addEventListener(
    "touchstart",
    (e) => {
      if (e.touches.length !== 1) return;
      touch = {
        x: e.touches[0].clientX,
        y: e.touches[0].clientY,
        top: e.currentTarget.scrollTop,
      };
    },
    { passive: true },
  );
  $("articleScroll").addEventListener(
    "touchend",
    (e) => {
      if (!touch || !e.changedTouches.length) return;
      const t = e.changedTouches[0],
        el = e.currentTarget;
      if (
        M.canSwipe(
          touch,
          { x: t.clientX, y: t.clientY },
          { top: touch.top, height: el.clientHeight, total: el.scrollHeight },
        )
      )
        move(t.clientY < touch.y ? 1 : -1);
      touch = null;
    },
    { passive: true },
  );
  $("like").onclick = async () => {
    if (!requireOwner()) return;
    const row = currentArticle(),
      token = articleSeq;
    if (!row || !canonicalArticleUrl(row.url, row.key)) return;
    $("like").disabled = true;
    try {
      await rpc(
        "note_action",
        { noteAction: "like", articleUrl: row.url, expectedAccount: owner },
        null,
        45000,
      );
      row.liked = true;
      if (token === articleSeq) $("like").textContent = "♥ スキ済み";
    } catch (e) {
      notice(e.message);
      if (token === articleSeq) $("like").disabled = false;
    }
  };
  function renderInbox() {
    $("inboxCount").textContent = String(inbox.length);
    $("inboxList").replaceChildren();
    inbox.slice(0, visible).forEach((item) => {
      const c = item.comment,
        card = document.createElement("div");
      card.className = "comment-card";
      const title = document.createElement("h3"),
        text = document.createElement("p"),
        meta = document.createElement("p");
      title.textContent = item.articleTitle;
      text.textContent = c.body;
      meta.className = "muted";
      meta.textContent =
        (c.authorName || c.authorUrlname) +
        " · " +
        (c.publishedAt ? new Date(c.publishedAt).toLocaleString("ja-JP") : "");
      card.append(
        title,
        meta,
        text,
        button("返信を書く", () =>
          openComposer({ ...item, replyTarget: c.replyTarget, kind: "reply" }),
        ),
        button("♡ コメントにスキ", (e) =>
          sendCommentLike(item, e.currentTarget),
        ),
        button("記事を読む", () => {
          const url = M.articleUrl(item.articleUrl);
          if (!url) return;
          resetFeed();
          rows = [{ url, key: url.split("/n/")[1], name: item.articleTitle }];
          index = 0;
          renderArticle();
        }),
      );
      $("inboxList").append(card);
    });
    $("moreInbox").hidden = inbox.length <= visible;
  }
  function renderPendingLikes(message = "") {
    $("pendingLikesCount").textContent = String(pendingCommentLikes.length);
    $("pendingLikesPanel").hidden =
      !pendingCommentLikes.length && !unknownReplyCount && !message;
    $("pendingLikeStatus").textContent =
      message ||
      (unknownReplyCount
        ? `送信結果が未確認の返信が${unknownReplyCount}件あります。noteで確認してください。`
        : "ここではスキだけを送信します。返信本文は再送しません。");
    $("pendingLikesList").replaceChildren();
    pendingCommentLikes.slice(0, pendingLikeVisible).forEach((item) => {
      const card = document.createElement("div");
      card.className = "comment-card";
      const title = document.createElement("h3"),
        body = document.createElement("p");
      title.textContent =
        (item.replySent ? "返信済み：" : "") +
        (item.articleTitle || "コメントへのスキ");
      body.textContent = item.replyTarget?.body || "";
      const open = document.createElement("a");
      open.href = M.articleUrl(item.articleUrl);
      open.target = "_blank";
      open.rel = "noreferrer noopener";
      open.textContent = "noteで確認 ↗";
      card.append(
        title,
        body,
        button("スキのみ再試行", (e) => sendCommentLike(item, e.currentTarget)),
        open,
      );
      $("pendingLikesList").append(card);
    });
    $("morePendingLikes").hidden =
      pendingCommentLikes.length <= pendingLikeVisible;
  }
  async function refreshPendingLikes() {
    if (!owner) {
      pendingCommentLikes = [];
      unknownReplyCount = 0;
      renderPendingLikes();
      return;
    }
    const account = owner;
    try {
      const result = await rpc("pending_comment_likes", { owner: account });
      if (owner !== account) return;
      pendingCommentLikes = result.items || [];
      unknownReplyCount = result.unknownReplyCount || 0;
      renderPendingLikes();
    } catch (e) {
      if (owner === account) renderPendingLikes(e.message);
    }
  }
  async function sendCommentLike(item, control) {
    if (!requireOwner() || sending) return;
    const account = owner,
      inboxKey = item.inboxKey || item.key;
    sending = true;
    if (control) control.disabled = true;
    try {
      await rpc(
        "comment_like",
        item.id
          ? { owner: account, pendingId: item.id }
          : {
              owner: account,
              articleUrl: item.articleUrl,
              articleTitle: item.articleTitle,
              inboxKey,
              replyTarget: item.replyTarget || item.comment?.replyTarget,
            },
        null,
        45000,
      );
      if (owner !== account) return;
      inbox = inbox.filter((row) => row.key !== inboxKey);
      if (item.replySent && data.uncertain[inboxKey]) {
        delete data.uncertain[inboxKey];
        await save().catch(() => {});
      }
      if (
        composer?.articleUrl === item.articleUrl &&
        composer.replyTarget?.commentKey ===
          (item.replyTarget || item.comment?.replyTarget)?.commentKey
      ) {
        $("composerLikeOnly").hidden = true;
        $("sendStatus").textContent = composer.replySent
          ? "返信とスキを送信しました。"
          : "コメントにスキしました。";
      }
      notice("コメントにスキしました。");
    } catch (e) {
      notice(e.message);
    } finally {
      sending = false;
      if (control) control.disabled = false;
      renderInbox();
      await refreshPendingLikes();
    }
  }
  $("morePendingLikes").onclick = () => {
    pendingLikeVisible += 30;
    renderPendingLikes();
  };
  $("composerLikeOnly").onclick = (e) => {
    if (composer)
      sendCommentLike(
        { ...composer, inboxKey: composer.inboxKey || composer.key },
        e.currentTarget,
      );
  };
  function updateSendLabel() {
    $("send").textContent =
      composer?.kind === "reply"
        ? $("replyLike").checked
          ? "返信＋スキを送信"
          : "返信する"
        : "コメントを送信";
  }
  $("replyLike").onchange = updateSendLabel;
  $("moreInbox").onclick = () => {
    visible += 30;
    renderInbox();
  };
  $("scan").onclick = async () => {
    if (!requireOwner() || scanning) return;
    scanning = true;
    $("scan").disabled = true;
    $("cancelScan").hidden = false;
    $("progress").hidden = false;
    const account = owner;
    try {
      const r = await rpc(
        "inbox_scan",
        { force: $("fullScan").checked },
        (p) => {
          $("scanStatus").textContent =
            p.message + ` / 返信待ち ${p.found || 0}件`;
          $("progress").max = Math.max(1, p.total || 1);
          $("progress").value = p.completed || 0;
        },
        3600000,
      );
      if (owner !== account) return;
      inbox = r.items || [];
      visible = 30;
      renderInbox();
      $("scanStatus").textContent =
        `${r.cancelled ? "中断・途中保存" : "確認完了"}：${r.checkedArticles}記事 / 取得失敗 ${r.failed}件 / 返信待ち ${inbox.length}件`;
    } catch (e) {
      $("scanStatus").textContent = e.message;
    } finally {
      scanning = false;
      $("scan").disabled = false;
      $("cancelScan").hidden = true;
      $("progress").hidden = true;
    }
  };
  $("cancelScan").onclick = () =>
    rpc("cancel_job", { kind: "inbox" }).catch((e) => notice(e.message));
  function openComposer(c) {
    if (sending) {
      notice("送信結果を確認しています。");
      return;
    }
    if (!requireOwner()) return;
    composer = { ...c, owner };
    $("composer").hidden = false;
    $("composerKind").textContent = c.kind === "reply" ? "REPLY" : "COMMENT";
    $("replyLikeOption").hidden = c.kind !== "reply";
    $("replyLike").checked = true;
    $("composerLikeOnly").hidden = true;
    updateSendLabel();
    $("composerTitle").textContent = c.articleTitle || "";
    $("context").textContent = c.comment?.body || "この記事にコメントします。";
    $("draft").value = data.drafts[M.draftKey(c)] || "";
    $("draftCount").textContent = String($("draft").value.length);
    const unknown = !!data.uncertain[M.draftKey(c)];
    $("send").disabled = unknown;
    $("resolveUnknown").hidden = !unknown;
    $("sendStatus").textContent = unknown
      ? "前回の送信結果が未確認です。noteで確認してから操作してください。"
      : "";
    $("draft").focus();
  }
  $("articleComment").onclick = () => {
    const r = currentArticle();
    if (r && canonicalArticleUrl(r.url, r.key))
      openComposer({
        kind: "comment",
        articleUrl: r.url,
        articleTitle: r.name,
      });
  };
  $("draft").oninput = () => {
    if (!composer) return;
    data.drafts[M.draftKey(composer)] = $("draft").value;
    $("draftCount").textContent = String($("draft").value.length);
    save().catch((e) => notice("下書きを保存できませんでした：" + e.message));
  };
  $("closeComposer").onclick = () => {
    if (sending) return;
    $("composer").hidden = true;
    composer = null;
  };
  $("send").onclick = async () => {
    if (!composer || sending || !requireOwner()) return;
    const composerRef = composer,
      sendData = data;
    const c = { ...composer },
      account = c.owner,
      key = M.draftKey(c),
      text = $("draft").value.trim();
    if (!text || text.length > 500) return;
    if (c.owner !== owner || data.uncertain[key]) return;
    sending = true;
    $("send").disabled = true;
    $("draft").disabled = true;
    $("replyLike").disabled = true;
    $("sendStatus").textContent = "送信しています…";
    // Persist BEFORE posting. A closed tab or lost Port must never invite an
    // automatic retry of a comment whose server result is unknown.
    sendData.uncertain[key] = true;
    const saveSendData = () =>
      browser.storage.local.set({ [M.storageKey(account)]: sendData });
    try {
      await saveSendData();
      if (owner !== account || composer !== composerRef)
        throw Object.assign(
          new Error("アカウントが変わったため送信を中断しました。"),
          { result: { code: "account_changed" } },
        );
      const r = await rpc(
        c.kind === "reply" ? "reply_comment" : "note_action",
        c.kind === "reply"
          ? {
              owner: account,
              articleUrl: c.articleUrl,
              articleTitle: c.articleTitle,
              likeComment: $("replyLike").checked,
              comment: text,
              replyTarget: c.replyTarget,
              inboxKey: c.inboxKey || c.key,
            }
          : {
              noteAction: "comment",
              expectedAccount: account,
              articleUrl: c.articleUrl,
              comment: text,
            },
        null,
        45000,
      );
      if (!r.ok) throw new Error("送信結果を確認できませんでした。");
      // A successful reply remains successful when the separate like fails.
      // Clear the text before saving locally so a storage error cannot invite a repost.
      delete sendData.uncertain[key];
      delete sendData.drafts[key];
      if (owner !== account || composer !== composerRef) {
        await saveSendData().catch(() => {});
        return;
      }
      $("draft").value = "";
      $("draftCount").textContent = "0";
      $("resolveUnknown").hidden = true;
      if (c.kind === "reply") {
        composer.replySent = true;
        inbox = inbox.filter((x) => x.key !== c.key);
        renderInbox();
        $("composerLikeOnly").hidden = !r.likePending;
      }
      const message =
        (r.likePending
          ? r.message
          : c.kind === "reply"
            ? r.liked
              ? "返信とスキを送信しました。"
              : "返信しました。"
            : "コメントを送信しました。") +
        (r.receiptSaved === false
          ? " 送信済み情報を端末に保存できませんでした。返信は再送しないでください。"
          : "");
      $("sendStatus").textContent = message;
      notice(message);
      try {
        await saveSendData();
      } catch {
        $("sendStatus").textContent =
          message +
          " 端末の保存情報を更新できませんでした。返信は再送しないでください。";
      }
    } catch (e) {
      const definitive =
        e.result &&
        [
          "account_changed",
          "login_required",
          "invalid_comment",
          "invalid_reply",
          "invalid_comment_target",
          "pending_likes_storage_failed",
          "busy",
          "throttled",
          "comment_api_rejected",
          "comment_acknowledgement",
        ].includes(e.result.code);
      if (definitive) {
        delete sendData.uncertain[key];
        await saveSendData().catch(() => {});
      }
      if (owner === account && composer === composerRef) {
        $("sendStatus").textContent = e.message;
        $("resolveUnknown").hidden = !sendData.uncertain[key];
      }
    } finally {
      sending = false;
      $("draft").disabled = false;
      $("replyLike").disabled = false;
      $("send").disabled = composer
        ? !!data.uncertain[M.draftKey(composer)]
        : false;
      await refreshPendingLikes();
    }
  };
  $("resolveUnknown").onclick = async () => {
    if (!composer) return;
    const link = M.articleUrl(composer.articleUrl);
    if (
      !confirm(
        "noteでコメントの送信結果を確認しましたか？ 送信済みの場合は下書きを消してください。",
      )
    ) {
      if (link) browser.tabs.create({ url: link });
      return;
    }
    delete data.uncertain[M.draftKey(composer)];
    await save();
    $("send").disabled = false;
    $("resolveUnknown").hidden = true;
    $("sendStatus").textContent =
      "確認済み。送信済みの場合は再送しないでください。";
  };
  $("clearData").onclick = async () => {
    if (!requireOwner() || sending || scanning || feeding) return;
    if (
      !confirm(
        "@" +
          owner +
          " のウォッチリスト・下書き・コメントキャッシュを削除しますか？",
      )
    )
      return;
    const all = await browser.storage.local.get(null);
    const markers = Object.keys(all).filter((k) =>
      k.startsWith("nero.members.sent." + owner + "."),
    );
    await browser.storage.local.remove([
      ...markers,
      M.storageKey(owner),
      "nero.app.inbox.v4." + owner,
      "nero.app.priority.v2." + owner,
      "nero.members.commentLikes.v1." + owner,
    ]);
    data = M.normalizeData(null, owner, null);
    restoreFeedOptions();
    inbox = [];
    pendingCommentLikes = [];
    unknownReplyCount = 0;
    renderPendingLikes();
    rows = [];
    resetArticleNavigation();
    composer = null;
    $("composer").hidden = true;
    renderWatch();
    renderInbox();
    renderArticle();
    notice("保存データを削除しました。");
  };
  $("connect").onclick = health;
  connectPort();
  health();
})();

;

})(globalThis.NeroChromePlatform.browser, globalThis.NeroChromePlatform.fetch);
